# Industrial Kit

All 32 one-shots from Signature Sounds' Industrial Percussions Kit/Foley.

Source: https://signaturesounds.org/store/p/industrial-percussions-kitfoley

Ingested by `tools/ingest-drumkit.js`: one file per lane, trailing silence trimmed,
levels untouched, mixed to mono and encoded to AAC. The lane table in `lanes.json`
records which file each lane came from; re-run the tool to swap any of them.

| lane | file | from | seconds | peak dB | rms dB |
|---|---|---|---|---|---|
| Sub Boom | industrial/36-subboom.m4a | 36-subboom.flac | 2.105 | -1.0 | -22.1 |
| Boom | industrial/37-boom.m4a | 37-boom.flac | 1.550 | -1.8 | -23.6 |
| Thud 1 | industrial/38-thud1.m4a | 38-thud1.flac | 2.418 | -0.0 | -19.4 |
| Thud 2 | industrial/39-thud2.m4a | 39-thud2.flac | 2.195 | -2.9 | -27.1 |
| Thud 3 | industrial/40-thud3.m4a | 40-thud3.flac | 1.494 | -1.8 | -23.4 |
| Thud 4 | industrial/41-thud4.m4a | 41-thud4.flac | 1.819 | -0.0 | -24.0 |
| Hydraulic | industrial/42-hydraulic.m4a | 42-hydraulic.flac | 1.963 | -3.3 | -26.6 |
| Barrel 1 | industrial/43-barrel1.m4a | 43-barrel1.flac | 1.904 | -2.5 | -27.7 |
| Barrel 2 | industrial/44-barrel2.m4a | 44-barrel2.flac | 1.814 | -5.0 | -26.1 |
| Barrel 3 | industrial/45-barrel3.m4a | 45-barrel3.flac | 1.593 | -5.9 | -28.4 |
| Barrel 4 | industrial/46-barrel4.m4a | 46-barrel4.flac | 0.999 | -3.4 | -22.5 |
| Barrel 5 | industrial/47-barrel5.m4a | 47-barrel5.flac | 2.063 | -6.5 | -30.1 |
| Barrel 6 | industrial/48-barrel6.m4a | 48-barrel6.flac | 1.740 | -8.8 | -32.0 |
| Barrel 7 | industrial/49-barrel7.m4a | 49-barrel7.flac | 1.558 | -0.1 | -22.3 |
| Pipe Clang | industrial/50-pipeclang.m4a | 50-pipeclang.flac | 0.818 | -1.3 | -21.2 |
| Pipe Hit 1 | industrial/51-pipehit1.m4a | 51-pipehit1.flac | 0.666 | 0.0 | -18.9 |
| Pipe Hit 2 | industrial/52-pipehit2.m4a | 52-pipehit2.flac | 1.332 | 0.0 | -17.7 |
| Pipe Hit 3 | industrial/53-pipehit3.m4a | 53-pipehit3.flac | 1.271 | 0.0 | -18.5 |
| Pipe Ring | industrial/54-pipering.m4a | 54-pipering.flac | 1.911 | -14.6 | -35.0 |
| Anvil Ring | industrial/55-anvilring.m4a | 55-anvilring.flac | 0.982 | -5.8 | -24.5 |
| Clunk | industrial/56-clunk.m4a | 56-clunk.flac | 1.318 | 0.0 | -15.8 |
| Metal Ring | industrial/57-metalring.m4a | 57-metalring.flac | 1.458 | -4.3 | -25.3 |
| Screech | industrial/58-screech.m4a | 58-screech.flac | 1.914 | -2.4 | -21.9 |
| Chain Rattle | industrial/59-chainrattle.m4a | 59-chainrattle.flac | 1.620 | 0.0 | -20.3 |
| Clank 1 | industrial/60-clank1.m4a | 60-clank1.flac | 0.888 | -0.8 | -19.4 |
| Clank 2 | industrial/61-clank2.m4a | 61-clank2.flac | 0.878 | -0.6 | -20.0 |
| Clank 3 | industrial/62-clank3.m4a | 62-clank3.flac | 1.288 | -2.1 | -26.7 |
| Sheet Hit | industrial/63-sheethit.m4a | 63-sheethit.flac | 0.888 | -0.5 | -23.0 |
| Scrape | industrial/64-scrape.m4a | 64-scrape.flac | 0.666 | -17.7 | -38.7 |
| Rattle 1 | industrial/65-rattle1.m4a | 65-rattle1.flac | 0.700 | -7.4 | -28.5 |
| Rattle 2 | industrial/66-rattle2.m4a | 66-rattle2.flac | 0.804 | -4.0 | -23.3 |
| Tick | industrial/67-tick.m4a | 67-tick.flac | 1.029 | -1.8 | -24.6 |

Levels follow Big Rusty's balance by family, measured as hit loudness (first 200 ms, K-weighted): booms, thuds and the hydraulic hit at Big Rusty's kick level; barrels, pipe hits and the clunk at its toms; ringing metal (pipe clang, pipe ring, anvil ring, metal ring) at its cymbals; bright clanks, ticks, rattles, scrapes and the screech at its hats. Peaks stay under -1 dBFS; the silence before each hit is trimmed.

## Hit names

Named from measurements, not by ear: low-end share and spectral centre (thud, boom), how tonal the hit is (barrel, pipe, anvil), how long it rings, how many impacts it holds (rattle, chain) and how slowly it peaks (scrape, hydraulic).

| Lane | File | Centre | Tonal peak | Ring | Impacts | Peak at |
|---|---|---|---|---|---|---|
| Sub Boom | Industrial Percussion03.wav | 92 Hz | 73.4 dB at 90 Hz | 0.46 s | 3 | 15.1 ms |
| Boom | Industrial Percussion26.wav | 244 Hz | 58.4 dB at 143 Hz | 0.83 s | 0 | 22.9 ms |
| Thud 1 | Industrial Percussion07.wav | 212 Hz | 65.4 dB at 185 Hz | 0.56 s | 2 | 14.3 ms |
| Thud 2 | Industrial Percussion17.wav | 268 Hz | 53.9 dB at 141 Hz | 0.54 s | 0 | 11.8 ms |
| Thud 3 | Industrial Percussion06.wav | 297 Hz | 50.5 dB at 191 Hz | 0.48 s | 1 | 15.8 ms |
| Thud 4 | Industrial Percussion01.wav | 317 Hz | 40.3 dB at 161 Hz | 0.44 s | 0 | 31.7 ms |
| Hydraulic | Industrial Percussion04.wav | 287 Hz | 50.1 dB at 146 Hz | 1.08 s | 1 | 99.5 ms |
| Barrel 1 | Industrial Percussion16.wav | 282 Hz | 63.5 dB at 225 Hz | 0.34 s | 2 | 18.8 ms |
| Barrel 2 | Industrial Percussion05.wav | 296 Hz | 65.0 dB at 273 Hz | 0.66 s | 0 | 24.1 ms |
| Barrel 3 | Industrial Percussion31.wav | 333 Hz | 62.6 dB at 170 Hz | 0.49 s | 1 | 7.4 ms |
| Barrel 4 | Industrial Percussion29.wav | 342 Hz | 48.0 dB at 245 Hz | 0.44 s | 3 | 17.7 ms |
| Barrel 5 | Industrial Percussion28.wav | 349 Hz | 52.4 dB at 188 Hz | 0.58 s | 2 | 9.4 ms |
| Barrel 6 | Industrial Percussion18.wav | 422 Hz | 54.8 dB at 240 Hz | 0.48 s | 0 | 9.4 ms |
| Barrel 7 | Industrial Percussion30.wav | 510 Hz | 49.1 dB at 231 Hz | 0.53 s | 1 | 8.8 ms |
| Pipe Clang | Industrial Percussion27.wav | 334 Hz | 82.2 dB at 623 Hz | 0.48 s | 1 | 9.4 ms |
| Pipe Hit 1 | Industrial Percussion13.wav | 641 Hz | 31.9 dB at 298 Hz | 0.35 s | 1 | 55.5 ms |
| Pipe Hit 2 | Industrial Percussion11.wav | 1109 Hz | 29.6 dB at 570 Hz | 0.59 s | 0 | 40.3 ms |
| Pipe Hit 3 | Industrial Percussion23.wav | 1274 Hz | 27.5 dB at 581 Hz | 0.56 s | 0 | 18.9 ms |
| Pipe Ring | Industrial Percussion24.wav | 863 Hz | 33.5 dB at 326 Hz | 1.19 s | 0 | 38.3 ms |
| Anvil Ring | Industrial Percussion25.wav | 703 Hz | 83.7 dB at 705 Hz | 0.9 s | 0 | 41.3 ms |
| Clunk | Industrial Percussion08.wav | 1417 Hz | 35.7 dB at 1355 Hz | 0.38 s | 0 | 70.1 ms |
| Metal Ring | Industrial Percussion15.wav | 2805 Hz | 24.3 dB at 1180 Hz | 0.76 s | 0 | 53.3 ms |
| Screech | Industrial Percussion14.wav | 2736 Hz | 31.4 dB at 1728 Hz | 0.95 s | 0 | 181.9 ms |
| Chain Rattle | Industrial Percussion19.wav | 577 Hz | 36.4 dB at 255 Hz | 0.56 s | 4 | 182.4 ms |
| Clank 1 | Industrial Percussion10.wav | 2298 Hz | 24.1 dB at 231 Hz | 0.52 s | 0 | 19.3 ms |
| Clank 2 | Industrial Percussion09.wav | 2506 Hz | 20.5 dB at 210 Hz | 0.46 s | 0 | 15.4 ms |
| Clank 3 | Industrial Percussion22.wav | 2884 Hz | 22.1 dB at 773 Hz | 0.48 s | 0 | 14.6 ms |
| Sheet Hit | Industrial Percussion12.wav | 3409 Hz | 17.3 dB at 2001 Hz | 0.46 s | 1 | 31.6 ms |
| Scrape | Industrial Percussion20.wav | 3751 Hz | 18.9 dB at 398 Hz | 0.45 s | 1 | 95.9 ms |
| Rattle 1 | Industrial Percussion02.wav | 2907 Hz | 18.6 dB at 170 Hz | 0.5 s | 2 | 9.3 ms |
| Rattle 2 | Industrial Percussion21.wav | 4884 Hz | 19.9 dB at 915 Hz | 0.46 s | 2 | 8.1 ms |
| Tick | Industrial Percussion32.wav | 5456 Hz | 16.2 dB at 823 Hz | 0.3 s | 0 | 10.9 ms |
