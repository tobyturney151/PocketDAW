# glasshum

Glass Hum — Sonic Pi sample `ambi_glass_hum`, https://freesound.org/people/kaligari/sounds/35391/.
Pitch, measured by harmonic-series fit over the whole sample and tracked over time: A2: the loudest partial is A3, but E4 and C#5 are odd harmonics of 110 Hz, so the fundamental is A2. Root A2, left as recorded (+0 cents). One sample played from A1 to A3 by resampling.

Ingested by tools/ingest-sfz.js from glasshum.sfz.
Range 33-57, tails cut at 10s.

Levels: loudest peak to -1.5 dBFS; gain ×2.929, so it peaks at -1.5 dBFS.

1.1.0: every zone now loops while its note is held. The loop starts once the attack settles and ends late in the sustain where the level matches; the end is aligned in phase with the start, the seam crossfaded, and a quarter second of continuation follows it.

## 1.2.0: one sample per semitone

The app no longer speeds samples up or slows them down: every note from A1 to A3 has its own sample, played at its own pitch. The recorded note (A2) is unchanged. The other 24 were made from the recording that played them before, pitch-shifted with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch 0.3.1 wrapper), which keeps the recording's timing: attack, vibrato, tremolo, loops and decay arrive as recorded. Each is level-matched to its source recording. Looping notes reuse their source's loop, with the same start, end and crossfade, lined up with the waveform at the new pitch. Seams slightly above our strict check: E2, F3, G3.

| Note | Made from | Semitones |
|---|---|---|
| A1 | A2 | -12 |
| A#1 | A2 | -11 |
| B1 | A2 | -10 |
| C2 | A2 | -9 |
| C#2 | A2 | -8 |
| D2 | A2 | -7 |
| D#2 | A2 | -6 |
| E2 | A2 | -5 |
| F2 | A2 | -4 |
| F#2 | A2 | -3 |
| G2 | A2 | -2 |
| G#2 | A2 | -1 |
| A#2 | A2 | +1 |
| B2 | A2 | +2 |
| C3 | A2 | +3 |
| C#3 | A2 | +4 |
| D3 | A2 | +5 |
| D#3 | A2 | +6 |
| E3 | A2 | +7 |
| F3 | A2 | +8 |
| F#3 | A2 | +9 |
| G3 | A2 | +10 |
| G#3 | A2 | +11 |
| A3 | A2 | +12 |
