# Clarinet

From Versilian Studios' VSCO 2 Community Edition (CC0): B♭ clarinet. Each note starts as its staccato recording and is joined into its sustain recording, which loops for as long as the note is held: short notes keep the tongued start, held notes carry on.
https://github.com/sgossner/VSCO-2-CE (staccato `Woodwinds/Clarinet/stac`, sustain `Woodwinds/Clarinet/susLong`)

Every note from D3 to F6 has its own sample, played at its own pitch.

**Layers.** Staccato, layer v2 (of v1-v3; the least breathy of the three). Sustain (long), layer v3 (loudest, of v1-v3), each recording's quiet lead-in trimmed. Both chosen by listening; the first take (round robin) of each note is used.

**Recordings.** Staccato, 11: D3, F3, A#3, D4, F4, A#4, D5, F5, A#5, D6, F6. Sustain, 11: D3, F3, A#3, D4, F4, A#4, D5, F5, A#5, D6, F6. Using the left microphone only: the two microphones are poorly correlated in these recordings, so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Refiled.** A file named for one note that plays another was filed where it sounds:

- Sustain: DCClar_susLong_F#5_v3_rr1_sum.wav: named F#5, expected F#6, sounds F6 -2 c

**Tuning.** Each recording's pitch was measured (cents, staccato: D3 -35, F3 -29, A#3 -40, D4 -30, F4 -25, A#4 -10, D5 -16, F5 -20, A#5 -4, D6 0, F6 -2; sustain: D3 +3, F3 +2, A#3 +1, D4 +2, F4 +1, A#4 +2, D5 +2, F5 +1, A#5 +2, D6 0, F6 -2) and corrected where 5 cents or more off.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Staccato from | Sustain from | Joint (ms) | Joins sustain at (s) | Loop (s) |
|---|---|---|---|---|---|
| D3 | D3 | D3 | 70-92 | 1.17 | 1.18-5.18 |
| D#3 | D3 (+1) | D3 (+1) | 70-92 | 1.14 | 1.21-5.22 |
| E3 | F3 (-1) | F3 (-1) | 80-102 | 0.48 | 0.50-6.58 |
| F3 | F3 | F3 | 75-97 | 0.49 | 0.50-6.57 |
| F#3 | F3 (+1) | F3 (+1) | 80-102 | 0.49 | 0.50-6.58 |
| G3 | F3 (+2) | F3 (+2) | 75-97 | 0.70 | 0.50-6.37 |
| G#3 | A#3 (-2) | A#3 (-2) | 60-82 | 0.34 | 0.74-7.69 |
| A3 | A#3 (-1) | A#3 (-1) | 60-82 | 0.40 | 0.68-7.63 |
| A#3 | A#3 | A#3 | 60-82 | 0.41 | 0.67-7.63 |
| B3 | A#3 (+1) | A#3 (+1) | 60-82 | 0.34 | 0.74-7.71 |
| C4 | A#3 (+2) | A#3 (+2) | 60-82 | 0.41 | 0.67-7.61 |
| C#4 | D4 (-1) | D4 (-1) | 65-87 | 0.46 | 0.50-7.80 |
| D4 | D4 | D4 | 65-87 | 0.50 | 0.50-7.76 |
| D#4 | D4 (+1) | D4 (+1) | 70-92 | 0.34 | 0.62-7.92 |
| E4 | F4 (-1) | F4 (-1) | 70-92 | 0.52 | 0.50-7.39 |
| F4 | F4 | F4 | 70-92 | 0.52 | 0.66-7.35 |
| F#4 | F4 (+1) | F4 (+1) | 65-87 | 0.52 | 0.56-7.37 |
| G4 | F4 (+2) | F4 (+2) | 65-87 | 0.52 | 0.56-7.37 |
| G#4 | A#4 (-2) | A#4 (-2) | 50-72 | 0.61 | 0.50-7.59 |
| A4 | A#4 (-1) | A#4 (-1) | 55-77 | 0.65 | 0.66-7.46 |
| A#4 | A#4 | A#4 | 55-77 | 0.65 | 0.50-7.50 |
| B4 | A#4 (+1) | A#4 (+1) | 60-82 | 0.67 | 0.60-7.53 |
| C5 | A#4 (+2) | A#4 (+2) | 55-77 | 0.32 | 0.50-7.91 |
| C#5 | D5 (-1) | D5 (-1) | 55-77 | 0.47 | 0.50-7.57 |
| D5 | D5 | D5 | 60-82 | 0.64 | 0.50-7.34 |
| D#5 | D5 (+1) | D5 (+1) | 60-82 | 0.62 | 0.50-7.34 |
| E5 | F5 (-1) | F5 (-1) | 55-77 | 0.44 | 2.47-7.34 |
| F5 | F5 | F5 | 60-82 | 0.63 | 2.29-7.16 |
| F#5 | F5 (+1) | F5 (+1) | 55-77 | 0.44 | 2.47-7.36 |
| G5 | F5 (+2) | F5 (+2) | 55-77 | 0.43 | 2.48-7.35 |
| G#5 | A#5 (-2) | A#5 (-2) | 65-87 | 0.60 | 0.62-7.42 |
| A5 | A#5 (-1) | A#5 (-1) | 50-72 | 0.57 | 0.64-7.42 |
| A#5 | A#5 | A#5 | 60-82 | 0.61 | 0.61-7.41 |
| B5 | A#5 (+1) | A#5 (+1) | 65-87 | 0.61 | 0.61-7.40 |
| C6 | A#5 (+2) | A#5 (+2) | 55-77 | 0.61 | 0.60-7.39 |
| C#6 | D6 (-1) | D6 (-1) | 60-82 | 0.10 | 1.30-7.63 |
| D6 | D6 | D6 | 60-82 | 0.09 | 1.31-7.62 |
| D#6 | D6 (+1) | D6 (+1) | 55-77 | 0.06 | 1.33-7.64 |
| E6 | F6 (-1) | F6 (-1) | 50-72 | 0.36 | 0.95-7.13 |
| F6 | F6 | F6 | 60-82 | 0.36 | 0.96-7.15 |

**The joint.** For each note:

1. The staccato is left just after its peak, so its tongued start and accent stay whole, and before it has faded 2 dB (here 50-102 ms into the note).
2. The sustain is joined where it has settled (not still swelling in or wavering), at the point that best matches the staccato's tone and pitch.
3. Where the staccato at the joint is 5 cents or more off the sustain, the staccato is retuned to it by varispeed, which keeps the attack crisp (13 of 40 notes, up to 9 cents). Joined notes match within 5 cents.
4. The sustain is moved by up to one cycle of the note to where the two waveforms line up best, and set to the staccato's level there.
5. They are crossfaded over three cycles of the note (22-40 ms) with gains that hold the level steady however well the waveforms line up. Measured across the joint, every note's level stays within -1.0 to +0.7 dB.
6. Tone glide: the sustain comes in with the staccato's tone, harmonic by harmonic, and relaxes to its own over 150 ms, so the brightness of the attack settles as in one played note. The glide changes tone only: each moment keeps its own loudness.
7. Loops: the sustain recording's own loop (pitch, tone and level matched, end aligned in phase, seam crossfaded) is kept where it still starts 0.5 s or later; otherwise a new loop is found the same way in the joined note (19 of 40 notes). Every loop starts at least 0.5 s in and lasts at least 1 s, with a quarter second of continuation after the loop end.

**Attack and breath.** The clarinet's staccato recordings carry more air than its sustains, which in a joined note arrives with every start and then vanishes. Two things take it out of the staccato part. Each staccato starts 10 ms before its tone comes within 20 dB of its peak, skipping up to 30 ms of air before the reed speaks. And between the harmonics the staccato is turned down 18 dB (short-time spectrum, 23 ms frames, 46 ms below G#3) while the harmonics pass untouched: the attack's breath measures about 34 dB under the tone instead of 24 (from D4 up; the worst note 29 instead of 15), the level the sustain carries. Breath sitting right on a harmonic can't be separated and stays. A 2 ms fade-in; the tongued start itself is kept.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s, K-weighted) across the range, set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

**Release.** 0.12 s, so short notes stop near the staccato's own length.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level. Built from the original recordings.

## 1.2.0

Now a hybrid: each note starts as the staccato recording (layer v2, with its breath lowered and its lead-in trimmed) and is joined into the sustain, which loops; release 0.12 s (was 0.25 s), attack ramp 2 ms (was 5 ms). 1.1.0 played the sustain recording alone. It also takes over from the Clarinet Staccato pack, which is retired.

## 1.1.0

Rebuilt from the loudest layer (v3 of v1-v3), each recording starting 10 ms before its tone is within 20 dB of its full level; 1.0.0 used v2, the second loudest.
