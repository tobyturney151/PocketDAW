# dantranhvib

Dan Tranh Vib. Source: https://github.com/sgossner/VCSL

Vibrato at ff, the layer previewed. Roots are the file names plus 12.

Ingested by tools/ingest-sfz.js from dantranhvib.sfz.
Range 45-85, tails cut at 4s.

Levels: loudest zone -7.6 dBFS as ingested; every zone given the same gain ×2.011 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.

## 1.1.0: tuned, one sample per semitone, even attacks and volume

Pitch: these recordings carry pressed vibrato, which swings from the base note upward by one to two and a half semitones; each recording's base pitch (the low edge of its pitch contour over the sustain) was tuned to its note, leaving the vibrato above it as played. Measured offsets of the recordings, in cents: B2 +2, C#3 +67, D#3 +28, F#3 +19, G#3 +30, B3 -6, C#4 +1, D#4 +26, F#4 -5, G#4 +5, B4 -20, C#5 -8, D#5 +7, F#5 +6, G#5 +10, B5 -24. Every note from A2 to C#6 now has its own sample, made from the recording that played it before with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch), shifted by the semitones to the note plus that recording's correction in one pass, which keeps the recording's timing. Recordings already within 5 cents on their own note are untouched. Attacks were aligned so each note speaks at the same moment after it starts (quiet starts trimmed, 2 ms fade-in so no pluck is softened), and each note's gain set onto a smooth line of loudness over its first half second, lowered so nothing clips.
