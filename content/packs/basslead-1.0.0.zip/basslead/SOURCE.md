# basslead

Synth Bass & Lead
-----------------

Version 2020-05-22

General MIDI instrument #88: Synth Lead 8 (bass + lead).

Samples by 快乐爱的小精灵 (Elf of Happy and Love) <lovebodhi@yandex.com>, sent to the FreePats project on April 2020. Made with Surge software synthesizer. This version has been edited by roberto@zenvoid.org.

Please visit FreePats web pages for updates and more content:
http://freepats.zenvoid.org/


Published under the terms of Creative Commons CC0 public domain dedication:
https://creativecommons.org/publicdomain/zero/1.0/

Ingested by tools/ingest-sfz.js from SynthBassLead 20200522.sfz.
Range 24-96.

Levels: loudest zone 1.8 dBFS as ingested; every zone given the same gain ×0.684 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
