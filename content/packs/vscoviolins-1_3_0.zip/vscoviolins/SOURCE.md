# vscoviolins

Violins. Source: https://github.com/sgossner/VSCO-2-CE

Layer v2. Roots are the file names plus 12 (VSCO writes middle C as C3): `A3` measures 441 Hz.

Ingested by tools/ingest-sfz.js from vscoviolins.sfz.
Range 55-91, tails cut at 7s.

Levels: loudest zone -15.0 dBFS as ingested; every zone given the same gain ×4.71 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.

1.1.0: every zone now loops while its note is held. The loop starts once the attack settles and ends late in the sustain where the level matches; the end is aligned in phase with the start, the seam crossfaded, and a quarter second of continuation follows it.

## 1.2.0 — one sample per semitone, G3 to G6

The app no longer speeds samples up or slows them down: every note from G3 to G6 has its
own sample, played at its own pitch. The 11 recorded notes (G3, A3, B3, D4, F#4, A4, C5,
E5, G5, B5, D6) are unchanged from 1.1.0, loops included. The other 26 were made from the
recording that played them before, pitch-shifted with Signalsmith Stretch (MIT licence,
https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch 0.3.1
wrapper), which keeps the recording's timing: the bow swell and vibrato arrive exactly as
recorded. Each was level-matched to its source recording and looped by the same method as
the recorded notes. The range now reaches G6 (E6 to G6 come from D6, up to five semitones).

| Note | Made from | Semitones |
|---|---|---|
| G#3 | G3 | +1 |
| A#3 | A3 | +1 |
| C4 | B3 | +1 |
| C#4 | D4 | -1 |
| D#4 | D4 | +1 |
| E4 | D4 | +2 |
| F4 | Fs4 | -1 |
| G4 | Fs4 | +1 |
| G#4 | A4 | -1 |
| A#4 | A4 | +1 |
| B4 | C5 | -1 |
| C#5 | C5 | +1 |
| D5 | C5 | +2 |
| D#5 | E5 | -1 |
| F5 | E5 | +1 |
| F#5 | G5 | -1 |
| G#5 | G5 | +1 |
| A5 | G5 | +2 |
| A#5 | B5 | -1 |
| C6 | B5 | +1 |
| C#6 | D6 | -1 |
| D#6 | D6 | +1 |
| E6 | D6 | +2 |
| F6 | D6 | +3 |
| F#6 | D6 | +4 |
| G6 | D6 | +5 |

## 1.3.0: attacks aligned and volume evened

The recordings start to speak at different speeds. Each note's quiet bow-start was trimmed, with a 10 ms fade-in, so every note reaches its speaking point (the mean of when it first comes within 24, 18 and 12 dB of its sustain) at the same moment after the note begins; the quickest tenth were left as recorded. Trims ranged from 0 to 119 ms; loops moved with them. Each note's gain was then set so its sustain loudness sits on a smooth line across the range, lowered just enough that no note would clip.
