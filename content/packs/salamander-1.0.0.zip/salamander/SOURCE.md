# salamander

Salamander Grand Piano V3 by Alexander Holm — a Yamaha C5, recorded at 48 kHz / 24-bit with two AKG C414s in AB about 12 cm above the strings, 16 velocity layers, sampled in minor thirds from the lowest A. This pack uses layer v10, the same as the preview. Files from https://github.com/sfzinstruments/SalamanderGrandPiano .

Layer v10 of 16. Names are at pitch.

Ingested by tools/ingest-sfz.js from salamander.sfz.
Range 21-108, tails cut at 5s.

Levels: loudest zone -9.1 dBFS as ingested; every zone given the same gain ×2.4 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
