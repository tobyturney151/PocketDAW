# Flute

From Versilian Studios' VSCO 2 Community Edition (CC0): flute, sustain without vibrato.
https://github.com/sgossner/VSCO-2-CE (`Woodwinds/Flute/susNV`)

Every note from C4 to C7 has its own sample, played at its own pitch.

**Layer.** The rule for these packs: the mf layer if there is one, otherwise the second loudest of three or more, or the louder of two. Here that is `v2`; notes that have no `v2` recording use their nearest layer (C4 `v3`, E4 `v3`, A4 `v3`, C5 `v3`, E5 `v3`, A5 `v3`, A6 `v3`, C7 `v1`). The first take (round robin) of each note is used.

**Recordings.** 10: C4, E4, A4, C5, E5, A5, C6, E6, A6, C7. Using the left microphone only: the two microphones are poorly correlated in these recordings (on some notes nearly opposite), so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Tuning.** Each recording's pitch was measured (cents: C4 0, E4 0, A4 0, C5 0, E5 0, A5 0, C6 0, E6 0, A6 0, C7 0) and corrected where 5 cents or more off. Finished notes measure 0 to +2 cents.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Made from | Semitones |
|---|---|---|
| C4 | C4 | recorded |
| C#4 | C4 | +1 |
| D4 | C4 | +2 |
| D#4 | E4 | -1 |
| E4 | E4 | recorded |
| F4 | E4 | +1 |
| F#4 | E4 | +2 |
| G4 | A4 | -2 |
| G#4 | A4 | -1 |
| A4 | A4 | recorded |
| A#4 | A4 | +1 |
| B4 | C5 | -1 |
| C5 | C5 | recorded |
| C#5 | C5 | +1 |
| D5 | C5 | +2 |
| D#5 | E5 | -1 |
| E5 | E5 | recorded |
| F5 | E5 | +1 |
| F#5 | E5 | +2 |
| G5 | A5 | -2 |
| G#5 | A5 | -1 |
| A5 | A5 | recorded |
| A#5 | A5 | +1 |
| B5 | C6 | -1 |
| C6 | C6 | recorded |
| C#6 | C6 | +1 |
| D6 | C6 | +2 |
| D#6 | E6 | -1 |
| E6 | E6 | recorded |
| F6 | E6 | +1 |
| F#6 | E6 | +2 |
| G6 | A6 | -2 |
| G#6 | A6 | -1 |
| A6 | A6 | recorded |
| A#6 | A6 | +1 |
| B6 | C7 | -1 |
| C7 | C7 | recorded |

**Loops.** Each recording loops while held, at points chosen for matching pitch, pitch direction, tone and level; the loop starts at least 0.5 s into the note and lasts at least 1 s; its end is aligned in phase with its start and the seam is crossfaded, with a quarter second of continuation after the loop end. Made notes reuse their recording's loop. Loops on the recordings (s): C4 1.76-7.90; E4 1.16-7.10; A4 1.44-7.54; C5 0.60-7.60; E5 2.64-7.04; A5 2.38-7.32; C6 1.30-7.50; E6 0.86-6.70; A6 1.12-6.99; C7 1.26-4.50.

**Attack.** Kept as recorded: each note starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, nothing trimmed. Notes speak 17-115 ms after they start.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s) across the range, and the line is set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level.
