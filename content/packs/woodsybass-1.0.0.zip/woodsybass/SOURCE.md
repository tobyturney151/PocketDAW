# woodsybass

Woodsy Bass — Sonic Pi sample `bass_woodsy_c`, https://freesound.org/people/ani_music/sounds/165322/.
Pitch, measured by harmonic-series fit over the whole sample and tracked over time: C2, 5 cents flat; left as recorded. Root C2, left as recorded (-5 cents). One sample played from A0 to G4 by resampling.

Ingested by tools/ingest-sfz.js from woodsybass.sfz.
Range 21-67, tails cut at 4s.

Levels: loudness-matched to Swag Bass G1; gain ×0.145, so it peaks at -16.5 dBFS.
