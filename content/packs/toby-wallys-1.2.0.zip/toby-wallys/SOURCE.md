# Toby Wallys (formerly Toby's Kit)

**Unlicensed. Toby Turney's own recordings, for Space Goat's own use only. Not CC0, not
dedicated to the public domain, no rights granted to anyone else.**

Toby's own kit, played by him, cut from Space Goat's multitrack sessions at Wally's
(Pro Tools, 48 kHz / 32-bit float). Twelve lanes.

Version 1.2, Toby's picks after listening to 1.0 and 1.1:
- **Hats are the two from 1.0**: one closed, one open. No soft hat lanes.
- **Each tom is one hit, the quieter stroke from 1.1.** The harder tom hits were dropped because
  they were flams or had other instruments bleeding in. Being the only tom sample now, each is
  levelled to the tom target (-4.5 dBFS) like the other kits' toms; play it softer with velocity.
- **Kick, snare and cowbell keep a loud and a soft lane.** Each pair shares one `gain`, so the
  soft lane plays at its real recorded level (7-13 dB under the loud one).
- **One crash and one ride.** The crash is right of centre in the overheads; the ride is the
  bigger cymbal on the left. Both are the big song-ending hits, the only cymbal hits that ring out
  alone, so the ride is a crashed ride rather than a tip "ping".

Hits were found by scanning every take for ones that ring out on their own (quiet close mic
before, no other drum at the same instant, nothing new before they decay); toms were checked by
pitch (rack ~120 Hz, floor ~72 Hz). Each sample starts 2 ms before its transient, is mono AAC at
44.1 kHz / 128 kbps, and has a short fade where it was cut.

| lane | midi | from (session, mics, time in take) | seconds | gain | processing |
|---|---|---|---|---|---|
| Crash | 49 | Let Me Go, OH.01_08, 386.737 s | 4.60 | 0.568 | overheads summed to mono, 250 Hz high-pass |
| Ride | 51 | Let Me Go, OH.07_17, 384.789 s | 5.55 | 0.498 | overheads summed to mono, 250 Hz high-pass |
| Hat Open | 46 | Let Me Go, HAT.06_15, 346.135 s | 0.44 | 0.51 | 450 Hz high-pass; a quiet snare stroke sits under it |
| Hat Closed | 42 | Let Me Go, HAT.13_26, 149.462 s | 0.23 | 0.53 | 300 Hz high-pass |
| Cowbell | 56 | Let Me Go, Cowbell_01, 41.097 s | 0.37 | 0.413 | 150 Hz high-pass; overdub track |
| Cowbell Soft | 29 | Let Me Go, Cowbell_03, 17.156 s | 0.46 | 0.413 | 150 Hz high-pass; overdub track |
| Snare | 38 | Let Me Go, SN T.01_08 + SN B.01_08, 197.644 s | 0.42 | 0.825 | top + bottom mics, bottom polarity-flipped, aligned and 8 dB under top; 60 Hz high-pass |
| Snare Soft | 40 | Nomad, SN T.03_07 + SN B.03_07, 86.788 s | 0.30 | 0.825 | top + bottom mics, bottom polarity-flipped, aligned and 8 dB under top; 60 Hz high-pass |
| Rack Tom | 50 | Let Me Go, T1.06_15, 83.545 s | 0.28 | 0.842 | 70 Hz high-pass; tail low-passed at 1.2 kHz from 40 ms |
| Floor Tom | 45 | Let Me Go, T2.06_15, 277.826 s | 0.72 | 0.858 | 40 Hz high-pass; tail low-passed at 1 kHz from 40 ms |
| Kick Soft | 35 | Let Me Go, KK In.07_17 + KK Out.07_17, 267.015 s | 0.58 | 0.943 | kick in + kick out (out low-passed 4 kHz, equal level); tail low-passed at 800 Hz from 30 ms |
| Kick | 36 | Nomad, KK In.02_06 + KK Out.02_06, 46.610 s | 0.58 | 0.943 | kick in + kick out (out low-passed 4 kHz, equal level); tail low-passed at 800 Hz from 30 ms |

Session files: `E:\Toby - Personal\Space Goat_Wallys Sessions\Space Goat\`.
