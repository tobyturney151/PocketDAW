# Clarinet

From Versilian Studios' VSCO 2 Community Edition (CC0): B♭ clarinet, sustain (long).
https://github.com/sgossner/VSCO-2-CE (`Woodwinds/Clarinet/susLong`)

Every note from D3 to F6 has its own sample, played at its own pitch.

**Layer.** The rule for these packs: the mf layer if there is one, otherwise the second loudest of three or more, or the louder of two. Here that is `v2`. The first take (round robin) of each note is used.

**Recordings.** 11: D3, F3, A#3, D4, F4, A#4, D5, F5, A#5, D6, F6. Using the left microphone only: the two microphones are poorly correlated in these recordings (on some notes nearly opposite), so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Refiled.** A file named for one note that plays another was filed where it sounds:

- DCClar_susLong_F#5_v2_rr1_sum.wav: named F#5, expected F#6, sounds F6 +1 c

**Tuning.** Each recording's pitch was measured (cents: D3 +3, F3 +1, A#3 +1, D4 +2, F4 +5, A#4 +2, D5 +2, F5 +4, A#5 +3, D6 +6, F6 +1) and corrected where 5 cents or more off. Finished notes measure 0 to +4 cents.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Made from | Semitones |
|---|---|---|
| D3 | D3 | recorded |
| D#3 | D3 | +1 |
| E3 | F3 | -1 |
| F3 | F3 | recorded |
| F#3 | F3 | +1 |
| G3 | F3 | +2 |
| G#3 | A#3 | -2 |
| A3 | A#3 | -1 |
| A#3 | A#3 | recorded |
| B3 | A#3 | +1 |
| C4 | A#3 | +2 |
| C#4 | D4 | -1 |
| D4 | D4 | recorded |
| D#4 | D4 | +1 |
| E4 | F4 | -1 |
| F4 | F4 | recorded |
| F#4 | F4 | +1 |
| G4 | F4 | +2 |
| G#4 | A#4 | -2 |
| A4 | A#4 | -1 |
| A#4 | A#4 | recorded |
| B4 | A#4 | +1 |
| C5 | A#4 | +2 |
| C#5 | D5 | -1 |
| D5 | D5 | recorded |
| D#5 | D5 | +1 |
| E5 | F5 | -1 |
| F5 | F5 | recorded |
| F#5 | F5 | +1 |
| G5 | F5 | +2 |
| G#5 | A#5 | -2 |
| A5 | A#5 | -1 |
| A#5 | A#5 | recorded |
| B5 | A#5 | +1 |
| C6 | A#5 | +2 |
| C#6 | D6 | -1 |
| D6 | D6 | recorded |
| D#6 | D6 | +1 |
| E6 | F6 | -1 |
| F6 | F6 | recorded |

**Loops.** Each recording loops while held, at points chosen for matching pitch, pitch direction, tone and level; the loop starts at least 0.5 s into the note and lasts at least 1 s; its end is aligned in phase with its start and the seam is crossfaded, with a quarter second of continuation after the loop end. Made notes reuse their recording's loop. Loops on the recordings (s): D3 1.28-7.34; F3 0.88-6.70; A#3 1.20-7.64; D4 0.52-7.36; F4 2.50-7.94; A#4 2.98-7.94; D5 1.92-6.04; F5 1.84-7.90; A#5 3.00-7.90; D6 0.50-7.22; F6 1.54-5.55.

**Attack.** Kept as recorded: each note starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, nothing trimmed. Notes speak 28-215 ms after they start.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s) across the range, and the line is set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level.
