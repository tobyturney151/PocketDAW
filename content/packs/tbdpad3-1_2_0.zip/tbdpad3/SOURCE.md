# tbdpad3

TBD Minor Pad 3 — Sonic Pi sample `tbd_pad_3`, donated to Sonic Pi by The Black Dog.
D4 with an E♭ a semitone above; the D3 energy is a separate sub-layer with no harmonics of its own. Retuned -6 cents to D4. One sample played an octave either side, D3 to D5, so the sound is never stretched far.

Ingested by tools/ingest-sfz.js from tbdpad3.sfz.
Range 50-74, tails cut at 4s.

Levels: loudest peak to -1.5 dBFS; gain ×1.581.

1.1.0: every zone now loops while its note is held. The loop starts once the attack settles and ends late in the sustain where the level matches; the end is aligned in phase with the start, the seam crossfaded, and a quarter second of continuation follows it.

## 1.2.0: one sample per semitone

The app no longer speeds samples up or slows them down: every note from D3 to D5 has its own sample, played at its own pitch. The recorded note (D4) is unchanged. The other 24 were made from the recording that played them before, pitch-shifted with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch 0.3.1 wrapper), which keeps the recording's timing: attack, vibrato, tremolo, loops and decay arrive as recorded. Each is level-matched to its source recording. Looping notes reuse their source's loop, with the same start, end and crossfade, lined up with the waveform at the new pitch.

| Note | Made from | Semitones |
|---|---|---|
| D3 | D4 | -12 |
| D#3 | D4 | -11 |
| E3 | D4 | -10 |
| F3 | D4 | -9 |
| F#3 | D4 | -8 |
| G3 | D4 | -7 |
| G#3 | D4 | -6 |
| A3 | D4 | -5 |
| A#3 | D4 | -4 |
| B3 | D4 | -3 |
| C4 | D4 | -2 |
| C#4 | D4 | -1 |
| D#4 | D4 | +1 |
| E4 | D4 | +2 |
| F4 | D4 | +3 |
| F#4 | D4 | +4 |
| G4 | D4 | +5 |
| G#4 | D4 | +6 |
| A4 | D4 | +7 |
| A#4 | D4 | +8 |
| B4 | D4 | +9 |
| C5 | D4 | +10 |
| C#5 | D4 | +11 |
| D5 | D4 | +12 |
