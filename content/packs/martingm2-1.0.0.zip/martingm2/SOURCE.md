# martingm2

MartinGM2 — 026-Acoustic Guitar (steel) from the Discord SFZ GM Bank.

// GM Acoustic Guitar
// 2017 Martin HD28 Vintage Series
// Author: Jeff Learman, for Kinwie's Discord SFZ GM: https://github.com/kinwie/Discord-SFZ-GM-Bank
// License: Creative Commons CC0

Ingested by tools/ingest-sfz.js from martingm2.sfz.
Range 35-88, tails cut at 4s.

Levels: loudest zone -0.8 dBFS as ingested; every zone given the same gain ×0.922 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
