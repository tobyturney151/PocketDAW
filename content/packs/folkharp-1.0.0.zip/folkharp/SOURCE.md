# folkharp

Folk Harp. Source: https://github.com/sgossner/VCSL

Normal plucks, layer v3. Roots are the file names plus 12.

Ingested by tools/ingest-sfz.js from folkharp.sfz.
Range 34-94, tails cut at 5s.

Levels: loudest zone -5.4 dBFS as ingested; every zone given the same gain ×1.574 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
