# Flute

From Versilian Studios' VSCO 2 Community Edition (CC0): flute. Each note starts as its staccato recording and is joined into its sustain recording, which loops for as long as the note is held: short notes keep the tongued start, held notes carry on. C4-F4, below the staccato recordings, play the sustain alone.
https://github.com/sgossner/VSCO-2-CE (staccato `Woodwinds/Flute/stac`, sustain `Woodwinds/Flute/susNV`)

Every note from C4 to C7 has its own sample, played at its own pitch.

**Layers.** Staccato, layer v1 (soft, of v1-v4). Sustain without vibrato, layer v1 (soft, of v1-v3). The staccato layer is the one whose tone best matches the sustain at the joint. The first take (round robin) of each note is used.

**Recordings.** Staccato, 8: A4, C5, E5, A5, C6, E6, A6, C7. Sustain, 10: C4, E4, A4, C5, E5, A5, C6, E6, A6, C7. Using the left microphone only: the two microphones are poorly correlated in these recordings, so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Tuning.** Each recording's pitch was measured (cents, staccato: A4 0, C5 -5, E5 0, A5 -4, C6 +3, E6 +6, A6 +2, C7 +4; sustain: all within 0.1 cent) and corrected where 5 cents or more off.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass. Staccatos reach up to 3 semitones past their highest and lowest recordings.

| Note | Staccato from | Sustain from | Joint (ms) | Joins sustain at (s) | Loop (s) |
|---|---|---|---|---|---|
| C4 | — (sustain alone) | C4 | — | — | 1.02-7.79 |
| C#4 | — (sustain alone) | C4 (+1) | — | — | 1.01-7.78 |
| D4 | — (sustain alone) | C4 (+2) | — | — | 1.02-7.79 |
| D#4 | — (sustain alone) | E4 (-1) | — | — | 1.45-7.76 |
| E4 | — (sustain alone) | E4 | — | — | 1.45-7.75 |
| F4 | — (sustain alone) | E4 (+1) | — | — | 1.45-7.76 |
| F#4 | A4 (-3) | E4 (+2) | 50-72 | 0.41 | 1.12-7.43 |
| G4 | A4 (-2) | A4 (-2) | 50-72 | 0.85 | 1.18-6.85 |
| G#4 | A4 (-1) | A4 (-1) | 50-72 | 0.85 | 1.22-6.86 |
| A4 | A4 | A4 | 50-72 | 0.85 | 1.30-6.52 |
| A#4 | A4 (+1) | A4 (+1) | 50-72 | 0.85 | 1.18-6.83 |
| B4 | C5 (-1) | C5 (-1) | 75-97 | 0.54 | 1.93-7.20 |
| C5 | C5 | C5 | 80-102 | 0.30 | 2.18-7.45 |
| C#5 | C5 (+1) | C5 (+1) | 75-97 | 0.54 | 1.94-7.18 |
| D5 | C5 (+2) | C5 (+2) | 75-97 | 0.54 | 1.94-7.18 |
| D#5 | E5 (-1) | E5 (-1) | 80-102 | 0.28 | 0.90-7.45 |
| E5 | E5 | E5 | 80-102 | 0.28 | 0.90-7.45 |
| F5 | E5 (+1) | E5 (+1) | 80-102 | 0.28 | 0.90-7.46 |
| F#5 | E5 (+2) | E5 (+2) | 80-102 | 0.27 | 0.91-7.47 |
| G5 | A5 (-2) | A5 (-2) | 40-62 | 0.14 | 0.80-7.43 |
| G#5 | A5 (-1) | A5 (-1) | 40-62 | 0.14 | 0.80-7.43 |
| A5 | A5 | A5 | 40-62 | 0.15 | 0.79-7.43 |
| A#5 | A5 (+1) | A5 (+1) | 40-62 | 0.14 | 0.80-7.44 |
| B5 | C6 (-1) | C6 (-1) | 75-97 | 1.12 | 0.60-4.75 |
| C6 | C6 | C6 | 85-107 | 1.17 | 0.86-4.64 |
| C#6 | C6 (+1) | C6 (+1) | 80-102 | 1.12 | 1.32-4.13 |
| D6 | C6 (+2) | C6 (+2) | 80-102 | 1.12 | 0.72-4.88 |
| D#6 | E6 (-1) | E6 (-1) | 50-72 | 0.48 | 0.60-7.72 |
| E6 | E6 | E6 | 50-72 | 0.48 | 0.60-7.75 |
| F6 | E6 (+1) | E6 (+1) | 50-72 | 0.48 | 0.60-7.71 |
| F#6 | E6 (+2) | E6 (+2) | 50-72 | 0.47 | 0.60-7.72 |
| G6 | A6 (-2) | A6 (-2) | 55-77 | 0.46 | 0.50-7.78 |
| G#6 | A6 (-1) | A6 (-1) | 55-77 | 0.48 | 0.56-7.58 |
| A6 | A6 | A6 | 55-77 | 0.49 | 0.50-7.59 |
| A#6 | A6 (+1) | A6 (+1) | 55-77 | 0.46 | 0.50-7.77 |
| B6 | C7 (-1) | C7 (-1) | 55-77 | 0.66 | 0.66-3.91 |
| C7 | C7 | C7 | 55-77 | 0.50 | 0.82-4.06 |

**The joint.** For each note:

1. The staccato is left just after its peak, so its tongued start and accent stay whole, and before it has faded 2 dB (here 40-107 ms into the note).
2. The sustain is joined where it has settled (not still swelling in or wavering), at the point that best matches the staccato's tone and pitch.
3. Where the staccato at the joint is 5 cents or more off the sustain, the staccato is retuned to it by varispeed, which keeps the attack crisp (10 of 31 notes, up to 8 cents). Joined notes match within 5 cents.
4. The sustain is moved by up to one cycle of the note to where the two waveforms line up best, and set to the staccato's level there.
5. They are crossfaded over three cycles of the note (22-40 ms) with gains that hold the level steady however well the waveforms line up. Measured across the joint, every note's level stays within -1.0 to +0.4 dB.
6. Tone glide: the sustain comes in with the staccato's tone, harmonic by harmonic, and relaxes to its own over 150 ms, so the brightness of the attack settles as in one played note. The glide changes tone only: each moment keeps its own loudness.
7. Loops: the sustain recording's own loop (pitch, tone and level matched, end aligned in phase, seam crossfaded) is kept where it still starts 0.5 s or later; otherwise a new loop is found the same way (16 of 37 notes). Every loop starts at least 0.5 s in and lasts at least 1 s, with a quarter second of continuation after the loop end.

**Attack and breath.** The staccato recordings carry more air than the sustains, which in a joined note arrives with every start and then vanishes. Two things take it out of the staccato part: each staccato starts 10 ms before its tone comes within 20 dB of its peak, skipping the air before the note speaks, and between the harmonics the staccato is turned down 18 dB (short-time spectrum) while the harmonics pass untouched. Breath sitting right on a harmonic can't be separated and stays. A 2 ms fade-in; the tongued start itself is kept. The notes played by the sustain alone (C4-F4) start 10 ms before their tone is within 20 dB of its held level.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s, K-weighted) across the range, set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

**Release.** 0.12 s, so short notes stop near the staccato's own length.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level. Built from the original recordings.

## 1.1.0

Now a hybrid: each note starts as the staccato recording (layer v1, with its breath lowered and its lead-in trimmed) and is joined into the sustain, which loops. The sustain is now the soft layer v1 (1.0.0 used v2 and v3). C4-F4, below the staccato recordings, play the sustain alone with its lead-in trimmed. Release 0.12 s (was 0.25 s), attack ramp 2 ms (was 5 ms). It also takes over from the Flute Staccato pack, which is retired.

## 1.0.0

First version: sustain without vibrato, layers v2/v3.
