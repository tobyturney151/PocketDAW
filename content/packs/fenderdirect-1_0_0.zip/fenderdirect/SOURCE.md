# Fender - Direct

From Electric Guitar FSBS (direct), version 2022-09-11, by FreePats (freepats.zenvoid.org); CC0 (its README, and its LICENSE.txt is the CC0 1.0 legal code).
https://github.com/freepats/electric-guitar-FSBS-direct

**The recordings.** A Fender electric (basic model) sampled direct through its bridge pickup: the raw signal, with no amplifier or effects; 19 notes from C2 to C#6, three or four takes each and a softer layer on some, mono, 48 kHz, 24-bit. This pack uses the normal (not soft) layer, first take (01): the recordings the strummed Guitar Previews played.

**Notes.** 19 recordings, C2 to C#6; the pack plays C2 to D#6. Each recording plays the notes nearest it, sped up or slowed down by at most 2 semitones, as the source's own sampler mapping does.

Each note starts 5 ms before its first sound (40 dB below its peak) with a 2 ms fade-in. It ends where it has fallen 60 dB (30 ms fade), or at 6 s with a 1 s fade if it is still ringing then, or at the end of the recording with a 0.3 s fade if that comes first (6 fall 60 dB, 13 reach 6 s). Notes last 3.0–6.0 s.

**Tuning.** Each recording measured (a harmonic fit, then the median of a pitch track over 0.05–0.8 s). 3 of the 19 were 5 cents or more off and were retuned by varispeed (resampled, which also changes their length by under 2%). The finished files measure -2 to +4 cents.

| Recording | Plays | Measured (cents) | Retuned (cents) | Length | Ends |
|---|---|---|---|---|---|
| C2 | C2–D2 | +6.6 | -6.6 | 6.0 s | 6 s, faded |
| E2 | D#2–E2 | +4.1 | – | 6.0 s | 6 s, faded |
| F2 | F2–G2 | +3.0 | – | 6.0 s | 6 s, faded |
| A2 | G#2–A#2 | +9.7 | -9.7 | 6.0 s | 6 s, faded |
| C3 | B2–C#3 | +2.5 | – | 6.0 s | 6 s, faded |
| D3 | D3–D#3 | -0.2 | – | 6.0 s | 6 s, faded |
| E3 | E3–F3 | +5.9 | -5.9 | 6.0 s | 6 s, faded |
| G3 | F#3–A3 | -2.1 | – | 6.0 s | 6 s, faded |
| B3 | A#3–C4 | +0.4 | – | 6.0 s | 6 s, faded |
| C#4 | C#4–D4 | +0.1 | – | 6.0 s | 6 s, faded |
| E4 | D#4–F4 | -1.0 | – | 6.0 s | 6 s, faded |
| G4 | F#4–A4 | +0.5 | – | 6.0 s | 6 s, faded |
| B4 | A#4–B4 | +0.7 | – | 5.2 s | fell 60 dB |
| C5 | C5–C#5 | -0.6 | – | 5.8 s | fell 60 dB |
| D5 | D5–D#5 | +3.8 | – | 4.5 s | fell 60 dB |
| F5 | E5–F#5 | +2.4 | – | 4.2 s | fell 60 dB |
| G#5 | G5–A5 | +0.2 | – | 6.0 s | 6 s, faded |
| A#5 | A#5–B5 | +3.4 | – | 4.6 s | fell 60 dB |
| C#6 | C6–D#6 | -1.7 | – | 3.0 s | fell 60 dB |

**Volume.** Set by the method of the volume audit of 14 October: every note in the range played as the app plays it and measured for listening loudness (ISO 532-1 Zwicker, the loudest moment), each recording's gain set so its notes match, and the pack set to the level of jRhodes and the other pitched packs. The notes measure 70.7 phon (median), within 1.5 phon of one another. At full velocity the loudest note peaks at 0.31 of full scale before the track and master gains.

**Strumming.** Like the rest of the Guitar category, the manifest sets `strum`: notes that start together are one stroke across the strings, down and up strokes strictly alternating; a downstroke goes low to high in 24 ms and an upstroke high to low in 18 ms however many strings it has, the upstroke at 82% of the velocity, each further string a little softer (0.96 down, 0.9 up). Single notes alternate the same way. The app needs the strum update for this; before it, the pack plays chords all at once.

**Envelope.** One-shots, as in the other Guitar packs: attack ramp 2 ms, release 0.4 s, 8 voices, headroom for 4 at once.

Files are mono, 44.1 kHz AAC at 160 kb/s (16 notes) and 192 kb/s (3 notes), each peak-normalised; the catalog gain restores its level. Each file takes the lowest of those rates at which it decodes cleanly (peak within 0.95 of full scale, waveform error at least 20 dB down).

## 1.0.0

First version.
