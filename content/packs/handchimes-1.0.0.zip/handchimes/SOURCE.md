# handchimes

Hand Chimes. Source: https://github.com/sgossner/VCSL

Roots are the file names plus 12: `C4` measures 523.5 Hz.

Ingested by tools/ingest-sfz.js from handchimes.sfz.
Range 60-96, tails cut at 5s.

Levels: loudest zone -13.9 dBFS as ingested; every zone given the same gain ×4.16 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
