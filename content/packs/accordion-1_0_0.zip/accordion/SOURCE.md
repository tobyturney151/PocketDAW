# Accordion

From hammondman's "Accordion wav samples" on Freesound (pack 18842), every sound released under Creative Commons 0.
https://freesound.org/people/hammondman/packs/18842/

Every note from A3 to E6 has its own sample, played at its own pitch.

**Recordings.** 15, one take each, mono, 32 kHz (resampled to 44.1 kHz). The file names are written an octave below how the notes sound (each one's fundamental sits an octave above its name, checked by measuring every note), so each was filed an octave up:

| Plays | File | Freesound page |
|---|---|---|
| A3 | `333714__hammondman__a2.wav` | https://freesound.org/s/333714/ |
| C4 | `333711__hammondman__c3.wav` | https://freesound.org/s/333711/ |
| C#4 | `333716__hammondman__cdz3.wav` | https://freesound.org/s/333716/ |
| E4 | `333720__hammondman__e3.wav` | https://freesound.org/s/333720/ |
| F#4 | `333723__hammondman__fdz3.wav` | https://freesound.org/s/333723/ |
| G#4 | `333724__hammondman__gdz3.wav` | https://freesound.org/s/333724/ |
| A#4 | `333712__hammondman__adz3.wav` | https://freesound.org/s/333712/ |
| C5 | `333718__hammondman__c4.wav` | https://freesound.org/s/333718/ |
| D5 | `333715__hammondman__d4.wav` | https://freesound.org/s/333715/ |
| E5 | `333719__hammondman__e4.wav` | https://freesound.org/s/333719/ |
| F5 | `333721__hammondman__f4.wav` | https://freesound.org/s/333721/ |
| G5 | `333725__hammondman__g4.wav` | https://freesound.org/s/333725/ |
| A5 | `333713__hammondman__a4.wav` | https://freesound.org/s/333713/ |
| C6 | `333717__hammondman__c5.wav` | https://freesound.org/s/333717/ |
| E6 | `333722__hammondman__e5.wav` | https://freesound.org/s/333722/ |

**Tuning.** Each recording's pitch was measured (cents: A3 +11, C4 +9, C#4 +7, E4 +15, F#4 +3, G#4 +8, A#4 +6, C5 +8, D5 +7, E5 +7, F5 +9, G5 +8, A5 +9, C6 +7, E6 +7) and corrected where 5 cents or more off; every recording was a little sharp.

**Lengthened.** The recordings last only 1.4-2.3 s and their level sags as the bellows ease off, too short for a loop that starts after 0.5 s and lasts at least 1 s. So each one's level is held steady from 0.25 s on, and its body (after 0.30 s) is lengthened with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch) to make the note 3.4 s long, timing changed and pitch kept: A3 x2.86, C4 x1.84, C#4 x2.43, E4 x1.83, F#4 x1.84, G#4 x2.11, A#4 x1.87, C5 x2.06, D5 x1.83, E5 x2.07, F5 x2.40, G5 x2.06, A5 x2.91, C6 x2.11, E6 x1.57. The untouched attack joins the lengthened body with a 50 ms crossfade ending at 0.35 s, at the point where the two waveforms line up best.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Made from | Semitones |
|---|---|---|
| A3 | A3 | recorded |
| A#3 | A3 | +1 |
| B3 | C4 | -1 |
| C4 | C4 | recorded |
| C#4 | C#4 | recorded |
| D4 | C#4 | +1 |
| D#4 | E4 | -1 |
| E4 | E4 | recorded |
| F4 | E4 | +1 |
| F#4 | F#4 | recorded |
| G4 | F#4 | +1 |
| G#4 | G#4 | recorded |
| A4 | G#4 | +1 |
| A#4 | A#4 | recorded |
| B4 | A#4 | +1 |
| C5 | C5 | recorded |
| C#5 | C5 | +1 |
| D5 | D5 | recorded |
| D#5 | D5 | +1 |
| E5 | E5 | recorded |
| F5 | F5 | recorded |
| F#5 | F5 | +1 |
| G5 | G5 | recorded |
| G#5 | G5 | +1 |
| A5 | A5 | recorded |
| A#5 | A5 | +1 |
| B5 | C6 | -1 |
| C6 | C6 | recorded |
| C#6 | C6 | +1 |
| D6 | C6 | +2 |
| D#6 | E6 | -1 |
| E6 | E6 | recorded |

**Loops.** Each note loops while held, at points chosen for matching pitch, pitch direction, tone and level; the loop starts at least 0.5 s in and lasts at least 1 s, its end aligned in phase with its start and the seam crossfaded, with a quarter second of continuation after it. Loops (s): A3 0.58-3.05; A#3 0.58-3.07; B3 0.56-3.03; C4 0.56-3.02; C#4 0.58-2.97; D4 0.58-2.97; D#4 0.58-3.30; E4 0.58-3.29; F4 0.58-3.31; F#4 0.52-2.94; G4 0.52-2.94; G#4 0.90-2.96; A4 0.90-2.95; A#4 0.62-3.25; B4 0.62-3.25; C5 0.60-3.08; C#5 0.60-3.10; D5 0.62-3.31; D#5 0.62-3.31; E5 0.70-2.97; F5 0.62-3.07; F#5 0.62-3.07; G5 1.06-3.03; G#5 1.06-3.04; A5 0.52-3.17; A#5 0.52-3.19; B5 0.62-2.93; C6 0.62-2.93; C#6 0.62-2.93; D6 0.62-2.93; D#6 0.50-3.25; E6 0.50-3.26.

**Attack.** Kept as recorded: each note starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in. Notes speak 2-12 ms after they start.

**Volume.** Every note is set to the same listening loudness (Zwicker, ISO 532-1, held part 0.3-1.3 s), and the pack plays at the same level as the Violins pack in the app (headroom for 4 voices included). Nothing clips.

**Envelope.** Attack ramp 5 ms, release 0.25 s.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level. Built from the original recordings.

## 1.0.0

First version.
