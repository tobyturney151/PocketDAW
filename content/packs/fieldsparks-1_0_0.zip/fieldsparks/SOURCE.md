# Fields & Parks

Open fields in the Scottish Highlands and St Stephen's Green, Dublin. Every lane loops while its note is held and stops when the note ends.

Source: https://signaturesounds.org/

Ingested by `tools/ingest-drumkit.js`: one file per lane, trailing silence trimmed,
levels untouched, mixed to mono and encoded to AAC. The lane table in `lanes.json`
records which file each lane came from; re-run the tool to swap any of them.

| lane | file | from | seconds | peak dB | rms dB |
|---|---|---|---|---|---|
| Field 1 | fieldsparks/36-field1.m4a | 36-field1.flac | 10.750 | -31.9 | -44.8 |
| Field 2 | fieldsparks/37-field2.m4a | 37-field2.flac | 11.210 | -32.5 | -45.1 |
| Field 3 | fieldsparks/38-field3.m4a | 38-field3.flac | 10.150 | -31.9 | -44.7 |
| Field 4 | fieldsparks/39-field4.m4a | 39-field4.flac | 11.010 | -27.6 | -43.5 |
| Field 5 | fieldsparks/40-field5.m4a | 40-field5.flac | 9.870 | -28.9 | -43.4 |
| Field 6 | fieldsparks/41-field6.m4a | 41-field6.flac | 11.110 | -23.6 | -43.4 |
| Park 1 | fieldsparks/42-park1.m4a | 42-park1.flac | 11.190 | -24.7 | -45.4 |
| Park 2 | fieldsparks/43-park2.m4a | 43-park2.flac | 10.190 | -34.1 | -47.9 |
| Park 3 | fieldsparks/44-park3.m4a | 44-park3.flac | 11.190 | -35.6 | -48.2 |
| Park 4 | fieldsparks/45-park4.m4a | 45-park4.flac | 10.630 | -34.8 | -48.7 |
| Park 5 | fieldsparks/46-park5.m4a | 46-park5.flac | 10.570 | -30.0 | -47.6 |

## Lanes

| MIDI | Lane | Source pack | Recording | Excerpt from | Loop | Level |
|---|---|---|---|---|---|---|
| 36 | Field 1 | [Open Fields (Scottish Highlands)](https://signaturesounds.org/) | Audio 1.wav | 48.8 s | 1.28–10.50 s | ×12.16 |
| 37 | Field 2 | [Open Fields (Scottish Highlands)](https://signaturesounds.org/) | Audio 3.wav | 45.2 s | 1.12–10.96 s | ×12.16 |
| 38 | Field 3 | [Open Fields (Scottish Highlands)](https://signaturesounds.org/) | Audio 7.wav | 6.5 s | 0.96–9.90 s | ×11.61 |
| 39 | Field 4 | [Open Fields (Scottish Highlands)](https://signaturesounds.org/) | Audio 12.wav | 39.8 s | 1.14–10.76 s | ×9.89 |
| 40 | Field 5 | [Open Fields (Scottish Highlands)](https://signaturesounds.org/) | Audio 4.wav | 9.0 s | 1.52–9.62 s | ×8.91 |
| 41 | Field 6 | [Open Fields (Scottish Highlands)](https://signaturesounds.org/) | Audio 5.wav | 11.2 s | 1.56–10.86 s | ×8.51 |
| 42 | Park 1 | [St Stephen's Green](https://signaturesounds.org/) | St_Stephen's_Green_Ambiance_Dublin_03.wav | 68.0 s | 0.94–10.94 s | ×11.35 |
| 43 | Park 2 | [St Stephen's Green](https://signaturesounds.org/) | St_Stephen's_Green_Ambiance_Dublin_02.wav | 45.8 s | 1.56–9.94 s | ×15.31 |
| 44 | Park 3 | [St Stephen's Green](https://signaturesounds.org/) | St_Stephen's_Green_Ambiance_Dublin_04.wav | 28.0 s | 2.00–10.94 s | ×15.85 |
| 45 | Park 4 | [St Stephen's Green](https://signaturesounds.org/) | St_Stephen's_Green_Ambiance_Dublin_Ireland_2.WAV | 113.2 s | 1.66–10.38 s | ×16.03 |
| 46 | Park 5 | [St Stephen's Green](https://signaturesounds.org/) | St_Stephen's_Green_Ambiance_Dublin_01.wav | 25.5 s | 1.26–10.32 s | ×14.29 |

Each excerpt is the steadiest stretch of about 11.5 s in its recording's first two minutes; recordings were picked from each source pack for steadiness, then spread across brightness so lanes differ. Loop seams avoid sudden sounds in both the high band and the full band, and match background level; the last 0.35 s before each loop end is crossfaded into the 0.35 s before its start, with a quarter second of continuation after the end. Recordings whose channels partly cancel when summed use their stronger channel. Levels: -26 LUFS over each loop, peaks under -1 dBFS.
