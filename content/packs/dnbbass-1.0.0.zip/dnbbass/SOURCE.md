# dnbbass

DnB Bass — Sonic Pi sample `bass_dnb_f`, https://freesound.org/people/Exsomniel/sounds/206134/.
Pitch, measured by harmonic-series fit over the whole sample and tracked over time: F1, about 10 cents flat, with a strong F2 partial. Root F1, retuned +10 cents to F1. One sample played from A0 to G4 by resampling.

Ingested by tools/ingest-sfz.js from dnbbass.sfz.
Range 21-67, tails cut at 2s.

Levels: loudness-matched to Swag Bass G1; gain ×0.314, so it peaks at -15.4 dBFS.
