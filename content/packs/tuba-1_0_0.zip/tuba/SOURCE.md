# Tuba

From Versilian Studios' VSCO 2 Community Edition (CC0): tuba, sustain.
https://github.com/sgossner/VSCO-2-CE (`Brass/Tuba/sus`)

Every note from F1 to D4 has its own sample, played at its own pitch.

**Layer.** The rule for these packs: the mf layer if there is one, otherwise the second loudest of three or more, or the louder of two. Here that is `v2`; notes that have no `v2` recording use their nearest layer (F1 `v1`, D4 `v1`). The first take (round robin) of each note is used.

**Recordings.** 9: F1, A#1, D#2, F2, A#2, D3, F3, A#3, D4. Using the right microphone only: the two microphones are poorly correlated in these recordings (on some notes nearly opposite), so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Tuning.** Each recording's pitch was measured (cents: F1 -14, A#1 -1, D#2 0, F2 +1, A#2 -1, D3 -6, F3 -5, A#3 +6, D4 -2) and corrected where 5 cents or more off. Finished notes measure -5 to +5 cents.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Made from | Semitones |
|---|---|---|
| F1 | F1 | recorded |
| F#1 | F1 | +1 |
| G1 | F1 | +2 |
| G#1 | A#1 | -2 |
| A1 | A#1 | -1 |
| A#1 | A#1 | recorded |
| B1 | A#1 | +1 |
| C2 | A#1 | +2 |
| C#2 | D#2 | -2 |
| D2 | D#2 | -1 |
| D#2 | D#2 | recorded |
| E2 | D#2 | +1 |
| F2 | F2 | recorded |
| F#2 | F2 | +1 |
| G2 | F2 | +2 |
| G#2 | A#2 | -2 |
| A2 | A#2 | -1 |
| A#2 | A#2 | recorded |
| B2 | A#2 | +1 |
| C3 | A#2 | +2 |
| C#3 | D3 | -1 |
| D3 | D3 | recorded |
| D#3 | D3 | +1 |
| E3 | F3 | -1 |
| F3 | F3 | recorded |
| F#3 | F3 | +1 |
| G3 | F3 | +2 |
| G#3 | A#3 | -2 |
| A3 | A#3 | -1 |
| A#3 | A#3 | recorded |
| B3 | A#3 | +1 |
| C4 | A#3 | +2 |
| C#4 | D4 | -1 |
| D4 | D4 | recorded |

**Loops.** Each recording loops while held, at points chosen for matching pitch, pitch direction, tone and level; the loop starts at least 0.5 s into the note and lasts at least 1 s; its end is aligned in phase with its start and the seam is crossfaded, with a quarter second of continuation after the loop end. Made notes reuse their recording's loop. Loops on the recordings (s): F1 1.08-3.04; A#1 0.98-5.90; D#2 2.48-4.89; F2 0.78-3.26; A#2 1.86-6.16; D3 2.28-7.96; F3 2.74-6.36; A#3 3.00-7.92; D4 0.78-6.66.

**Attack.** Kept as recorded: each note starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, nothing trimmed. Notes speak 0-42 ms after they start.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s) across the range, and the line is set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level.
