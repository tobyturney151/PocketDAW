# Trumpet

From Versilian Studios' VSCO 2 Community Edition (CC0): trumpet, sustain.
https://github.com/sgossner/VSCO-2-CE (`Brass/Trumpet/sus`)

Every note from F3 to C6 has its own sample, played at its own pitch.

**Layer.** The soft layer (v1 of v1 and v3), chosen by listening. The first take (round robin) of each note is used.

**Recordings.** 10: F3, A3, C4, D#4, G4, A#4, D5, F5, A5, C6. Using the left microphone only: the two microphones are poorly correlated in these recordings (on some notes nearly opposite), so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Tuning.** Each recording's pitch was measured (cents: F3 +2, A3 -2, C4 -4, D#4 +1, G4 +8, A#4 +2, D5 0, F5 +2, A5 -3, C6 0) and corrected where 5 cents or more off. Finished notes measure -4 to +3 cents.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Made from | Semitones |
|---|---|---|
| F3 | F3 | recorded |
| F#3 | F3 | +1 |
| G3 | F3 | +2 |
| G#3 | A3 | -1 |
| A3 | A3 | recorded |
| A#3 | A3 | +1 |
| B3 | C4 | -1 |
| C4 | C4 | recorded |
| C#4 | C4 | +1 |
| D4 | D#4 | -1 |
| D#4 | D#4 | recorded |
| E4 | D#4 | +1 |
| F4 | D#4 | +2 |
| F#4 | G4 | -1 |
| G4 | G4 | recorded |
| G#4 | G4 | +1 |
| A4 | A#4 | -1 |
| A#4 | A#4 | recorded |
| B4 | A#4 | +1 |
| C5 | A#4 | +2 |
| C#5 | D5 | -1 |
| D5 | D5 | recorded |
| D#5 | D5 | +1 |
| E5 | F5 | -1 |
| F5 | F5 | recorded |
| F#5 | F5 | +1 |
| G5 | F5 | +2 |
| G#5 | A5 | -1 |
| A5 | A5 | recorded |
| A#5 | A5 | +1 |
| B5 | C6 | -1 |
| C6 | C6 | recorded |

**Loops.** Each recording loops while held, at points chosen for matching pitch, pitch direction, tone and level; the loop starts at least 0.5 s into the note and lasts at least 1 s; its end is aligned in phase with its start and the seam is crossfaded, with a quarter second of continuation after the loop end. Made notes reuse their recording's loop. Loops on the recordings (s): F3 1.54-7.70; A3 1.06-7.68; C4 2.02-7.52; D#4 0.54-7.72; G4 2.38-7.74; A#4 1.32-7.32; D5 2.50-7.20; F5 0.70-6.82; A5 2.56-7.98; C6 2.68-7.20.

**Attack.** Kept as recorded: each note starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, nothing trimmed. Notes speak 2-18 ms after they start.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s) across the range, and the line is set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level.

## 1.1.0

Rebuilt from the soft layer (v1 of v1 and v3); 1.0.0 used v3, the louder of two.
