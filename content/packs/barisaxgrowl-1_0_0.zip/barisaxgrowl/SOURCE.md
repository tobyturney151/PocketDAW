# Bari Sax Growl

From Karoryfer Samples' Bear Sax, a 1926 Conn baritone (CC0): growl.
https://github.com/sfzinstruments/karoryfer.bear-sax (`Samples (growl)`)

Every note from G#2 to B3 has its own sample, played at its own pitch.

**Layer.** The growl samples have one layer; the first of each pair of takes is used. 

**Recordings.** 14: G#2, A2, A#2, B2, C3, C#3, D3, D#3, F3, F#3, G3, G#3, A3, B3. Using the mono recording.

**Growl pitches.** Bear Sax's own mapping plays each growl sample about a fifth below the pitch it actually sounds (the D2 key's growl sounds A2, for example). Each was measured and filed where it sounds:

- growl1_rr1.wav: sfz key C#2, sounds G#2 +18 c
- growl2_rr1.wav: sfz key D2, sounds A2 +27 c
- growl3_rr1.wav: sfz key D#2, sounds A#2 +48 c
- growl4_rr1.wav: sfz key E2, sounds B2 +58 c
- growl5_rr1.wav: sfz key F2, sounds C3 +48 c
- growl6_rr1.wav: sfz key F#2, sounds C#3 +21 c
- growl7_rr1.wav: sfz key G2, sounds D3 +45 c
- growl8_rr1.wav: sfz key G#2, sounds D#3 +42 c
- growl9_rr1.wav: sfz key A2, sounds F3 -25 c
- growl10_rr1.wav: sfz key A#2, sounds F#3 -29 c
- growl11_rr1.wav: sfz key B2, sounds G3 -80 c
- growl12_rr1.wav: sfz key C3, sounds G#3 -33 c
- growl13_rr1.wav: sfz key C#3, sounds A3 -7 c
- growl14_rr1.wav: sfz key D3, sounds B3 -10 c

**Tuning.** Each recording's pitch was measured (cents: G#2 +18, A2 +27, A#2 +48, B2 +58, C3 +48, C#3 +21, D3 +45, D#3 +42, F3 -25, F#3 -30, G3 -80, G#3 -33, A3 -7, B3 -10) and corrected where 5 cents or more off. Finished notes measure -26 to +11 cents (growl pitch is rough by nature; measured by YIN on the steady part, every note within 12 cents).

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Made from | Semitones |
|---|---|---|
| G#2 | G#2 | recorded |
| A2 | A2 | recorded |
| A#2 | A#2 | recorded |
| B2 | B2 | recorded |
| C3 | C3 | recorded |
| C#3 | C#3 | recorded |
| D3 | D3 | recorded |
| D#3 | D#3 | recorded |
| E3 | D#3 | +1 |
| F3 | F3 | recorded |
| F#3 | F#3 | recorded |
| G3 | G3 | recorded |
| G#3 | G#3 | recorded |
| A3 | A3 | recorded |
| A#3 | A3 | +1 |
| B3 | B3 | recorded |

**One-shots.** No loops: each note plays to its natural end, cut 60 dB down with a 30 ms fade.

**Attack.** Kept as recorded: each note starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, nothing trimmed. Notes speak 2-15 ms after they start.

**Volume.** Each note's gain sits on a smooth line of loudness over the first 0.15 s (K-weighted) across the range, and the line is set so the pack plays at the same level as the Plucked Strings pack in the app (headroom for 2 voices included). Nothing clips.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level.
