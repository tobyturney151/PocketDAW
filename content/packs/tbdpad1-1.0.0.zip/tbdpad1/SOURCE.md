# tbdpad1

TBD Minor Pad 1 — Sonic Pi sample `tbd_pad_1`, donated to Sonic Pi by The Black Dog.
A chord over G2 — G, B♭, F, E♭, a G minor 7 colour. Retuned +4 cents to G2. One sample played an octave either side, G1 to G3, so the sound is never stretched far.

Ingested by tools/ingest-sfz.js from tbdpad1.sfz.
Range 31-55, tails cut at 4s.

Levels: loudest peak to -1.5 dBFS; gain ×2.61.
