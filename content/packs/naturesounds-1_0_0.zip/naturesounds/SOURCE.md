# Nature Sounds

Ten CC0 field recordings from BurghRecords' Nature Sounds Of Edinburgh, plus Sonic Pi's steam and crow. Every lane but the crow loops while its note is held and stops when the note ends.

Source: https://freesound.org/people/BurghRecords/packs/24672/

Ingested by `tools/ingest-drumkit.js`: one file per lane, trailing silence trimmed,
levels untouched, mixed to mono and encoded to AAC. The lane table in `lanes.json`
records which file each lane came from; re-run the tool to swap any of them.

| lane | file | from | seconds | peak dB | rms dB |
|---|---|---|---|---|---|
| Spring | naturesounds/36-spring.m4a | 36-spring.flac | 11.230 | -18.6 | -36.9 |
| Morning | naturesounds/37-morning.m4a | 37-morning.flac | 9.390 | -19.2 | -43.7 |
| Forest | naturesounds/38-forest.m4a | 38-forest.flac | 10.990 | -18.9 | -38.0 |
| Woodland | naturesounds/39-woodland.m4a | 39-woodland.flac | 8.290 | -16.7 | -36.8 |
| Birdsong | naturesounds/40-birdsong.m4a | 40-birdsong.flac | 10.910 | -12.0 | -31.6 |
| Treetops | naturesounds/41-treetops.m4a | 41-treetops.flac | 9.130 | -17.0 | -35.8 |
| Outdoors | naturesounds/42-outdoors.m4a | 42-outdoors.flac | 9.430 | -13.4 | -36.9 |
| Winter | naturesounds/43-winter.m4a | 43-winter.flac | 5.393 | -22.1 | -42.8 |
| Stream | naturesounds/44-stream.m4a | 44-stream.flac | 10.390 | -9.3 | -30.5 |
| Rain | naturesounds/45-rain.m4a | 45-rain.flac | 11.110 | -16.8 | -45.5 |
| Sauna | naturesounds/46-sauna.m4a | 46-sauna.flac | 6.750 | -0.2 | -14.0 |
| Crow | naturesounds/47-crow.m4a | 47-crow.flac | 0.481 | -0.2 | -14.2 |

## Lanes

| MIDI | Lane | Source | Kept | Loop | Level |
|---|---|---|---|---|---|
| 36 | Spring | [Birds In Spring (Scotland)](https://freesound.org/people/BurghRecords/sounds/463903/) | first 11.2 s | 1.26–10.98 s | ×2.57 |
| 37 | Morning | [Birds In The Morning](https://freesound.org/people/BurghRecords/sounds/554513/) | first 9.4 s | 1.52–9.14 s | ×2.88 |
| 38 | Forest | [Birds In The Forest](https://freesound.org/people/BurghRecords/sounds/456123/) | first 11.0 s | 0.90–10.74 s | ×3.16 |
| 39 | Woodland | [Birds In Forest (Scotland)](https://freesound.org/people/BurghRecords/sounds/490846/) | first 8.3 s | 0.94–8.04 s | ×2.04 |
| 40 | Birdsong | [Birds Singing, Forest (Scotland)](https://freesound.org/people/BurghRecords/sounds/490845/) | first 10.9 s | 1.58–10.66 s | ×1.26 |
| 41 | Treetops | [Birds In The Tree's](https://freesound.org/people/BurghRecords/sounds/543939/) | first 9.1 s | 0.90–8.88 s | ×2.11 |
| 42 | Outdoors | [Birds Outdoors](https://freesound.org/people/BurghRecords/sounds/456122/) | first 9.5 s | 2.32–9.18 s | ×2.69 |
| 43 | Winter | [Winter Forest](https://freesound.org/people/BurghRecords/sounds/562871/) | first 5.4 s | 0.96–5.14 s | ×4.57 |
| 44 | Stream | [Gentle Stream](https://freesound.org/people/BurghRecords/sounds/446019/) | first 10.4 s | 0.96–10.14 s | ×1.40 |
| 45 | Rain | [Light Outdoor Rain](https://freesound.org/people/BurghRecords/sounds/517316/) | first 11.1 s | 1.04–10.86 s | ×6.32 |
| 46 | Sauna | [Sonic Pi ambi_sauna](https://freesound.org/people/Exsomniel/sounds/207809/) | first 6.8 s | 1.00–6.50 s | ×0.20 |
| 47 | Crow | [Sonic Pi misc_crow](https://freesound.org/people/Autistic%20Lucario/sounds/195341/) | first 0.5 s | one-shot | ×0.25 |

Loop points avoid bird calls: each crossfade window was chosen to hold no burst standing out from its background, and the background level at the loop end matches the start. The last 0.35 s before each loop end is crossfaded into the 0.35 s before its start, and a quarter second of continuation follows the loop end. The sauna's steam fades throughout, so its level is held from 1 s for the length of its loop. Levels: loop lanes at -26 LUFS over their loop, the crow at -24 LUFS over its loudest 400 ms, every peak under -1 dBFS.
