# Didgeridoo 3

From Versilian Studios' VCSL (CC0): didgeridoo, sustain 8, one recording made playable from A1 to F#2.
https://github.com/sgossner/VCSL (`Aerophones/Lip Aerophones/Didgeridoo/Didgeridoo1_Sus8_Main.wav`)

**The recording.** A steady drone with slow vowel sweeps, blown nearly a quarter-tone sharp. 14.0 s, from its first sound to the end of the breath. The two microphones are mixed to mono: they are nearly uncorrelated, so the mix keeps the level of each.

**Pitch.** Like every recording of this didgeridoo, it drones on C#2 (about 69 Hz); this one measures C#2 +43 cents.

**Notes.** Every note from A1 to F#2 is made from the recording with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing. Each note is shifted by its interval from C#2 plus the recording's own offset, then measured as heard (0.3 s to its loop end) and made again with any remaining error taken out, until it is within 3 cents where it can be. The measurement is the median of four: a harmonic comb (harmonics 1-8) in 1 s frames, a pitch track, a harmonic comb over the whole note, and YIN on the frames where it follows the drone. Every note ends within 10 cents of its target.

| Note | Shift (semitones) | Measured (cents) | Loop (s) |
|---|---|---|---|
| A1 | -4.433 | +1.7 | 1.74-12.62 |
| A#1 | -3.433 | +1.6 | 1.78-12.60 |
| B1 | -2.433 | +2.1 | 1.72-12.58 |
| C2 | -1.433 | +2.2 | 1.78-12.61 |
| C#2 | -0.433 | +2.1 | 1.78-12.61 |
| D2 | +0.567 | +2.1 | 1.74-12.62 |
| D#2 | +1.567 | +2.3 | 1.74-12.65 |
| E2 | +2.567 | +2.6 | 1.74-12.63 |
| F2 | +3.567 | +2.8 | 1.72-12.56 |
| F#2 | +4.567 | +2.3 | 1.74-12.62 |

**Loops.** Each note loops while held, at points chosen for matching pitch, pitch direction, tone and level; the loop starts at least 0.5 s in and lasts at least 1 s, its end aligned in phase with its start and the seam crossfaded, with a quarter second of continuation after it. Loops (s): A1 1.74-12.62; A#1 1.78-12.60; B1 1.72-12.58; C2 1.78-12.61; C#2 1.78-12.61; D2 1.74-12.62; D#2 1.74-12.65; E2 1.74-12.63; F2 1.72-12.56; F#2 1.74-12.62.

**Volume.** Every note is set to the same listening loudness (Zwicker, ISO 532-1, held part 0.3-1.3 s), and the pack plays at the level of the other drone packs in the app (Ambi Drone, Haunted Hum, Drone Loop; headroom for 4 voices included). Nothing clips.

**Envelope.** Attack ramp 10 ms, release 1 s.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level. Built from the original recordings.

## 1.0.0

First version.
