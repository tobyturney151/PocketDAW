# droneloop

Drone Loop — Sonic Pi sample `loop_drone_g_97`, https://freesound.org/people/hullum/sounds/415570/.
A steady G1 drone, two bars at 97 bpm, confirmed by its third harmonic D3. The last 150 ms are crossfaded into the start so a held note loops without a click. Retuned +5 cents to G1. One sample played an octave either side, G0 to G2, so the sound is never stretched far.

Ingested by tools/ingest-sfz.js from droneloop.sfz.
Range 19-43.

Levels: loudest peak to -1.5 dBFS; gain ×1.663.
