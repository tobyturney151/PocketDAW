# Virtuosity Drums

Versilian Studios and Karoryfer Samples, Virtuosity Drums — a contemporary jazz kit played with sticks. Kick on the kick mic, snare articulations on the snare mic, toms on the mid mic, hats and cymbals on the overhead, as Big Rusty was built. Each lane's gain matches Big Rusty's measured playback level for the same lane, so a track moved between the two keeps its balance. MIDI numbers follow Big Rusty and the 808 for the same reason.

Source: https://github.com/sfzinstruments/virtuosity_drums

Ingested by `tools/ingest-drumkit.js`: one file per lane, trailing silence trimmed,
levels untouched, mixed to mono and encoded to AAC. The lane table in `lanes.json`
records which file each lane came from; re-run the tool to swap any of them.

| lane | file | from | seconds | peak dB | rms dB |
|---|---|---|---|---|---|
| Crash | virtuosity/49-crash.m4a | 49-oh_crash_crash_vl2_rr1.flac | 6.000 | -27.4 | -47.9 |
| Sizzle Crash | virtuosity/52-sizzlecrash.m4a | 52-oh_crash_sizzle_vl2_rr1.flac | 4.957 | -30.1 | -51.2 |
| Ride | virtuosity/51-ride.m4a | 51-oh_ride_ride_vl2_rr1.flac | 5.000 | -20.2 | -61.0 |
| Bell | virtuosity/53-bell.m4a | 53-oh_ride_bell_vl2_rr1.flac | 4.000 | -23.9 | -59.2 |
| Flat Ride | virtuosity/59-flatride.m4a | 59-oh_flatride_ride_vl2_rr1.flac | 5.000 | -18.6 | -58.5 |
| Hat Tip | virtuosity/42-hattip.m4a | 42-oh_hh_closed_vl1_rr1.flac | 0.157 | -38.4 | -65.1 |
| Hat Shank | virtuosity/22-hatshank.m4a | 22-oh_hh_closed_vl3_rr1.flac | 0.356 | -23.9 | -52.8 |
| Hat Pedal | virtuosity/44-hatpedal.m4a | 44-oh_hh_pedal_vl3_rr1.flac | 1.796 | -26.4 | -53.5 |
| Stickshot | virtuosity/39-stickshot.m4a | 39-snaremic_snare_stickshot2_vl10.flac | 0.295 | -23.0 | -47.2 |
| Cross Stick | virtuosity/37-crossstick.m4a | 37-snaremic_snare_crossstick_vl10.flac | 0.380 | -16.3 | -40.5 |
| Muted Snare | virtuosity/33-mutedsnare.m4a | 33-snaremic_snare_muted_vl10.flac | 0.545 | -11.6 | -37.4 |
| Rimshot | virtuosity/40-rimshot.m4a | 40-snaremic_snare_rimshot_vl9.flac | 1.499 | -4.3 | -32.8 |
| Snare | virtuosity/38-snare.m4a | 38-snaremic_snare_center_vl24.flac | 0.856 | -10.1 | -33.6 |
| Hi Tom | virtuosity/50-hitom.m4a | 50-mid_htom_center_vl10.flac | 1.773 | -11.0 | -33.9 |
| Lo Tom | virtuosity/45-lotom.m4a | 45-mid_ltom_center_vl10.flac | 3.518 | -12.5 | -34.8 |
| Kick | virtuosity/36-kick.m4a | 36-kickmic_kick_snon_vl3_rr1.flac | 2.064 | -8.3 | -28.2 |
