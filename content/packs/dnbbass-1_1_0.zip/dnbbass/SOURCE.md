# dnbbass

DnB Bass — Sonic Pi sample `bass_dnb_f`, https://freesound.org/people/Exsomniel/sounds/206134/.
Pitch, measured by harmonic-series fit over the whole sample and tracked over time: F1, about 10 cents flat, with a strong F2 partial. Root F1, retuned +10 cents to F1. One sample played from A0 to G4 by resampling.

Ingested by tools/ingest-sfz.js from dnbbass.sfz.
Range 21-67, tails cut at 2s.

Levels: loudness-matched to Swag Bass G1; gain ×0.314, so it peaks at -15.4 dBFS.

## 1.1.0: one sample per semitone

The app no longer speeds samples up or slows them down: every note from A0 to G4 has its own sample, played at its own pitch. The recorded note (F1) is unchanged. The other 46 were made from the recording that played them before, pitch-shifted with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch 0.3.1 wrapper), which keeps the recording's timing: attack, vibrato, tremolo, loops and decay arrive as recorded. Each is level-matched to its source recording.

| Note | Made from | Semitones |
|---|---|---|
| A0 | F1 | -8 |
| A#0 | F1 | -7 |
| B0 | F1 | -6 |
| C1 | F1 | -5 |
| C#1 | F1 | -4 |
| D1 | F1 | -3 |
| D#1 | F1 | -2 |
| E1 | F1 | -1 |
| F#1 | F1 | +1 |
| G1 | F1 | +2 |
| G#1 | F1 | +3 |
| A1 | F1 | +4 |
| A#1 | F1 | +5 |
| B1 | F1 | +6 |
| C2 | F1 | +7 |
| C#2 | F1 | +8 |
| D2 | F1 | +9 |
| D#2 | F1 | +10 |
| E2 | F1 | +11 |
| F2 | F1 | +12 |
| F#2 | F1 | +13 |
| G2 | F1 | +14 |
| G#2 | F1 | +15 |
| A2 | F1 | +16 |
| A#2 | F1 | +17 |
| B2 | F1 | +18 |
| C3 | F1 | +19 |
| C#3 | F1 | +20 |
| D3 | F1 | +21 |
| D#3 | F1 | +22 |
| E3 | F1 | +23 |
| F3 | F1 | +24 |
| F#3 | F1 | +25 |
| G3 | F1 | +26 |
| G#3 | F1 | +27 |
| A3 | F1 | +28 |
| A#3 | F1 | +29 |
| B3 | F1 | +30 |
| C4 | F1 | +31 |
| C#4 | F1 | +32 |
| D4 | F1 | +33 |
| D#4 | F1 | +34 |
| E4 | F1 | +35 |
| F4 | F1 | +36 |
| F#4 | F1 | +37 |
| G4 | F1 | +38 |
