# knightupright

Knight Upright. Source: https://github.com/sgossner/VCSL

Player-position microphones, layer vl2. Roots are the file names plus 12.

Ingested by tools/ingest-sfz.js from knightupright.sfz.
Range 21-108, tails cut at 5s.

Levels: loudest zone -5.8 dBFS as ingested; every zone given the same gain ×1.65 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
