# Emily Guitar

From Emilyguitar (Karoryfer Lecolds, 2014), played and mapped by D. Smolken; CC0 (the repository's LICENSE file is the CC0 1.0 legal code).
https://github.com/sfzinstruments/karoryfer.emilyguitar

**The recordings.** An Epiphone "Emily the Strange" solid-body electric with d'Addario Chromes flatwound strings (11 gauge), recorded direct through both pickups with every knob on ten, about every minor third from E2 to D6 plus the low E string tuned down to Db2 (18 notes), four dynamics with three takes each, mono, 44.1 kHz, 24-bit. This pack uses the second-loudest dynamic (mf), first take (rr1): the recordings the strummed Guitar Previews played.

**Notes.** 18 recordings, C#2 to D6; the pack plays C#2 to E6. Each recording plays the notes nearest it, sped up or slowed down by at most 2 semitones, as the source's own sampler mapping does.

Each note starts 5 ms before its first sound (40 dB below its peak) with a 2 ms fade-in. It ends where it has fallen 60 dB (30 ms fade), or at 6 s with a 1 s fade if it is still ringing then, or at the end of the recording with a 0.3 s fade if that comes first (11 fall 60 dB, 7 stop with their recording). Notes last 2.9–4.2 s.

**Tuning.** Each recording measured (a harmonic fit, then the median of a pitch track over 0.05–0.8 s). 4 of the 18 were 5 cents or more off and were retuned by varispeed (resampled, which also changes their length by under 2%). The finished files measure -3 to +5 cents.

| Recording | Plays | Measured (cents) | Retuned (cents) | Length | Ends |
|---|---|---|---|---|---|
| C#2 | C#2–D2 | -2.8 | – | 4.2 s | with the recording |
| E2 | D#2–F2 | +5.9 | -5.9 | 4.2 s | with the recording |
| F#2 | F#2–G2 | +2.9 | – | 4.2 s | with the recording |
| A2 | G#2–A#2 | +5.9 | -5.9 | 4.2 s | fell 60 dB |
| C3 | B2–C#3 | +7.0 | -7.0 | 4.2 s | fell 60 dB |
| D#3 | D3–E3 | +0.1 | – | 4.2 s | fell 60 dB |
| F#3 | F3–G3 | -3.0 | – | 4.2 s | with the recording |
| A3 | G#3–A#3 | +4.2 | – | 4.2 s | with the recording |
| C4 | B3–C#4 | -0.2 | – | 4.2 s | with the recording |
| D#4 | D4–E4 | +3.6 | – | 4.2 s | with the recording |
| F#4 | F4–G4 | +0.9 | – | 4.1 s | fell 60 dB |
| A4 | G#4–A#4 | +4.6 | – | 4.2 s | fell 60 dB |
| C5 | B4–C#5 | +2.2 | – | 4.2 s | fell 60 dB |
| D#5 | D5–E5 | +9.3 | -9.3 | 4.2 s | fell 60 dB |
| F#5 | F5–G5 | -1.6 | – | 4.1 s | fell 60 dB |
| A5 | G#5–A#5 | +4.9 | – | 2.9 s | fell 60 dB |
| C6 | B5–C#6 | +2.5 | – | 3.0 s | fell 60 dB |
| D6 | D6–E6 | -1.3 | – | 3.5 s | fell 60 dB |

**Volume.** Set by the method of the volume audit of 14 October: every note in the range played as the app plays it and measured for listening loudness (ISO 532-1 Zwicker, the loudest moment), each recording's gain set so its notes match, and the pack set to the level of jRhodes and the other pitched packs. The notes measure 70.6 phon (median), within 1.6 phon of one another. At full velocity the loudest note peaks at 1.05 of full scale before the track and master gains.

**Strumming.** Like the rest of the Guitar category, the manifest sets `strum`: notes that start together are one stroke across the strings, down and up strokes strictly alternating; a downstroke goes low to high in 24 ms and an upstroke high to low in 18 ms however many strings it has, the upstroke at 82% of the velocity, each further string a little softer (0.96 down, 0.9 up). Single notes alternate the same way. The app needs the strum update for this; before it, the pack plays chords all at once.

**Envelope.** One-shots, as in the other Guitar packs: attack ramp 2 ms, release 0.4 s, 8 voices, headroom for 4 at once.

Files are mono, 44.1 kHz AAC at 160 kb/s, each peak-normalised; the catalog gain restores its level. Each file takes the lowest of those rates at which it decodes cleanly (peak within 0.95 of full scale, waveform error at least 20 dB down).

## 1.0.0

First version.
