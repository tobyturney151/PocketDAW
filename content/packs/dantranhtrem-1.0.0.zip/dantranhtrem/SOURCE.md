# dantranhtrem

Dan Tranh Trem. Source: https://github.com/sgossner/VCSL

Tremolo. Roots are the file names plus 12.

Ingested by tools/ingest-sfz.js from dantranhtrem.sfz.
Range 45-85, tails cut at 4s.

Levels: loudest zone -8.9 dBFS as ingested; every zone given the same gain ×2.355 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
