# Harmonica

From Versilian Studios' VCSL (CC0): Hohner Special 20 diatonic harmonica in C, soft sustains.
https://github.com/sgossner/VCSL (`Aerophones/Free Aerophones/Harmonica-Hohner-Special20-C/Sustains/Soft`)

Every note from C4 to C7 has its own sample, played at its own pitch.

**Layer.** VCSL records the Special 20 in C as normal, soft and vibrato sustains, each with separate release tails (not used here); this pack is the soft sustains, chosen by listening. One take per note. The recordings are the harmonica's blow notes (C, E and G in each octave), so the notes between them are made with Signalsmith.

**Recordings.** 10: C4, E4, G4, C5, E5, G5, C6, E6, G6, C7. Using the mono recording. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Tuning.** Each recording's pitch was measured: all within 1.9 cents, so none needed correcting (the rule is 5 cents or more). Finished notes measure -3 to +2 cents.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Each made note reuses its recording's loop.

| Note | Made from | Semitones |
|---|---|---|
| C4 | C4 | recorded |
| C#4 | C4 | +1 |
| D4 | C4 | +2 |
| D#4 | E4 | -1 |
| E4 | E4 | recorded |
| F4 | E4 | +1 |
| F#4 | G4 | -1 |
| G4 | G4 | recorded |
| G#4 | G4 | +1 |
| A4 | G4 | +2 |
| A#4 | C5 | -2 |
| B4 | C5 | -1 |
| C5 | C5 | recorded |
| C#5 | C5 | +1 |
| D5 | C5 | +2 |
| D#5 | E5 | -1 |
| E5 | E5 | recorded |
| F5 | E5 | +1 |
| F#5 | G5 | -1 |
| G5 | G5 | recorded |
| G#5 | G5 | +1 |
| A5 | G5 | +2 |
| A#5 | C6 | -2 |
| B5 | C6 | -1 |
| C6 | C6 | recorded |
| C#6 | C6 | +1 |
| D6 | C6 | +2 |
| D#6 | E6 | -1 |
| E6 | E6 | recorded |
| F6 | E6 | +1 |
| F#6 | G6 | -1 |
| G6 | G6 | recorded |
| G#6 | G6 | +1 |
| A6 | G6 | +2 |
| A#6 | C7 | -2 |
| B6 | C7 | -1 |
| C7 | C7 | recorded |

**Loops.** Each recording loops while held, at points chosen for matching pitch, pitch direction, tone and level; the loop starts at least 0.5 s into the note and lasts at least 1 s; its end is aligned in phase with its start and the seam is crossfaded, with a quarter second of continuation after the loop end. Loops (s): C4 0.50-2.81; C#4 0.50-2.82; D4 0.50-2.80; D#4 0.50-5.15; E4 0.50-5.15; F4 0.50-5.14; F#4 0.50-5.13; G4 0.50-5.15; G#4 0.50-5.14; A4 0.50-5.15; A#4 0.66-5.15; B4 0.66-5.13; C5 0.66-5.14; C#5 0.66-5.14; D5 0.66-5.14; D#5 0.82-4.69; E5 0.82-4.69; F5 0.82-4.69; F#5 1.68-4.81; G5 1.68-4.80; G#5 1.68-4.80; A5 1.68-4.78; A#5 0.88-5.85; B5 0.88-5.86; C6 0.88-5.85; C#6 0.88-5.85; D6 0.88-5.85; D#6 1.58-5.11; E6 1.58-5.12; F6 1.58-5.10; F#6 0.74-4.58; G6 0.74-4.60; G#6 0.74-4.58; A6 0.74-4.58; A#6 0.70-2.56; B6 0.70-2.58; C7 0.70-2.56.

**Attack.** Each note starts 10 ms before its tone comes within 20 dB of its full level, skipping the quiet lead-in before the reed speaks, with a 2 ms fade-in; the attack itself is kept. Notes speak 13-48 ms after they start.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s, K-weighted) across the range, set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

**Envelope.** Attack ramp 5 ms, release 0.25 s.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level. Built from the original recordings.

## 1.0.0

First version.
