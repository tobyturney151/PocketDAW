# tubularbells2

Tubular Bells 2. Source: https://github.com/sgossner/VCSL

Layer v2. The strike tone sits an octave below the loudest partials, which puts it at the file names: C4 to F5.

Ingested by tools/ingest-sfz.js from tubularbells2.sfz.
Range 58-79, tails cut at 6s.

Levels: loudest zone -17.5 dBFS as ingested; every zone given the same gain ×6.331 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
