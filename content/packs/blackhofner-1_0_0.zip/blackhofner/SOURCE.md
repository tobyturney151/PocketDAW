# Black Hofner

From Black And Green Guitars (Karoryfer Lecolds, 2022), recorded and photographed by Brian Wood; CC0 (the repository's LICENSE file is the CC0 1.0 legal code).
https://github.com/sfzinstruments/karoryfer.black-and-green-guitars

**The recordings.** A black Höfner Club hollow-body electric, every semitone from E2 to D6, played ordinarily ("twang") at three dynamics with two to four takes each, mono, 44.1 kHz, 24-bit. This pack uses the loudest dynamic (f), first take (rr1): the recordings the strummed Guitar Previews played.

**Notes.** 47 recordings, E2 to D6; the pack plays E2 to E6. Every note has its own recording, and the 2 above the top one are the top recording sped up.

Each note starts 5 ms before its first sound (40 dB below its peak) with a 2 ms fade-in. It ends where it has fallen 60 dB (30 ms fade), or at 6 s with a 1 s fade if it is still ringing then, or at the end of the recording with a 0.3 s fade if that comes first (42 fall 60 dB, 5 stop with their recording). Notes last 1.4–5.7 s.

**Tuning.** Each recording measured (a harmonic fit, then the median of a pitch track over 0.05–0.8 s). 26 of the 47 were 5 cents or more off and were retuned by varispeed (resampled, which also changes their length by under 2%). The finished files measure -5 to +5 cents.

| Recording | Plays | Measured (cents) | Retuned (cents) | Length | Ends |
|---|---|---|---|---|---|
| E2 | E2 | +8.5 | -8.5 | 5.6 s | fell 60 dB |
| F2 | F2 | +9.3 | -9.3 | 4.7 s | with the recording |
| F#2 | F#2 | +12.8 | -12.8 | 3.3 s | with the recording |
| G2 | G2 | +7.5 | -7.5 | 3.9 s | with the recording |
| G#2 | G#2 | +0.1 | – | 4.3 s | with the recording |
| A2 | A2 | -0.8 | – | 5.3 s | fell 60 dB |
| A#2 | A#2 | +11.0 | -11.0 | 4.1 s | fell 60 dB |
| B2 | B2 | +3.5 | – | 4.2 s | fell 60 dB |
| C3 | C3 | +1.7 | – | 4.5 s | fell 60 dB |
| C#3 | C#3 | -5.8 | +5.8 | 4.5 s | with the recording |
| D3 | D3 | +8.7 | -8.7 | 5.1 s | fell 60 dB |
| D#3 | D#3 | +12.0 | -12.0 | 4.8 s | fell 60 dB |
| E3 | E3 | +15.6 | -15.6 | 4.5 s | fell 60 dB |
| F3 | F3 | +7.6 | -7.6 | 4.2 s | fell 60 dB |
| F#3 | F#3 | +7.8 | -7.8 | 3.6 s | fell 60 dB |
| G3 | G3 | +13.6 | -13.6 | 5.6 s | fell 60 dB |
| G#3 | G#3 | +17.4 | -17.4 | 4.5 s | fell 60 dB |
| A3 | A3 | +16.2 | -16.2 | 4.6 s | fell 60 dB |
| A#3 | A#3 | +12.5 | -12.5 | 4.5 s | fell 60 dB |
| B3 | B3 | +7.3 | -7.3 | 5.7 s | fell 60 dB |
| C4 | C4 | +15.3 | -15.3 | 5.0 s | fell 60 dB |
| C#4 | C#4 | +7.2 | -7.2 | 5.0 s | fell 60 dB |
| D4 | D4 | +5.0 | -5.0 | 4.9 s | fell 60 dB |
| D#4 | D#4 | +4.9 | – | 5.3 s | fell 60 dB |
| E4 | E4 | +3.1 | – | 4.4 s | fell 60 dB |
| F4 | F4 | +4.8 | – | 3.8 s | fell 60 dB |
| F#4 | F#4 | +4.1 | – | 3.8 s | fell 60 dB |
| G4 | G4 | +4.2 | – | 4.2 s | fell 60 dB |
| G#4 | G#4 | +2.9 | – | 4.2 s | fell 60 dB |
| A4 | A4 | +2.5 | – | 3.9 s | fell 60 dB |
| A#4 | A#4 | +1.7 | – | 3.8 s | fell 60 dB |
| B4 | B4 | +0.1 | – | 4.0 s | fell 60 dB |
| C5 | C5 | -0.2 | – | 4.0 s | fell 60 dB |
| C#5 | C#5 | -0.1 | – | 3.5 s | fell 60 dB |
| D5 | D5 | -1.2 | – | 3.9 s | fell 60 dB |
| D#5 | D#5 | -2.6 | – | 3.6 s | fell 60 dB |
| E5 | E5 | -2.1 | – | 4.0 s | fell 60 dB |
| F5 | F5 | -3.7 | – | 3.4 s | fell 60 dB |
| F#5 | F#5 | -5.8 | +5.8 | 2.7 s | fell 60 dB |
| G5 | G5 | -3.9 | – | 3.3 s | fell 60 dB |
| G#5 | G#5 | -11.9 | +11.9 | 3.3 s | fell 60 dB |
| A5 | A5 | -6.0 | +6.0 | 2.6 s | fell 60 dB |
| A#5 | A#5 | -8.3 | +8.3 | 2.4 s | fell 60 dB |
| B5 | B5 | -5.8 | +5.8 | 2.8 s | fell 60 dB |
| C6 | C6 | -4.9 | – | 2.5 s | fell 60 dB |
| C#6 | C#6 | -8.5 | +8.5 | 1.9 s | fell 60 dB |
| D6 | D6–E6 | -5.7 | +5.7 | 1.4 s | fell 60 dB |

**Volume.** Set by the method of the volume audit of 14 October: every note in the range played as the app plays it and measured for listening loudness (ISO 532-1 Zwicker, the loudest moment), each recording's gain set so its notes match, and the pack set to the level of jRhodes and the other pitched packs. The notes measure 70.8 phon (median), within 1.5 phon of one another. At full velocity the loudest note peaks at 0.48 of full scale before the track and master gains.

**Strumming.** Like the rest of the Guitar category, the manifest sets `strum`: notes that start together are one stroke across the strings, down and up strokes strictly alternating; a downstroke goes low to high in 24 ms and an upstroke high to low in 18 ms however many strings it has, the upstroke at 82% of the velocity, each further string a little softer (0.96 down, 0.9 up). Single notes alternate the same way. The app needs the strum update for this; before it, the pack plays chords all at once.

**Envelope.** One-shots, as in the other Guitar packs: attack ramp 2 ms, release 0.4 s, 8 voices, headroom for 4 at once.

Files are mono, 44.1 kHz AAC at 160 kb/s (46 notes) and 256 kb/s (1 note), each peak-normalised; the catalog gain restores its level. Each file takes the lowest of those rates at which it decodes cleanly (peak within 0.95 of full scale, waveform error at least 20 dB down).

## 1.0.0

First version.
