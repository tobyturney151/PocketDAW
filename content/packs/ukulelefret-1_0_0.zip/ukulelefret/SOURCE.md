# Ukulele - Fret Mic

From "Ukulele" by Sadiquecat on Freesound (pack 40584), every sound in it released under Creative Commons 0.
https://freesound.org/people/Sadiquecat/packs/40584/

Every note from A3 to F6 has its own sample, played at its own pitch.

**The recordings.** One soprano ukulele, tuned G C E A (re-entrant: G4, C4, E4, A4), each string plucked on its own at every fret from open to the 17th. The pack has two sets of strings: the ukulele's original strings, about eight years old (the files marked "old"), and newer ones, which this pack uses. Each pluck was recorded at once by two Rode NT5 microphones, one aimed at the 12th fret and one at the soundhole, and by a Zoom H5's XY pair; 48 kHz, 24-bit, not processed apart from trimming. This pack uses the NT5 microphone aimed at the 12th fret (the left channel of the pack's NT5 files).

**Notes.** For each note, the lowest fret that plays it, as a player in first position would: the C string for C4–D#4, the E string for E4–F#4, the G string for G4–G#4 and the A string from A4 up to D6. Each starts 5 ms before its first sound (40 dB below its peak) with a 2 ms fade-in, and ends where it has fallen 60 dB with a 30 ms fade, or, if the recording stops sooner, at its end with a 0.3 s fade.

**Tuning.** Each recording measured on this microphone (a harmonic fit, then the median of a pitch track over 0.05–0.8 s). The higher frets play sharp, as fretted strings do; 17 of the 27 recordings were 5 cents or more off and were retuned by varispeed (resampled, which also lengthens each by up to 2.5%). Finished notes measure 0 to +5 cents.

| Note | String and fret | Measured (cents) | Retuned (cents) |
|---|---|---|---|
| A3 | made from C4, -3 semitones | – | – |
| A#3 | made from C4, -2 semitones | – | – |
| B3 | made from C4, -1 semitone | – | – |
| C4 | C, open | +2.0 | – |
| C#4 | C, fret 1 | +5.7 | -5.7 |
| D4 | C, fret 2 | +2.6 | – |
| D#4 | C, fret 3 | +2.3 | – |
| E4 | E, open | +0.8 | – |
| F4 | E, fret 1 | +10.7 | -10.7 |
| F#4 | E, fret 2 | +6.6 | -6.6 |
| G4 | G, open | +1.2 | – |
| G#4 | G, fret 1 | +2.5 | – |
| A4 | A, open | +4.5 | – |
| A#4 | A, fret 1 | +4.6 | – |
| B4 | A, fret 2 | +7.4 | -7.4 |
| C5 | A, fret 3 | +7.4 | -7.4 |
| C#5 | A, fret 4 | +8.4 | -8.4 |
| D5 | A, fret 5 | +10.3 | -10.3 |
| D#5 | A, fret 6 | +7.9 | -7.9 |
| E5 | A, fret 7 | +7.1 | -7.1 |
| F5 | A, fret 8 | +6.7 | -6.7 |
| F#5 | A, fret 9 | +3.5 | – |
| G5 | A, fret 10 | +3.6 | – |
| G#5 | A, fret 11 | +6.4 | -6.4 |
| A5 | A, fret 12 | +10.3 | -10.3 |
| A#5 | A, fret 13 | +19.0 | -19.0 |
| B5 | A, fret 14 | +30.1 | -30.1 |
| C6 | A, fret 15 | +37.4 | -37.4 |
| C#6 | A, fret 16 | +42.3 | -42.3 |
| D6 | A, fret 17 | +41.0 | -41.0 |
| D#6 | made from D6, +1 semitone | – | – |
| E6 | made from D6, +2 semitones | – | – |
| F6 | made from D6, +3 semitones | – | – |

**Notes past the ukulele's range** (A3, A#3, B3, D#6, E6, F6) were made from the nearest end note with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that note.

**One-shots.** No loops: each note plays to its own end (0.8–6.6 s; the low notes ring longest, the highest frets shortest), as Spanish Guitar and Oud, the other packs in the Guitar category, do.

**Volume.** Every note is set to the same listening loudness (Zwicker, ISO 532-1, the loudest moment of its first 0.8 s; the finished files measure within 0.5 phon), and the pack plays at the level of the Spanish Guitar pack (median of its notes' first 0.15 s, K-weighted, headroom for 4 voices included). At full velocity the loudest note peaks at 0.58 of full scale before the track and master gains.

**Envelope.** Attack ramp 2 ms, release 0.4 s. Every note speaks at once (within 5 ms of its start).

Files are mono, 44.1 kHz AAC, each peak-normalised; the catalog gain restores the level. They are encoded at 160 kb/s (27 notes), 192 kb/s (3 notes) and 256 kb/s (3 notes): at 96 kb/s, the rate most packs use, the encoder blurred some of the sharp plucks (decoded peaks up to 1.4 times the original).

## 1.0.0

First version.
