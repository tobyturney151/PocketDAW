# glassrub

Glass Rub — Sonic Pi sample `ambi_glass_rub`, https://freesound.org/people/ani_music/sounds/198403/.
Pitch, measured by harmonic-series fit over the whole sample and tracked over time: F#5, 9 cents flat, clean and steady. Root F#5, retuned +9 cents to F#5. One sample played from F#4 to F#6 by resampling.

Ingested by tools/ingest-sfz.js from glassrub.sfz.
Range 66-90, tails cut at 4s.

Levels: loudest peak to -1.5 dBFS; gain ×0.996, so it peaks at -1.5 dBFS.
