# thickbass

Thick Bass — Sonic Pi sample `bass_thick_c`, https://freesound.org/people/ani_music/sounds/165314/.
Pitch, measured by harmonic-series fit over the whole sample and tracked over time: two detuned oscillators on C2, averaging 10 cents flat. Root C2, retuned +10 cents to C2. One sample played from A0 to G4 by resampling.

Ingested by tools/ingest-sfz.js from thickbass.sfz.
Range 21-67, tails cut at 4s.

Levels: loudness-matched to Swag Bass G1; gain ×0.218, so it peaks at -13.6 dBFS.
