# dantranhtrem

Dan Tranh Trem. Source: https://github.com/sgossner/VCSL

Tremolo. Roots are the file names plus 12.

Ingested by tools/ingest-sfz.js from dantranhtrem.sfz.
Range 45-85, tails cut at 4s.

Levels: loudest zone -8.9 dBFS as ingested; every zone given the same gain ×2.355 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.

1.0.1: three samples removed and their notes borrowed from neighbours. F#3 (file F#2) measured 30 cents flat and G#5 (file G#4) 33 cents sharp. C#3 (file C#2) was reported off by ear and one measurement, though it read 9 cents flat here; removed at the listener's request. Each missing note is played by whichever neighbour is closer: B2 takes C#3, D#3 takes D3 and F3, G#3 takes F#3 and G3, F#5 takes G#5, B5 takes A5 — all neighbours within 10 cents.
