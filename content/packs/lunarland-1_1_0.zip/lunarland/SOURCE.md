# lunarland

Lunar Land — Sonic Pi sample `ambi_lunar_land`, https://freesound.org/people/maqsim/sounds/172157/.
Pitch, measured by harmonic-series fit over the whole sample and tracked over time: no fixed pitch: a continuous descent of about three octaves, from around B5 to G1, fading as it falls. Rooted on the loud opening around A#5, so a key starts the whole descent from that pitch. Root A#5, left as recorded (+0 cents). One sample played from A#4 to A#6 by resampling.

Ingested by tools/ingest-sfz.js from lunarland.sfz.
Range 70-94, tails cut at 8s.

Levels: loudest peak to -1.5 dBFS; gain ×1.652, so it peaks at -1.5 dBFS.

## 1.1.0: one sample per semitone

The app no longer speeds samples up or slows them down: every note from A#4 to A#6 has its own sample, played at its own pitch. The recorded note (A#5) is unchanged. The other 24 were made from the recording that played them before, pitch-shifted with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch 0.3.1 wrapper), which keeps the recording's timing: attack, vibrato, tremolo, loops and decay arrive as recorded. Each is level-matched to its source recording.

| Note | Made from | Semitones |
|---|---|---|
| A#4 | A#5 | -12 |
| B4 | A#5 | -11 |
| C5 | A#5 | -10 |
| C#5 | A#5 | -9 |
| D5 | A#5 | -8 |
| D#5 | A#5 | -7 |
| E5 | A#5 | -6 |
| F5 | A#5 | -5 |
| F#5 | A#5 | -4 |
| G5 | A#5 | -3 |
| G#5 | A#5 | -2 |
| A5 | A#5 | -1 |
| B5 | A#5 | +1 |
| C6 | A#5 | +2 |
| C#6 | A#5 | +3 |
| D6 | A#5 | +4 |
| D#6 | A#5 | +5 |
| E6 | A#5 | +6 |
| F6 | A#5 | +7 |
| F#6 | A#5 | +8 |
| G6 | A#5 | +9 |
| G#6 | A#5 | +10 |
| A6 | A#5 | +11 |
| A#6 | A#5 | +12 |
