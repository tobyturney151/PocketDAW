# Coast & Falls

Beach ambiences, stones thrown into the sea, waves on rocks, and waterfalls in Scotland and Montenegro. Every lane loops while its note is held and stops when the note ends.

Source: https://signaturesounds.org/

Ingested by `tools/ingest-drumkit.js`: one file per lane, trailing silence trimmed,
levels untouched, mixed to mono and encoded to AAC. The lane table in `lanes.json`
records which file each lane came from; re-run the tool to swap any of them.

| lane | file | from | seconds | peak dB | rms dB |
|---|---|---|---|---|---|
| Beach 1 | coastfalls/36-beach1.m4a | 36-beach1.flac | 10.310 | -19.3 | -31.9 |
| Beach 2 | coastfalls/37-beach2.m4a | 37-beach2.flac | 11.050 | -24.1 | -45.3 |
| Beach 3 | coastfalls/38-beach3.m4a | 38-beach3.flac | 11.050 | -26.9 | -45.9 |
| Beach 4 | coastfalls/39-beach4.m4a | 39-beach4.flac | 10.610 | -22.6 | -38.3 |
| Stones | coastfalls/40-stones.m4a | 40-stones.flac | 10.650 | -5.8 | -41.7 |
| Rock Shore | coastfalls/41-rockshore.m4a | 41-rockshore.flac | 11.230 | -11.7 | -42.1 |
| Hermitage | coastfalls/42-hermitage.m4a | 42-hermitage.flac | 10.410 | -16.5 | -30.1 |
| Hermitage 2 | coastfalls/43-hermitage2.m4a | 43-hermitage2.flac | 10.610 | -20.3 | -34.4 |
| Hermitage 3 | coastfalls/44-hermitage3.m4a | 44-hermitage3.flac | 10.810 | -16.7 | -29.8 |
| Falls Far | coastfalls/45-fallsfar.m4a | 45-fallsfar.flac | 10.450 | -11.2 | -24.2 |
| Falls Near | coastfalls/46-fallsnear.m4a | 46-fallsnear.flac | 11.230 | -11.8 | -25.3 |

## Lanes

| MIDI | Lane | Source pack | Recording | Excerpt from | Loop | Level |
|---|---|---|---|---|---|---|
| 36 | Beach 1 | [Beach Ambience Recordings](https://signaturesounds.org/) | Beach_Ambience_9.wav | 26.0 s | 0.98–10.06 s | ×2.63 |
| 37 | Beach 2 | [Beach Ambience Recordings](https://signaturesounds.org/) | Beach_Ambience_7.wav | 37.2 s | 1.70–10.80 s | ×10.12 |
| 38 | Beach 3 | [Beach Ambience Recordings](https://signaturesounds.org/) | Beach_Ambience_6.wav | 38.5 s | 0.98–10.80 s | ×11.22 |
| 39 | Beach 4 | [Beach Ambience Recordings](https://signaturesounds.org/) | Beach_Ambience_10.wav | 41.5 s | 1.98–10.36 s | ×4.27 |
| 40 | Stones | [Beach Ambience Recordings](https://signaturesounds.org/) | Throwing_Stones_Into_Ocean_Recording_1.wav | 68.2 s | 2.42–10.40 s | ×1.81 |
| 41 | Rock Shore | [Beach Ambience Recordings](https://signaturesounds.org/) | Beach_Rocks_Recording_2.wav | 63.5 s | 1.02–10.98 s | ×3.43 |
| 42 | Hermitage | [Waterfall Recordings](https://signaturesounds.org/) | Waterfall_Ambience_The_Harmitage_Scotland.wav | 41.2 s | 1.30–10.16 s | ×1.64 |
| 43 | Hermitage 2 | [Waterfall Recordings](https://signaturesounds.org/) | Waterfall_Ambience_The_Harmitage_Scotland_04.wav | 19.0 s | 1.00–10.36 s | ×2.51 |
| 44 | Hermitage 3 | [Waterfall Recordings](https://signaturesounds.org/) | Waterfall_Ambience_The_Harmitage_Scotland_05.wav | 11.8 s | 1.10–10.56 s | ×1.45 |
| 45 | Falls Far | [Waterfall Recordings](https://signaturesounds.org/) | Waterfall_Far_Away_Risan_Montenegro.WAV | 19.8 s | 1.20–10.20 s | ×0.78 |
| 46 | Falls Near | [Waterfall Recordings](https://signaturesounds.org/) | Waterfall_Upclose_Risan_Montenegro.WAV | 9.0 s | 0.98–10.98 s | ×0.91 |

Each excerpt is the steadiest stretch of about 11.5 s in its recording's first two minutes; recordings were picked from each source pack for steadiness, then spread across brightness so lanes differ. Loop seams avoid sudden sounds in both the high band and the full band, and match background level; the last 0.35 s before each loop end is crossfaded into the 0.35 s before its start, with a quarter second of continuation after the end. Recordings whose channels partly cancel when summed use their stronger channel. Levels: -26 LUFS over each loop, peaks under -1 dBFS.
