# SonicPi Drums

Sonic Pi's acoustic drum kit, the twenty drum_ samples, each from Freesound under CC0. MIDI numbers follow Big Rusty, the 808 and Virtuosity, so a track moved between kits keeps its parts. Every hard hit is levelled to Big Rusty's playback level for the same lane, and each soft hit gets its partner's gain, so it stays as much softer as it was played. Sources per file: drum_cymbal_hard https://www.freesound.org/people/menegass/sounds/100056/; drum_cymbal_soft https://www.freesound.org/people/menegass/sounds/100057/; drum_splash_hard https://www.freesound.org/people/menegass/sounds/100060/; drum_splash_soft https://www.freesound.org/people/menegass/sounds/100061/; drum_cymbal_open https://www.freesound.org/people/menegass/sounds/100055/; drum_cymbal_closed https://www.freesound.org/people/menegass/sounds/100053/; drum_cymbal_pedal https://www.freesound.org/people/menegass/sounds/100054/; drum_cowbell https://freesound.org/people/Neotone/sounds/75338/; drum_roll https://freesound.org/people/Heigh-hoo/sounds/19433/; drum_snare_hard https://www.freesound.org/people/menegass/sounds/100058/; drum_snare_soft https://www.freesound.org/people/menegass/sounds/100059/; drum_tom_hi_hard https://www.freesound.org/people/menegass/sounds/100062/; drum_tom_hi_soft https://www.freesound.org/people/menegass/sounds/100063/; drum_tom_mid_hard https://www.freesound.org/people/menegass/sounds/100066/; drum_tom_mid_soft https://www.freesound.org/people/menegass/sounds/100067/; drum_tom_lo_hard https://www.freesound.org/people/menegass/sounds/100064/; drum_tom_lo_soft https://www.freesound.org/people/menegass/sounds/100065/; drum_heavy_kick https://freesound.org/people/Zajo/sounds/4832/; drum_bass_hard https://www.freesound.org/people/menegass/sounds/100051/; drum_bass_soft https://www.freesound.org/people/menegass/sounds/100052/

Source: https://github.com/sonic-pi-net/sonic-pi/tree/main/etc/samples

Ingested by `tools/ingest-drumkit.js`: one file per lane, trailing silence trimmed,
levels untouched, mixed to mono and encoded to AAC. The lane table in `lanes.json`
records which file each lane came from; re-run the tool to swap any of them.

| lane | file | from | seconds | peak dB | rms dB |
|---|---|---|---|---|---|
| Crash | spdrums/49-crash.m4a | 49-drum_cymbal_hard.flac | 1.639 | -0.0 | -23.2 |
| Crash Soft | spdrums/57-crashsoft.m4a | 57-drum_cymbal_soft.flac | 0.950 | -4.1 | -26.1 |
| Splash | spdrums/55-splash.m4a | 55-drum_splash_hard.flac | 2.596 | -0.1 | -19.0 |
| Splash Soft | spdrums/52-splashsoft.m4a | 52-drum_splash_soft.flac | 1.858 | -7.3 | -26.5 |
| Hat Open | spdrums/46-hatopen.m4a | 46-drum_cymbal_open.flac | 1.804 | -0.1 | -19.2 |
| Hat Closed | spdrums/42-hatclosed.m4a | 42-drum_cymbal_closed.flac | 0.207 | -0.9 | -23.8 |
| Hat Pedal | spdrums/44-hatpedal.m4a | 44-drum_cymbal_pedal.flac | 0.272 | -2.7 | -22.6 |
| Cowbell | spdrums/56-cowbell.m4a | 56-drum_cowbell.flac | 0.350 | -1.8 | -11.3 |
| Snare Roll | spdrums/25-snareroll.m4a | 25-drum_roll.flac | 6.242 | -3.1 | -21.2 |
| Snare | spdrums/38-snare.m4a | 38-drum_snare_hard.flac | 0.445 | 0.0 | -13.8 |
| Snare Soft | spdrums/40-snaresoft.m4a | 40-drum_snare_soft.flac | 0.315 | -5.6 | -24.0 |
| Hi Tom | spdrums/50-hitom.m4a | 50-drum_tom_hi_hard.flac | 0.738 | 0.0 | -13.2 |
| Hi Tom Soft | spdrums/48-hitomsoft.m4a | 48-drum_tom_hi_soft.flac | 0.629 | -6.0 | -23.1 |
| Mid Tom | spdrums/47-midtom.m4a | 47-drum_tom_mid_hard.flac | 0.734 | 0.0 | -12.3 |
| Mid Tom Soft | spdrums/43-midtomsoft.m4a | 43-drum_tom_mid_soft.flac | 0.672 | -3.9 | -18.2 |
| Lo Tom | spdrums/45-lotom.m4a | 45-drum_tom_lo_hard.flac | 1.000 | 0.0 | -12.2 |
| Lo Tom Soft | spdrums/41-lotomsoft.m4a | 41-drum_tom_lo_soft.flac | 0.863 | -5.4 | -22.0 |
| Heavy Kick | spdrums/34-heavykick.m4a | 34-drum_heavy_kick.flac | 0.270 | -0.0 | -11.3 |
| Kick | spdrums/36-kick.m4a | 36-drum_bass_hard.flac | 0.695 | 0.0 | -10.4 |
| Kick Soft | spdrums/35-kicksoft.m4a | 35-drum_bass_soft.flac | 0.562 | -0.2 | -17.4 |
