# Solo Violin Tremolo

From Versilian Studios' VSCO 2 Community Edition (CC0): solo violin, tremolo, soft layer.
https://github.com/sgossner/VSCO-2-CE (folder `Strings/Solo Violin/Trem`)

Every note from G3 to A6 has its own sample, played at its own pitch.

**Recordings.** 13 soft-layer recordings (LLVln_trem_<note>_v1_rr1.wav, first round robin where there are several): G3, A3, C4, E4, G4, A4, C5, E5, G5, A5, C6, E6, G6. The file names in this folder are written an octave low (`LLVln_trem_C3_v1_rr1.wav` sounds C4), so each was filed an octave up. Only the left microphone is used: the two channels of these solo recordings are poorly correlated, and summing them to mono thinned notes by 1 to 4 dB with notches of up to 9 dB in some bands.

**Tuning.** Each recording's pitch was measured (cents: G3 +0, A3 -2, C4 -3, E4 +1, G4 +2, A4 -1, C5 +0, E5 -1, G5 +0, A5 +1, C6 -1, E6 +1, G6 -1) and corrected where 5 cents or more off. Finished notes measure -4 to +1 cents.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch wrapper), which shifts pitch while keeping the recording's timing, and level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Made from | Semitones |
|---|---|---|
| G3 | G3 | recorded |
| G#3 | G3 | +1 |
| A3 | A3 | recorded |
| A#3 | A3 | +1 |
| B3 | C4 | -1 |
| C4 | C4 | recorded |
| C#4 | C4 | +1 |
| D4 | C4 | +2 |
| D#4 | E4 | -1 |
| E4 | E4 | recorded |
| F4 | E4 | +1 |
| F#4 | G4 | -1 |
| G4 | G4 | recorded |
| G#4 | G4 | +1 |
| A4 | A4 | recorded |
| A#4 | A4 | +1 |
| B4 | C5 | -1 |
| C5 | C5 | recorded |
| C#5 | C5 | +1 |
| D5 | C5 | +2 |
| D#5 | E5 | -1 |
| E5 | E5 | recorded |
| F5 | E5 | +1 |
| F#5 | G5 | -1 |
| G5 | G5 | recorded |
| G#5 | G5 | +1 |
| A5 | A5 | recorded |
| A#5 | A5 | +1 |
| B5 | C6 | -1 |
| C6 | C6 | recorded |
| C#6 | C6 | +1 |
| D6 | C6 | +2 |
| D#6 | E6 | -1 |
| E6 | E6 | recorded |
| F6 | E6 | +1 |
| F#6 | G6 | -1 |
| G6 | G6 | recorded |
| G#6 | G6 | +1 |
| A6 | G6 | +2 |

**Loops.** Each recording loops while held, at points chosen for matching pitch, pitch direction, tone and level; the loop starts after 0.5 s, is at least 1 s long, its end is aligned in phase with its start and the seam is crossfaded, with a quarter second of continuation after the loop end. Each made note reuses its source recording's loop, lined up at the new pitch. Loops on the recordings: G3 1.32-4.35 s; A3 0.56-5.35 s; C4 0.86-5.35 s; E4 0.98-6.19 s; G4 0.60-5.24 s; A4 0.56-5.96 s; C5 1.14-5.68 s; E5 0.88-3.64 s; G5 0.98-4.42 s; A5 0.76-5.72 s; C6 0.90-4.06 s; E6 1.40-5.15 s; G6 0.62-7.63 s.

**Attack.** Notes were trimmed so each speaks at the same moment after it starts (from 7-27 ms to 5-12 ms).

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s) across the range, and the line is set to the level of the Tremolo Strings pack so the two can be swapped without changing the mix. Nothing clips.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level.
