# Alto Sax

From Karoryfer Samples' Weresax, an alto saxophone (CC0): alto saxophone, sustain, condenser microphone, p.
https://github.com/sfzinstruments/karoryfer.weresax (`Samples/alto`)

Every note from C#3 to G#5 has its own sample, each from its own recording, played at its own pitch.

**Layer and microphone.** Weresax records each note at two dynamics (p and f) on two microphones (a clean condenser and an overdriven dynamic); this pack is the condenser at p, chosen by listening. The first take (round robin) of each note is used. Weresax's vibrato is made by its sfz instrument, not recorded, so the notes here are straight.

**Recordings.** 32: C#3 to G#5, every semitone. Using the mono recording. The file names count middle C as C3, so each was filed an octave up from a middle-C-is-C4 reading (checked by measuring every note).

**Tuning.** Each recording's pitch was measured: all within 1.3 cents, so none needed correcting (the rule is 5 cents or more). Finished notes measure 0 to +1 cents.

**Loops.** Each recording loops while held, at points chosen for matching pitch, pitch direction, tone and level; the loop starts at least 0.5 s into the note and lasts at least 1 s; its end is aligned in phase with its start and the seam is crossfaded, with a quarter second of continuation after the loop end. Loops (s): C#3 2.38-7.60; D3 1.08-4.38; D#3 2.32-5.95; E3 0.92-6.30; F3 1.24-5.90; F#3 1.08-5.60; G3 0.56-5.63; G#3 0.78-6.27; A3 1.02-5.47; A#3 0.50-5.46; B3 0.60-5.89; C4 0.68-4.91; C#4 0.86-3.79; D4 1.04-5.69; D#4 0.74-6.11; E4 0.78-4.72; F4 1.04-4.12; F#4 1.02-5.00; G4 0.74-5.39; G#4 0.80-5.52; A4 0.78-4.32; A#4 0.72-5.52; B4 0.92-5.23; C5 1.86-5.74; C#5 0.70-4.92; D5 0.50-4.59; D#5 0.98-5.25; E5 0.50-4.06; F5 0.70-5.78; F#5 0.96-5.24; G5 0.68-5.97; G#5 1.04-3.96.

**Attack.** Kept as recorded: each note starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, nothing trimmed. Notes speak 0-32 ms after they start.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s, K-weighted) across the range, set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

**Envelope.** Attack ramp 5 ms, release 0.25 s.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level. Built from the original recordings.

## 1.0.0

First version.
