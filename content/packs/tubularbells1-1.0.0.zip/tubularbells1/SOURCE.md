# tubularbells1

Tubular Bells 1. Source: https://github.com/sgossner/VCSL

ff layer, taken from whichever round robin has each note. The strike tone sits an octave below the loudest partials (they run in a 2:3:4 ratio), so roots are the file names plus 12, D4 to E5.

Ingested by tools/ingest-sfz.js from tubularbells1.sfz.
Range 60-78, tails cut at 6s.

Levels: loudest zone -3.7 dBFS as ingested; every zone given the same gain ×1.284 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
