# dantranhplucked

Dan Tranh Plucked. Source: https://github.com/sgossner/VCSL

Normal plucks at f. Roots are the file names plus 12.

Ingested by tools/ingest-sfz.js from dantranhplucked.sfz.
Range 45-85, tails cut at 4s.

Levels: loudest zone -16.7 dBFS as ingested; every zone given the same gain ×5.722 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.

1.0.1: the C#4 sample (file C#3) measured 52 cents sharp and is removed. The B3 sample, 10 cents sharp, now also plays C#4, and the D#4 sample, 8 cents sharp, also plays D4.

## 1.1.0: tuned, one sample per semitone, even attacks and volume

Pitch: each recording's pitch was measured over the body of the note (from 0.15 s, leaving out the natural sharp glide of the pluck) and corrected. Measured offsets of the recordings, in cents: B2 -2, C#3 +15, D#3 +20, F#3 +2, G#3 +14, B3 +7, D#4 +6, F#4 -8, G#4 -7, B4 -4, C#5 -3, D#5 +1, F#5 -6, G#5 -6, B5 -11. Every note from A2 to C#6 now has its own sample, made from the recording that played it before with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch), shifted by the semitones to the note plus that recording's correction in one pass, which keeps the recording's timing. Recordings already within 5 cents on their own note are untouched. Attacks were aligned so each note speaks at the same moment after it starts (quiet starts trimmed, 2 ms fade-in so no pluck is softened), and each note's gain set onto a smooth line of loudness over its first half second, lowered so nothing clips.
