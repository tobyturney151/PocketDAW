# Piccolo

From Versilian Studios' VSCO 2 Community Edition (CC0): piccolo. Each note starts as its staccato recording and is joined into its sustain recording, which loops for as long as the note is held: short notes keep the tongued start, held notes carry on.
https://github.com/sgossner/VSCO-2-CE (staccato `Woodwinds/Piccolo/Stac`, sustain `Woodwinds/Piccolo/Sus`)

Every note from G5 to G7 has its own sample, played at its own pitch.

**Layers.** Staccato and sustain, one layer each. The first take (round robin) of each note is used.

**Recordings.** Staccato, 5: A#5, G6, A#6, G7, A#7. Sustain, 5: G5, C6, G6, C7, G7. Using the left microphone only: the two microphones are poorly correlated in these recordings, so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Tuning.** Each recording's pitch was measured (cents, staccato: A#5 -5, G6 +2, A#6 0, G7 +4, A#7 +11; sustain: G5 -1, C6 -6, G6 +6, C7 +8, G7 -1) and corrected where 5 cents or more off.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass. Staccatos reach up to 3 semitones past their highest and lowest recordings.

| Note | Staccato from | Sustain from | Joint (ms) | Joins sustain at (s) | Loop (s) |
|---|---|---|---|---|---|
| G5 | A#5 (-3) | G5 | 60-82 | 0.35 | 0.62-5.86 |
| G#5 | A#5 (-2) | G5 (+1) | 60-82 | 0.35 | 0.64-5.89 |
| A5 | A#5 (-1) | G5 (+2) | 60-82 | 0.35 | 0.62-5.86 |
| A#5 | A#5 | C6 (-2) | 85-107 | 0.71 | 0.52-6.43 |
| B5 | A#5 (+1) | C6 (-1) | 85-107 | 0.84 | 0.54-6.32 |
| C6 | A#5 (+2) | C6 | 65-87 | 0.61 | 0.96-6.48 |
| C#6 | A#5 (+3) | C6 (+1) | 65-87 | 0.61 | 0.76-6.50 |
| D6 | A#5 (+4) | C6 (+2) | 65-87 | 0.61 | 0.74-6.49 |
| D#6 | G6 (-4) | C6 (+3) | 65-87 | 0.74 | 0.62-6.18 |
| E6 | G6 (-3) | G6 (-3) | 70-92 | 0.38 | 1.36-5.84 |
| F6 | G6 (-2) | G6 (-2) | 70-92 | 0.37 | 1.36-5.84 |
| F#6 | G6 (-1) | G6 (-1) | 70-92 | 0.37 | 1.36-5.84 |
| G6 | G6 | G6 | 65-87 | 0.37 | 1.35-5.84 |
| G#6 | G6 (+1) | G6 (+1) | 65-87 | 0.37 | 1.35-5.84 |
| A6 | A#6 (-1) | G6 (+2) | 85-107 | 0.37 | 1.37-5.86 |
| A#6 | A#6 | C7 (-2) | 75-97 | 0.08 | 0.79-7.93 |
| B6 | A#6 (+1) | C7 (-1) | 80-102 | 0.08 | 0.80-7.95 |
| C7 | A#6 (+2) | C7 | 75-97 | 0.08 | 0.79-7.93 |
| C#7 | A#6 (+3) | C7 (+1) | 75-97 | 0.08 | 0.80-7.93 |
| D7 | A#6 (+4) | C7 (+2) | 80-102 | 0.08 | 0.80-7.93 |
| D#7 | G7 (-4) | C7 (+3) | 70-92 | 0.07 | 0.80-7.93 |
| E7 | G7 (-3) | G7 (-3) | 70-92 | 0.45 | 0.64-4.93 |
| F7 | G7 (-2) | G7 (-2) | 75-97 | 0.45 | 0.62-4.91 |
| F#7 | G7 (-1) | G7 (-1) | 75-97 | 0.45 | 0.62-4.91 |
| G7 | G7 | G7 | 75-97 | 0.21 | 0.69-4.97 |

**The joint.** For each note:

1. The staccato is left just after its peak, so its tongued start and accent stay whole, and before it has faded 2 dB (here 60-107 ms into the note).
2. The sustain is joined where it has settled (not still swelling in or wavering), at the point that best matches the staccato's tone and pitch.
3. Where the staccato at the joint is 5 cents or more off the sustain, the staccato is retuned to it by varispeed, which keeps the attack crisp (6 of 25 notes, up to 11 cents). Joined notes match within 4 cents.
4. The sustain is moved by up to one cycle of the note to where the two waveforms line up best, and set to the staccato's level there.
5. They are crossfaded over three cycles of the note (22-40 ms) with gains that hold the level steady however well the waveforms line up. Measured across the joint, every note's level stays within -0.9 to +1.0 dB.
6. Tone glide: the sustain comes in with the staccato's tone, harmonic by harmonic, and relaxes to its own over 150 ms, so the brightness of the attack settles as in one played note. The glide changes tone only: each moment keeps its own loudness.
7. Loops: the sustain recording's own loop (pitch, tone and level matched, end aligned in phase, seam crossfaded) is kept where it still starts 0.5 s or later; otherwise a new loop is found the same way (12 of 25 notes). Every loop starts at least 0.5 s in and lasts at least 1 s, with a quarter second of continuation after the loop end.

**Attack.** Kept as recorded: each staccato starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, nothing trimmed.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s, K-weighted) across the range, set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

**Release.** 0.12 s, so short notes stop near the staccato's own length.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level. Built from the original recordings.

## 1.0.0

First version.
