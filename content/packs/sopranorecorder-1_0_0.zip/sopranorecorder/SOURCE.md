# Soprano Recorder

From Versilian Studios' VCSL (Versilian Community Sample Library) (CC0): baroque soprano recorder. Each note starts as its staccato recording and is joined into its sustain recording, which loops for as long as the note is held: short notes keep the tongued start, held notes carry on.
https://github.com/sgossner/VCSL (staccato `Aerophones/Edge-blown Aerophones/Baroque Soprano Recorder/Staccato`, sustain `Aerophones/Edge-blown Aerophones/Baroque Soprano Recorder/Sustain`)

Every note from C5 to C7 has its own sample, played at its own pitch.

**Layers.** Staccato and sustain, one layer each. The first take (round robin) of each note is used.

**Recordings.** Staccato, 12: C5, D5, E5, F#5, G#5, A#5, C6, D6, E6, F#6, G6, A#6. Sustain, 13: C5, D5, E5, F#5, G#5, A#5, C6, D6, E6, F#6, G6, A#6, C7. Using the right microphone only: the two microphones are poorly correlated in these recordings, so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Tuning.** Each recording's pitch was measured (cents, staccato: C5 -2, D5 +4, E5 +6, F#5 +9, G#5 +10, A#5 +9, C6 +3, D6 +1, E6 -2, F#6 +5, G6 +4, A#6 +2; sustain: C5 +4, D5 +4, E5 +8, F#5 +9, G#5 +1, A#5 +2, C6 +1, D6 +2, E6 +4, F#6 +4, G6 +5, A#6 +9, C7 +7) and corrected where 5 cents or more off.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass. Staccatos reach up to 3 semitones past their highest and lowest recordings.

| Note | Staccato from | Sustain from | Joint (ms) | Joins sustain at (s) | Loop (s) |
|---|---|---|---|---|---|
| C5 | C5 | C5 | 165-187 | 0.22 | 0.54-4.77 |
| C#5 | C5 (+1) | C5 (+1) | 170-192 | 0.77 | 0.86-4.42 |
| D5 | D5 | D5 | 125-147 | 0.40 | 0.50-7.51 |
| D#5 | D5 (+1) | D5 (+1) | 145-167 | 0.40 | 0.50-7.52 |
| E5 | E5 | E5 | 165-187 | 0.24 | 2.75-7.82 |
| F5 | E5 (+1) | E5 (+1) | 165-187 | 0.14 | 2.85-7.93 |
| F#5 | F#5 | F#5 | 70-91 | 0.34 | 2.61-7.65 |
| G5 | F#5 (+1) | F#5 (+1) | 80-102 | 0.14 | 2.82-7.88 |
| G#5 | G#5 | G#5 | 100-122 | 0.48 | 0.50-7.64 |
| A5 | G#5 (+1) | G#5 (+1) | 100-122 | 0.48 | 0.50-7.65 |
| A#5 | A#5 | A#5 | 60-82 | 0.12 | 1.34-7.90 |
| B5 | A#5 (+1) | A#5 (+1) | 60-82 | 0.18 | 1.28-7.84 |
| C6 | C6 | C6 | 105-127 | 0.39 | 0.54-7.61 |
| C#6 | C6 (+1) | C6 (+1) | 105-127 | 0.39 | 0.54-7.61 |
| D6 | D6 | D6 | 55-77 | 0.32 | 1.95-7.70 |
| D#6 | D6 (+1) | D6 (+1) | 55-77 | 0.33 | 1.95-7.70 |
| E6 | E6 | E6 | 70-92 | 0.31 | 1.62-7.75 |
| F6 | E6 (+1) | E6 (+1) | 70-92 | 0.31 | 1.62-7.73 |
| F#6 | F#6 | F#6 | 121-143 | 0.06 | 2.33-7.35 |
| G6 | G6 | G6 | 115-137 | 0.44 | 2.30-7.38 |
| G#6 | G6 (+1) | G6 (+1) | 115-137 | 0.43 | 2.30-7.39 |
| A6 | A#6 (-1) | A#6 (-1) | 125-147 | 0.28 | 2.53-7.21 |
| A#6 | A#6 | A#6 | 125-147 | 0.34 | 2.47-7.15 |
| B6 | A#6 (+1) | A#6 (+1) | 125-147 | 0.27 | 2.53-7.21 |
| C7 | A#6 (+2) | C7 | 125-147 | 0.60 | 1.09-7.31 |

**The joint.** For each note:

1. The staccato is left just after its peak, so its tongued start and accent stay whole, and before it has faded 2 dB (here 55-192 ms into the note).
2. The sustain is joined where it has settled (not still swelling in or wavering), at the point that best matches the staccato's tone and pitch.
3. Where the staccato at the joint is 5 cents or more off the sustain, the staccato is retuned to it by varispeed, which keeps the attack crisp (3 of 25 notes, up to 13 cents). Joined notes match within 4 cents.
4. The sustain is moved by up to one cycle of the note to where the two waveforms line up best, and set to the staccato's level there.
5. They are crossfaded over three cycles of the note (22-40 ms) with gains that hold the level steady however well the waveforms line up. Measured across the joint, every note's level stays within -1.2 to +0.5 dB.
6. Tone glide: the sustain comes in with the staccato's tone, harmonic by harmonic, and relaxes to its own over 150 ms, so the brightness of the attack settles as in one played note. The glide changes tone only: each moment keeps its own loudness.
7. Loops: the sustain recording's own loop (pitch, tone and level matched, end aligned in phase, seam crossfaded) is kept where it still starts 0.5 s or later; otherwise a new loop is found the same way (7 of 25 notes). Every loop starts at least 0.5 s in and lasts at least 1 s, with a quarter second of continuation after the loop end.

**Attack.** Kept as recorded: each staccato starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, nothing trimmed.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s, K-weighted) across the range, set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

**Release.** 0.12 s, so short notes stop near the staccato's own length.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level. Built from the original recordings.

## 1.0.0

First version.
