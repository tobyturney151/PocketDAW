# steinwayb

Steinway B. Source: https://github.com/sgossner/VCSL

Close microphones, sustain pedal up, layer vl3 of 3. Names are at pitch.

Ingested by tools/ingest-sfz.js from steinwayb.sfz.
Range 21-106, tails cut at 5s.

Levels: loudest zone -2.8 dBFS as ingested; every zone given the same gain ×1.163 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
