# sweeppad

Sweep Pad
---------

Version 2019-08-13

Designed to perform as the General MIDI instrument #96: Synth Pad 8 (sweep). Created by roberto@zenvoid.org for the FreePats project, using ZynAddSubFX / Yoshimi software synthesizers.

Please visit FreePats web pages for updates and more content:
http://freepats.zenvoid.org/


Published under the terms of Creative Commons CC0 public domain dedication:
https://creativecommons.org/publicdomain/zero/1.0/

Ingested by tools/ingest-sfz.js from SweepPad 20190813.sfz.
Range 24-100.

Levels: loudest zone 5.5 dBFS as ingested; every zone given the same gain ×0.448 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
