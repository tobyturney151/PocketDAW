# ambichoir

Ambi Choir — Sonic Pi sample `ambi_choir`, https://freesound.org/people/Exsomniel/sounds/207809/.
Pitch, measured by harmonic-series fit over the whole sample and tracked over time: a sung minor third on C#4, 43 cents flat — almost a quarter-tone. Root C#4, retuned +43 cents to C#4. One sample played from C#3 to C#5 by resampling.

Ingested by tools/ingest-sfz.js from ambichoir.sfz.
Range 49-73, tails cut at 2s.

Levels: loudest peak to -1.5 dBFS; gain ×1.919, so it peaks at -1.5 dBFS.

## 1.1.0: one sample per semitone

The app no longer speeds samples up or slows them down: every note from C#3 to C#5 has its own sample, played at its own pitch. The recorded note (C#4) is unchanged. The other 24 were made from the recording that played them before, pitch-shifted with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch 0.3.1 wrapper), which keeps the recording's timing: attack, vibrato, tremolo, loops and decay arrive as recorded. Each is level-matched to its source recording.

| Note | Made from | Semitones |
|---|---|---|
| C#3 | C#4 | -12 |
| D3 | C#4 | -11 |
| D#3 | C#4 | -10 |
| E3 | C#4 | -9 |
| F3 | C#4 | -8 |
| F#3 | C#4 | -7 |
| G3 | C#4 | -6 |
| G#3 | C#4 | -5 |
| A3 | C#4 | -4 |
| A#3 | C#4 | -3 |
| B3 | C#4 | -2 |
| C4 | C#4 | -1 |
| D4 | C#4 | +1 |
| D#4 | C#4 | +2 |
| E4 | C#4 | +3 |
| F4 | C#4 | +4 |
| F#4 | C#4 | +5 |
| G4 | C#4 | +6 |
| G#4 | C#4 | +7 |
| A4 | C#4 | +8 |
| A#4 | C#4 | +9 |
| B4 | C#4 | +10 |
| C5 | C#4 | +11 |
| C#5 | C#4 | +12 |
