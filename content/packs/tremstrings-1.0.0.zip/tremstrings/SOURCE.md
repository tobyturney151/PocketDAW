# tremstrings

Tremolo — 045-Tremolo Strings from the Discord SFZ GM Bank.

// GM Tremolo Strings
// A custom mix of VCSL and VSCO 2 strings (plus some contrabass string samples) which Samulis pre-panned and rendered in ARIA in m3rds
// License: Creative Commons CC0
// Source: https://vis.versilstudios.com

Ingested by tools/ingest-sfz.js from tremstrings.sfz.
Range 28-96, tails cut at 6s.

Levels: loudest zone -4.0 dBFS as ingested; every zone given the same gain ×1.338 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
