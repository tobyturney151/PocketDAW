# Trumpet

From Versilian Studios' VSCO 2 Community Edition (CC0): trumpet. Each note starts as its staccato recording and is joined into its sustain recording, which loops for as long as the note is held: short notes keep the tongued start, held notes carry on.
https://github.com/sgossner/VSCO-2-CE (staccato `Brass/Trumpet/stac`, sustain `Brass/Trumpet/sus`)

Every note from F3 to C6 has its own sample, played at its own pitch.

**Layers.** Staccato, layer v1 (soft, of v1-v3). Sustain, layer v1 (soft, of v1 and v3). Both chosen by listening; the first take (round robin) of each note is used.

**Recordings.** Staccato, 11: F3, A3, C4, D#4, F4, G4, A#4, D5, F5, A5, C6. Sustain, 10: F3, A3, C4, D#4, G4, A#4, D5, F5, A5, C6. Using the left microphone only: the two microphones are poorly correlated in these recordings, so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Tuning.** Each recording's pitch was measured (cents, staccato: F3 +3, A3 -19, C4 +2, D#4 -4, F4 -1, G4 -1, A#4 -1, D5 +3, F5 -1, A5 -1, C6 -1; sustain: F3 +2, A3 -2, C4 -4, D#4 +1, G4 +8, A#4 +2, D5 0, F5 +2, A5 -3, C6 0) and corrected where 5 cents or more off.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Staccato from | Sustain from | Joint (ms) | Joins sustain at (s) | Loop (s) |
|---|---|---|---|---|---|
| F3 | F3 | F3 | 95-117 | 0.20 | 1.44-7.58 |
| F#3 | F3 (+1) | F3 (+1) | 85-107 | 0.19 | 1.44-7.60 |
| G3 | F3 (+2) | F3 (+2) | 80-102 | 0.09 | 1.53-7.69 |
| G#3 | A3 (-1) | A3 (-1) | 69-91 | 0.22 | 0.91-7.51 |
| A3 | A3 | A3 | 69-91 | 0.22 | 0.91-7.51 |
| A#3 | A3 (+1) | A3 (+1) | 64-86 | 0.22 | 0.90-7.53 |
| B3 | C4 (-1) | C4 (-1) | 110-132 | 0.09 | 2.04-7.54 |
| C4 | C4 | C4 | 110-132 | 0.38 | 1.75-7.25 |
| C#4 | C4 (+1) | C4 (+1) | 105-127 | 0.37 | 1.75-7.25 |
| D4 | D#4 (-1) | D#4 (-1) | 90-112 | 0.12 | 0.51-7.70 |
| D#4 | D#4 | D#4 | 90-112 | 0.12 | 0.51-7.69 |
| E4 | D#4 (+1) | D#4 (+1) | 85-107 | 0.12 | 0.50-7.67 |
| F4 | F4 | D#4 (+2) | 70-92 | 0.19 | 0.62-7.80 |
| F#4 | F4 (+1) | G4 (-1) | 70-92 | 0.09 | 2.36-7.72 |
| G4 | G4 | G4 | 75-97 | 0.20 | 2.26-7.60 |
| G#4 | G4 (+1) | G4 (+1) | 65-87 | 0.50 | 1.94-7.29 |
| A4 | A#4 (-1) | A#4 (-1) | 55-77 | 0.13 | 1.24-7.23 |
| A#4 | A#4 | A#4 | 55-77 | 0.13 | 1.24-7.23 |
| B4 | A#4 (+1) | A#4 (+1) | 75-97 | 0.10 | 1.29-7.28 |
| C5 | A#4 (+2) | A#4 (+2) | 85-107 | 0.11 | 1.29-7.28 |
| C#5 | D5 (-1) | D5 (-1) | 45-67 | 0.11 | 2.44-7.14 |
| D5 | D5 | D5 | 40-62 | 0.11 | 2.43-7.14 |
| D#5 | D5 (+1) | D5 (+1) | 50-72 | 0.11 | 2.44-7.13 |
| E5 | F5 (-1) | F5 (-1) | 80-102 | 0.10 | 0.68-6.80 |
| F5 | F5 | F5 | 85-107 | 0.10 | 0.68-6.78 |
| F#5 | F5 (+1) | F5 (+1) | 85-107 | 0.27 | 0.51-6.64 |
| G5 | F5 (+2) | F5 (+2) | 80-102 | 0.27 | 0.51-6.63 |
| G#5 | A5 (-1) | A5 (-1) | 130-152 | 0.19 | 2.50-7.91 |
| A5 | A5 | A5 | 125-147 | 0.11 | 2.57-7.98 |
| A#5 | A5 (+1) | A5 (+1) | 130-152 | 0.19 | 2.50-7.91 |
| B5 | C6 (-1) | C6 (-1) | 135-157 | 0.44 | 2.37-6.88 |
| C6 | C6 | C6 | 135-157 | 0.43 | 2.38-6.90 |

**The joint.** For each note:

1. The staccato is left just after its peak, so its tongued start and accent stay whole, and before it has faded 2 dB (here 40-157 ms into the note).
2. The sustain is joined where it has settled (not still swelling in or wavering), at the point that best matches the staccato's tone and pitch.
3. Where the staccato at the joint is 5 cents or more off the sustain, the staccato is retuned to it by varispeed, which keeps the attack crisp (11 of 32 notes, up to 26 cents). Joined notes match within 4 cents.
4. The sustain is moved by up to one cycle of the note to where the two waveforms line up best, and set to the staccato's level there.
5. They are crossfaded over three cycles of the note (22-40 ms) with gains that hold the level steady however well the waveforms line up. Measured across the joint, every note's level stays within -1.4 to +0.9 dB.
6. Tone glide: the sustain comes in with the staccato's tone, harmonic by harmonic, and relaxes to its own over 150 ms, so the brightness of the attack settles as in one played note. The glide changes tone only: each moment keeps its own loudness.
7. Loops: the sustain recording's own loop (pitch, tone and level matched, end aligned in phase, seam crossfaded) is kept where it still starts 0.5 s or later; otherwise a new loop is found the same way in the joined note (1 of 32 notes). Every loop starts at least 0.5 s in and lasts at least 1 s, with a quarter second of continuation after the loop end.

**Attack.** Kept as recorded: each staccato starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, nothing trimmed.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s, K-weighted) across the range, set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

**Release.** 0.12 s, so short notes stop near the staccato's own length.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level. Built from the original recordings.

## 1.2.0

Now a hybrid: each note starts as the staccato recording (layer v1, soft) and is joined into the sustain, which loops; release 0.12 s (was 0.25 s), attack ramp 2 ms (was 5 ms). 1.1.0 played the sustain recording alone. It also takes over from the Trumpet Staccato pack, which is retired.

## 1.1.0

Rebuilt from the soft layer (v1 of v1 and v3); 1.0.0 used v3, the louder of two.
