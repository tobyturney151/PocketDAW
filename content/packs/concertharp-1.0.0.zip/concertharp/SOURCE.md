# concertharp

Concert Harp. Source: https://github.com/sgossner/VCSL

Layer f1. Names are at pitch.

Ingested by tools/ingest-sfz.js from concertharp.sfz.
Range 26-103, tails cut at 5s.

Levels: loudest zone -11.8 dBFS as ingested; every zone given the same gain ×3.282 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
