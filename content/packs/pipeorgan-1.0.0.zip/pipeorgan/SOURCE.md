# pipeorgan

Pipe Organ. Source: https://github.com/sgossner/VCSL

The voicing previewed: the loud pedal division for the lower notes (up to F#4 as sounding) and the loud manual (Man3Open) above. No loop points in the source; notes last about 8 s. Roots are the file names plus 12.

Ingested by tools/ingest-sfz.js from pipeorgan.sfz.
Range 34-98, tails cut at 8s.

Levels: loudest zone -6.1 dBFS as ingested; every zone given the same gain ×1.702 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
