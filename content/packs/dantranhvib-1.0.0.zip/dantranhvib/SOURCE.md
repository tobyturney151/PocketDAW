# dantranhvib

Dan Tranh Vib. Source: https://github.com/sgossner/VCSL

Vibrato at ff, the layer previewed. Roots are the file names plus 12.

Ingested by tools/ingest-sfz.js from dantranhvib.sfz.
Range 45-85, tails cut at 4s.

Levels: loudest zone -7.6 dBFS as ingested; every zone given the same gain ×2.011 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
