# uprightkw

# Upright piano KW

Version 2022-02-21

This sound bank has been created from a Kawai upright piano, located in a
living room. Thanks to Inma Martínez de Miguel for kindly letting us access to
her home to play and record the piano.

It was recorded by Gonzalo <humanogonzalo@gmail.com> and Roberto
<roberto@zenvoid.org> on January 2017, using a Zoom H1 portable recorder
mounted on a tripod in front of the piano, approximately at the place where
the head of a piano player would be.

The raw recordings were cropped, edited, and processed by Roberto, using free
software programs. This sound bank, in several formats and qualities, is
available on the FreePats project web pages:
http://freepats.zenvoid.org/Piano/acoustic-grand-piano.html#UprightKW


Published under the terms of Creative Commons CC0 public domain dedication:
https://creativecommons.org/publicdomain/zero/1.0/

Ingested by tools/ingest-sfz.js from UprightPianoKW.sfz.
Range 21-108, tails cut at 5s.
