# hang

Hang tuned in D minor
---------------------

Version 2022-03-30

The Hang is a pitched percussion instrument, made of steel and commonly played with the hands. This sounds have been created from a hang tuned in D minor. Thanks to Mar who kindly let us record her hang for the FreePats project and was the performer during the recording session.

It was recorded on July 2017, at the Medialab-Prado auditorium in Madrid (Spain), by Gonzalo <humanogonzalo@gmail.com> and Roberto <roberto@zenvoid.org>, using a Zoom H1 portable recorder mounted on a tripod.

The raw recordings were cropped, edited, and processed by Roberto, using free software programs.

This sound bank contains the same notes than the real instrument: A3, C4, D4, E4, F4, G4, A4, Bb4, C5, D5. Other notes are silent. Unlike other sound banks, we shouldn't fill missing in-between semitones by varying the pitch of nearby notes. When one note of the hang is played, all other notes resonate in background, creating a characteristic warm compound sound tuned in D minor in this particular case. If the frequency of one note is shifted, its background chords would be shifted as well to random scales.

Please visit FreePats web pages for updates and more content:
http://freepats.zenvoid.org/


Published under the terms of Creative Commons CC0 public domain dedication:
https://creativecommons.org/publicdomain/zero/1.0/

Round robin _01 only. The hang has nine notes (D minor); other keys play the nearest note, pitch-shifted.

Ingested by tools/ingest-sfz.js from Hang-D-minor 20220330.sfz.
Range 55-77, tails cut at 6s.

Levels: loudest zone 3.3 dBFS as ingested; every zone given the same gain ×0.575 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
