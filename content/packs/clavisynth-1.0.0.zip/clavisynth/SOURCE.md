# clavisynth

Clavisynth. Source: https://github.com/sgossner/VCSL

Roots are the file names plus 24 — the patch sounds two octaves above what it is named: `C2` measures 262 Hz with harmonics at 524, 786, 1310.

Ingested by tools/ingest-sfz.js from clavisynth.sfz.
Range 36-100, tails cut at 2.5s.

Levels: loudest zone -19.7 dBFS as ingested; every zone given the same gain ×8.091 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
