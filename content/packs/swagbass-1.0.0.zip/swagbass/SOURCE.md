# swagbass

Bass guitar with Louis Vuitton fabric finish played and mapped by D. Smolken. And refinished, too.
SFZ mappings including string release samples and various noises.
There is one file for regular mappings, one clean (no release samples), one shiny (no release samples, using open string samples for the bottom two octaves), one clean things (no release samples, four round robins playing at once) and finally one for shiny things (no release samples, open strings for bottom two octaves, four round robins at once).
Fifths tuning (CGDA) though the low C string was also sampled tuned down to A. The strings are old and dead d'Addario Chrome flatwounds. Before being Vuittonized the bass used to be an Ibanez BTB-400QM. All samples recorded direct, using neck pickup only, with no effects and the onboard EQ set flat.
Notes have three velocity layers and four round robins, release samples three round robins, noises five round robins.

Royalty-free for all commercial and non-commercial use.
Copyright 2014 Karoryfer Lecolds.

The SFZ's keycenters are right and the file names read an octave high: `c2_f_rr1` measures 33 Hz (C1), mapped at 24.

Ingested by tools/ingest-sfz.js from swagbass_shiny.sfz.
Range 21-67, tails cut at 3s.

Levels: loudest zone -7.9 dBFS as ingested; every zone given the same gain ×2.09 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
