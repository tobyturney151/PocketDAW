# hardbass

Hard Bass — Sonic Pi sample `bass_hard_c`, https://freesound.org/people/ani_music/sounds/165309/.
Pitch, measured by harmonic-series fit over the whole sample and tracked over time: C1: the fundamental is only 1 dB under the C2 partial, and the harmonic fit is clear; 16 cents flat. Root C1, retuned +16 cents to C1. One sample played from A0 to G4 by resampling.

Ingested by tools/ingest-sfz.js from hardbass.sfz.
Range 21-67, tails cut at 2s.

Levels: loudness-matched to Swag Bass G1; gain ×0.224, so it peaks at -13.9 dBFS.

## 1.1.0: one sample per semitone

The app no longer speeds samples up or slows them down: every note from A0 to G4 has its own sample, played at its own pitch. The recorded note (C1) is unchanged. The other 46 were made from the recording that played them before, pitch-shifted with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch 0.3.1 wrapper), which keeps the recording's timing: attack, vibrato, tremolo, loops and decay arrive as recorded. Each is level-matched to its source recording.

| Note | Made from | Semitones |
|---|---|---|
| A0 | C1 | -3 |
| A#0 | C1 | -2 |
| B0 | C1 | -1 |
| C#1 | C1 | +1 |
| D1 | C1 | +2 |
| D#1 | C1 | +3 |
| E1 | C1 | +4 |
| F1 | C1 | +5 |
| F#1 | C1 | +6 |
| G1 | C1 | +7 |
| G#1 | C1 | +8 |
| A1 | C1 | +9 |
| A#1 | C1 | +10 |
| B1 | C1 | +11 |
| C2 | C1 | +12 |
| C#2 | C1 | +13 |
| D2 | C1 | +14 |
| D#2 | C1 | +15 |
| E2 | C1 | +16 |
| F2 | C1 | +17 |
| F#2 | C1 | +18 |
| G2 | C1 | +19 |
| G#2 | C1 | +20 |
| A2 | C1 | +21 |
| A#2 | C1 | +22 |
| B2 | C1 | +23 |
| C3 | C1 | +24 |
| C#3 | C1 | +25 |
| D3 | C1 | +26 |
| D#3 | C1 | +27 |
| E3 | C1 | +28 |
| F3 | C1 | +29 |
| F#3 | C1 | +30 |
| G3 | C1 | +31 |
| G#3 | C1 | +32 |
| A3 | C1 | +33 |
| A#3 | C1 | +34 |
| B3 | C1 | +35 |
| C4 | C1 | +36 |
| C#4 | C1 | +37 |
| D4 | C1 | +38 |
| D#4 | C1 | +39 |
| E4 | C1 | +40 |
| F4 | C1 | +41 |
| F#4 | C1 | +42 |
| G4 | C1 | +43 |
