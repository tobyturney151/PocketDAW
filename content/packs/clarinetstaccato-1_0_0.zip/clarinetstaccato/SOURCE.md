# Clarinet Staccato

From Versilian Studios' VSCO 2 Community Edition (CC0): B♭ clarinet, staccato.
https://github.com/sgossner/VSCO-2-CE (`Woodwinds/Clarinet/stac`)

Every note from D3 to F6 has its own sample, played at its own pitch.

**Layer.** The rule for these packs: the mf layer if there is one, otherwise the second loudest of three or more, or the louder of two. Here that is `v2`. The first take (round robin) of each note is used.

**Recordings.** 11: D3, F3, A#3, D4, F4, A#4, D5, F5, A#5, D6, F6. Using the left microphone only: the two microphones are poorly correlated in these recordings (on some notes nearly opposite), so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Tuning.** Each recording's pitch was measured (cents: D3 -35, F3 -29, A#3 -40, D4 -30, F4 -25, A#4 -10, D5 -16, F5 -20, A#5 -4, D6 0, F6 -2) and corrected where 5 cents or more off. Finished notes measure -4 to +3 cents.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Made from | Semitones |
|---|---|---|
| D3 | D3 | recorded |
| D#3 | D3 | +1 |
| E3 | F3 | -1 |
| F3 | F3 | recorded |
| F#3 | F3 | +1 |
| G3 | F3 | +2 |
| G#3 | A#3 | -2 |
| A3 | A#3 | -1 |
| A#3 | A#3 | recorded |
| B3 | A#3 | +1 |
| C4 | A#3 | +2 |
| C#4 | D4 | -1 |
| D4 | D4 | recorded |
| D#4 | D4 | +1 |
| E4 | F4 | -1 |
| F4 | F4 | recorded |
| F#4 | F4 | +1 |
| G4 | F4 | +2 |
| G#4 | A#4 | -2 |
| A4 | A#4 | -1 |
| A#4 | A#4 | recorded |
| B4 | A#4 | +1 |
| C5 | A#4 | +2 |
| C#5 | D5 | -1 |
| D5 | D5 | recorded |
| D#5 | D5 | +1 |
| E5 | F5 | -1 |
| F5 | F5 | recorded |
| F#5 | F5 | +1 |
| G5 | F5 | +2 |
| G#5 | A#5 | -2 |
| A5 | A#5 | -1 |
| A#5 | A#5 | recorded |
| B5 | A#5 | +1 |
| C6 | A#5 | +2 |
| C#6 | D6 | -1 |
| D6 | D6 | recorded |
| D#6 | D6 | +1 |
| E6 | F6 | -1 |
| F6 | F6 | recorded |

**One-shots.** No loops: each note plays to its natural end, cut 60 dB down with a 30 ms fade.

**Attack.** Kept as recorded: each note starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, nothing trimmed. Notes speak 5-42 ms after they start.

**Volume.** Each note's gain sits on a smooth line of loudness over the first 0.15 s (K-weighted) across the range, and the line is set so the pack plays at the same level as the Plucked Strings pack in the app (headroom for 2 voices included). Nothing clips.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level.
