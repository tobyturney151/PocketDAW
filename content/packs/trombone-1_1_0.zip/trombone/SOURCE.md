# Trombone

From Versilian Studios' VSCO 2 Community Edition (CC0): tenor trombone. Each note starts as its staccato recording and is joined into its sustain recording, which loops for as long as the note is held: short notes keep the tongued start, held notes carry on.
https://github.com/sgossner/VSCO-2-CE (staccato `Brass/Tenor Trombone/stac`, sustain `Brass/Tenor Trombone/sus`)

Every note from A#1 to F4 has its own sample, played at its own pitch.

**Layers.** Staccato, layer v2 (of v1-v4). Sustain, layer v2 (of v1-v3). Both chosen by listening. The first take (round robin) of each note is used.

**Recordings.** Staccato, 7: A#1, F2, A#2, F3, A#3, D4, F4. Sustain, 11: A#1, C#2, D#2, F2, A#2, D3, F3, C4, C#4, D#4, F4. Using the right microphone only: the two microphones are poorly correlated in these recordings, so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Tuning.** Each recording's pitch was measured (cents, staccato: A#1 -2, F2 +10, A#2 0, F3 +2, A#3 0, D4 -1, F4 0; sustain: all within 0.3 cent) and corrected where 5 cents or more off.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Staccato from | Sustain from | Joint (ms) | Joins sustain at (s) | Loop (s) |
|---|---|---|---|---|---|
| A#1 | A#1 | A#1 | 114-154 | 0.66 | 0.56-2.43 |
| B1 | A#1 (+1) | A#1 (+1) | 114-154 | 0.56 | 0.54-2.64 |
| C2 | A#1 (+2) | C#2 (-1) | 123-163 | 0.20 | 0.78-3.46 |
| C#2 | A#1 (+3) | C#2 | 119-159 | 0.33 | 0.65-3.32 |
| D2 | F2 (-3) | C#2 (+1) | 95-135 | 0.30 | 0.66-3.32 |
| D#2 | F2 (-2) | D#2 | 90-128 | 0.68 | 0.56-4.46 |
| E2 | F2 (-1) | D#2 (+1) | 90-126 | 0.72 | 0.52-4.45 |
| F2 | F2 | F2 | 90-124 | 0.13 | 1.58-6.49 |
| F#2 | F2 (+1) | F2 (+1) | 60-93 | 0.46 | 1.22-6.12 |
| G2 | F2 (+2) | F2 (+2) | 90-120 | 0.59 | 1.12-6.02 |
| G#2 | A#2 (-2) | A#2 (-2) | 75-104 | 0.43 | 0.51-7.61 |
| A2 | A#2 (-1) | A#2 (-1) | 80-107 | 0.43 | 0.51-7.62 |
| A#2 | A#2 | A#2 | 75-101 | 0.21 | 0.72-7.83 |
| B2 | A#2 (+1) | A#2 (+1) | 80-104 | 0.26 | 0.68-7.77 |
| C3 | A#2 (+2) | A#2 (+2) | 80-103 | 0.19 | 0.75-7.84 |
| C#3 | A#2 (+3) | D3 (-1) | 65-87 | 0.72 | 0.54-6.30 |
| D3 | F3 (-3) | D3 | 90-112 | 0.61 | 0.50-6.41 |
| D#3 | F3 (-2) | D3 (+1) | 80-102 | 0.60 | 0.50-6.41 |
| E3 | F3 (-1) | F3 (-1) | 95-117 | 0.62 | 0.54-7.30 |
| F3 | F3 | F3 | 85-107 | 0.64 | 0.52-7.28 |
| F#3 | F3 (+1) | F3 (+1) | 95-117 | 0.63 | 0.52-7.29 |
| G3 | F3 (+2) | F3 (+2) | 90-112 | 0.63 | 0.52-7.28 |
| G#3 | A#3 (-2) | F3 (+3) | 80-102 | 0.63 | 0.50-7.25 |
| A3 | A#3 (-1) | C4 (-3) | 60-82 | 0.43 | 1.09-7.14 |
| A#3 | A#3 | C4 (-2) | 70-92 | 0.62 | 0.90-6.96 |
| B3 | A#3 (+1) | C4 (-1) | 75-97 | 0.59 | 0.95-6.99 |
| C4 | A#3 (+2) | C4 | 75-97 | 0.66 | 0.88-6.93 |
| C#4 | D4 (-1) | C#4 | 85-107 | 1.03 | 1.28-6.04 |
| D4 | D4 | C#4 (+1) | 95-117 | 1.02 | 1.34-6.09 |
| D#4 | D4 (+1) | D#4 | 90-112 | 0.50 | 0.77-7.21 |
| E4 | F4 (-1) | D#4 (+1) | 90-112 | 0.52 | 0.75-7.20 |
| F4 | F4 | F4 | 90-112 | 0.75 | 0.52-7.52 |

**The joint.** For each note:

1. The staccato is left just after its peak, so its tongued start and accent stay whole, and before it has faded 2 dB (here 60-163 ms into the note).
2. The sustain is joined where it has settled (not still swelling in or wavering), at the point that best matches the staccato's tone and pitch.
3. Where the staccato at the joint is 5 cents or more off the sustain, the staccato is retuned to it by varispeed, which keeps the attack crisp (5 of 32 notes, up to 25 cents). Joined notes match within 5 cents.
4. The sustain is moved by up to one cycle of the note to where the two waveforms line up best, and set to the staccato's level there.
5. They are crossfaded over three cycles of the note (22-40 ms) with gains that hold the level steady however well the waveforms line up. Measured across the joint, every note's level stays within -2.6 to +2.3 dB.
6. Tone glide: the sustain comes in with the staccato's tone, harmonic by harmonic, and relaxes to its own over 150 ms, so the brightness of the attack settles as in one played note. The glide changes tone only: each moment keeps its own loudness.
7. Loops: the sustain recording's own loop (pitch, tone and level matched, end aligned in phase, seam crossfaded) is kept where it still starts 0.5 s or later; otherwise a new loop is found the same way (15 of 32 notes). Every loop starts at least 0.5 s in and lasts at least 1 s, with a quarter second of continuation after the loop end.

**Attack.** Kept as recorded: each staccato starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, nothing trimmed.

**Hits evened.** Each note's first 0.15 s is set to sit the same amount above its held part (the median across the pack), so short notes come out even: just after the joint the sustain eases over 0.2 s from the joint level to its evened level (here -4.0 to +3.7 dB, at most 6 dB either way), before any loop.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s, K-weighted) across the range, set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

**Release.** 0.12 s, so short notes stop near the staccato's own length.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level. Built from the original recordings.

## 1.1.0

Now a hybrid: each note starts as the staccato recording (layer v2) and is joined into the sustain (layer v2, as in 1.0.0), which loops; release 0.12 s (was 0.25 s), attack ramp 2 ms (was 5 ms); each note's opening hit evened against its held part. It also takes over from the Trombone Staccato pack, which is retired.

## 1.0.0

First version: sustain, layer v2.
