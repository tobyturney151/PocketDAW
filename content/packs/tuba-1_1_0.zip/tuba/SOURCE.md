# Tuba

From Versilian Studios' VSCO 2 Community Edition (CC0): tuba. Each note starts as its staccato recording and is joined into its sustain recording, which loops for as long as the note is held: short notes keep the tongued start, held notes carry on. F1-F#1, below the staccato recordings, play the sustain alone.
https://github.com/sgossner/VSCO-2-CE (staccato `Brass/Tuba/stac`, sustain `Brass/Tuba/sus`)

Every note from F1 to D4 has its own sample, played at its own pitch.

**Layers.** Staccato, layer v2 (loud, of v1 and v2). Sustain, layer v1 (soft, of v1-v3). Both chosen by listening. The first take (round robin) of each note is used.

**Recordings.** Staccato, 8: A#1, D#2, F2, A#2, D3, F3, A#3, D4. Sustain, 8: F1, A#1, D#2, F2, A#2, F3, A#3, D4. Using the right microphone only: the two microphones are poorly correlated in these recordings, so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Refiled or left out.**

- Sustain: left out the D3 recording; its notes are made from the nearest others

**Tuning.** Each recording's pitch was measured (cents, staccato: A#1 -12, D#2 +1, F2 -2, A#2 -10, D3 -10, F3 -4, A#3 -10, D4 +1; sustain: F1 -14, A#1 -5, D#2 +1, F2 -3, A#2 -1, F3 +1, A#3 -1, D4 -2) and corrected where 5 cents or more off.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass. Staccatos reach up to 3 semitones past their lowest recording (A#1, so down to G1); F1-F#1, below that, play the sustain alone. The D3 sustain recording is left out: held, it carries noticeably more breath than its neighbours, on the harmonics where filtering can't reach it. D3 and D#3 are made from F3, and C#3 from A#2.

| Note | Staccato from | Sustain from | Joint (ms) | Joins sustain at (s) | Loop (s) |
|---|---|---|---|---|---|
| F1 | — (sustain alone) | F1 | — | — | 1.08-3.04 |
| F#1 | — (sustain alone) | F1 (+1) | — | — | 1.08-3.04 |
| G1 | A#1 (-3) | F1 (+2) | 125-165 | 0.62 | 0.58-2.54 |
| G#1 | A#1 (-2) | A#1 (-2) | 146-186 | 0.50 | 2.11-6.22 |
| A1 | A#1 (-1) | A#1 (-1) | 146-186 | 0.49 | 2.12-6.24 |
| A#1 | A#1 | A#1 | 155-195 | 0.48 | 2.14-6.26 |
| B1 | A#1 (+1) | A#1 (+1) | 141-181 | 0.49 | 2.11-6.21 |
| C2 | A#1 (+2) | A#1 (+2) | 150-190 | 0.51 | 2.10-6.21 |
| C#2 | D#2 (-2) | D#2 (-2) | 115-155 | 0.59 | 2.52-6.57 |
| D2 | D#2 (-1) | D#2 (-1) | 149-189 | 0.60 | 2.55-6.58 |
| D#2 | D#2 | D#2 | 145-183 | 0.58 | 2.57-6.62 |
| E2 | D#2 (+1) | D#2 (+1) | 115-151 | 0.58 | 2.54-6.57 |
| F2 | F2 | F2 | 125-159 | 0.64 | 0.68-7.43 |
| F#2 | F2 (+1) | F2 (+1) | 120-152 | 0.65 | 0.66-7.40 |
| G2 | F2 (+2) | F2 (+2) | 115-145 | 0.65 | 0.58-7.33 |
| G#2 | A#2 (-2) | A#2 (-2) | 125-154 | 0.28 | 2.12-7.51 |
| A2 | A#2 (-1) | A#2 (-1) | 126-153 | 0.22 | 2.19-7.57 |
| A#2 | A#2 | A#2 | 120-145 | 0.50 | 1.90-7.28 |
| B2 | A#2 (+1) | A#2 (+1) | 125-149 | 0.50 | 1.90-7.28 |
| C3 | A#2 (+2) | A#2 (+2) | 130-153 | 0.22 | 2.19-7.58 |
| C#3 | D3 (-1) | A#2 (+3) | 55-77 | 0.26 | 2.07-7.46 |
| D3 | D3 | F3 (-3) | 39-61 | 0.16 | 0.62-7.92 |
| D#3 | D3 (+1) | F3 (-2) | 55-77 | 0.19 | 0.58-7.86 |
| E3 | F3 (-1) | F3 (-1) | 125-147 | 0.23 | 0.62-7.92 |
| F3 | F3 | F3 | 130-152 | 0.23 | 0.62-7.92 |
| F#3 | F3 (+1) | F3 (+1) | 95-117 | 0.25 | 0.58-7.87 |
| G3 | F3 (+2) | F3 (+2) | 125-147 | 0.23 | 0.60-7.90 |
| G#3 | A#3 (-2) | A#3 (-2) | 130-152 | 0.27 | 1.20-5.79 |
| A3 | A#3 (-1) | A#3 (-1) | 140-162 | 0.20 | 1.28-5.87 |
| A#3 | A#3 | A#3 | 125-147 | 0.26 | 1.20-5.80 |
| B3 | A#3 (+1) | A#3 (+1) | 124-146 | 0.27 | 1.19-5.79 |
| C4 | A#3 (+2) | A#3 (+2) | 125-147 | 0.27 | 1.19-5.80 |
| C#4 | D4 (-1) | D4 (-1) | 135-157 | 0.58 | 0.56-6.43 |
| D4 | D4 | D4 | 130-152 | 0.15 | 0.76-6.65 |

**The joint.** For each note:

1. The staccato is left just after its peak, so its tongued start and accent stay whole, and before it has faded 2 dB (here 39-195 ms into the note).
2. The sustain is joined where it has settled (not still swelling in or wavering), at the point that best matches the staccato's tone and pitch.
3. Where the staccato at the joint is 5 cents or more off the sustain, the staccato is retuned to it by varispeed, which keeps the attack crisp (13 of 32 notes, up to 27 cents). Joined notes match within 4 cents.
4. The sustain is moved by up to one cycle of the note to where the two waveforms line up best, and set to the staccato's level there.
5. They are crossfaded over three cycles of the note (22-40 ms) with gains that hold the level steady however well the waveforms line up. Measured across the joint, every note's level stays within -3.5 to +2.3 dB.
6. Tone glide: the sustain comes in with the staccato's tone, harmonic by harmonic, and relaxes to its own over 150 ms, so the brightness of the attack settles as in one played note. The glide changes tone only: each moment keeps its own loudness.
7. Loops: the sustain recording's own loop (pitch, tone and level matched, end aligned in phase, seam crossfaded) is kept where it still starts 0.5 s or later; otherwise a new loop is found the same way (10 of 34 notes). Every loop starts at least 0.5 s in and lasts at least 1 s, with a quarter second of continuation after the loop end.

**Attack and breath.** The staccato recordings carry more air than the sustains, which in a joined note arrives with every start and then vanishes. Two things take it out of the staccato part: each staccato starts 10 ms before its tone comes within 20 dB of its peak, skipping the air before the note speaks, and between the harmonics the staccato is turned down 18 dB (short-time spectrum) while the harmonics pass untouched. Breath sitting right on a harmonic can't be separated and stays. A 2 ms fade-in; the tongued start itself is kept. The notes played by the sustain alone (F1-F#1) start 10 ms before their tone is within 20 dB of its held level.

**Hits evened.** Each note's first 0.15 s is set to sit the same amount above its held part (the median across the pack), so short notes come out even: just after the joint the sustain eases over 0.2 s from the joint level to its evened level (here -2.0 to +6.0 dB, at most 6 dB either way), before any loop.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s, K-weighted) across the range, set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

**Release.** 0.12 s, so short notes stop near the staccato's own length.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level. Built from the original recordings.

## 1.1.0

Now a hybrid: each note starts as the staccato recording (layer v2, with its breath lowered and its lead-in trimmed) and is joined into the sustain, which loops. The sustain is now the soft layer v1 (1.0.0 used v2), without its D3 recording. F1-F#1, below the staccato recordings, play the sustain alone with its lead-in trimmed. Release 0.12 s (was 0.25 s), attack ramp 2 ms (was 5 ms); each note's opening hit evened against its held part. It also takes over from the Tuba Staccato pack, which is retired.

## 1.0.0

First version: sustain, layer v2.
