# tbdpad2

TBD Minor Pad 2 — Sonic Pi sample `tbd_pad_2`, donated to Sonic Pi by The Black Dog.
A clean G minor 7 — G, B♭, D, F. G2 is 7 dB under the loudest partial, and real. Retuned -7 cents to G2. One sample played an octave either side, G1 to G3, so the sound is never stretched far.

Ingested by tools/ingest-sfz.js from tbdpad2.sfz.
Range 31-55, tails cut at 4s.

Levels: loudest peak to -1.5 dBFS; gain ×2.419.
