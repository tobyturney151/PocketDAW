# droneloop

Drone Loop — Sonic Pi sample `loop_drone_g_97`, https://freesound.org/people/hullum/sounds/415570/.
A steady G1 drone, two bars at 97 bpm, confirmed by its third harmonic D3. The last 150 ms are crossfaded into the start so a held note loops without a click. Retuned +5 cents to G1. One sample played an octave either side, G0 to G2, so the sound is never stretched far.

Ingested by tools/ingest-sfz.js from droneloop.sfz.
Range 19-43.

Levels: loudest peak to -1.5 dBFS; gain ×1.663.

## 1.1.0: one sample per semitone

The app no longer speeds samples up or slows them down: every note from G0 to G2 has its own sample, played at its own pitch. The recorded note (G1) is unchanged. The other 24 were made from the recording that played them before, pitch-shifted with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch 0.3.1 wrapper), which keeps the recording's timing: attack, vibrato, tremolo, loops and decay arrive as recorded. Each is level-matched to its source recording. Looping notes reuse their source's loop, with the same start, end and crossfade, lined up with the waveform at the new pitch. Seams slightly above our strict check: E1.

| Note | Made from | Semitones |
|---|---|---|
| G0 | G1 | -12 |
| G#0 | G1 | -11 |
| A0 | G1 | -10 |
| A#0 | G1 | -9 |
| B0 | G1 | -8 |
| C1 | G1 | -7 |
| C#1 | G1 | -6 |
| D1 | G1 | -5 |
| D#1 | G1 | -4 |
| E1 | G1 | -3 |
| F1 | G1 | -2 |
| F#1 | G1 | -1 |
| G#1 | G1 | +1 |
| A1 | G1 | +2 |
| A#1 | G1 | +3 |
| B1 | G1 | +4 |
| C2 | G1 | +5 |
| C#2 | G1 | +6 |
| D2 | G1 | +7 |
| D#2 | G1 | +8 |
| E2 | G1 | +9 |
| F2 | G1 | +10 |
| F#2 | G1 | +11 |
| G2 | G1 | +12 |
