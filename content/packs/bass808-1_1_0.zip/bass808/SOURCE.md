# bass808

808 Bass — built from the TR-808 bass drum in Michael Fischer's Roland TR-808 Rhythm Composer Sound Sample Set 1.0.0 (1994), republished under CC0 1.0 by TidalCycles: https://github.com/tidalcycles/sounds-tr808-fischer

Source file: bd8/BD2510.WAV — Tone 2.5, Decay 1.0, the 3-second recording (the kit's kick is BD2550, Decay 5.0).

Processing, in order, so the shipped file is not the untouched recording:
1. Retuned by -22 cents. Every Fischer kick settles at 49.6 Hz after its pitch sweep; G1 is 49.0 Hz.
2. The app's click sweep (clickLayer.js, amount 0.2) mixed into the first 12 ms, so the note has an onset a phone speaker can play.
3. Soft drive: tanh at a factor of 2.5, which adds the 2nd and 3rd harmonics (82 and 124 Hz at E1) that let the note be heard on a small speaker.
One sample, root G1, played across A0 to D3 by resampling, so the decay lengthens on low notes and shortens on high ones, as a pitched 808 does.

Ingested by tools/ingest-sfz.js from bass808.sfz.
Range 21-50, tails cut at 3s.

Levels: matched by loudness, not peak — a sine's crest factor is about half a bass guitar's, so a peak match would play it far louder. Gain ×0.172 sets the first second's RMS to Swag Bass on the same G1 (-22.8 dBFS). Peak as it plays: -14.4 dBFS.

## 1.1.0: one sample per semitone

The app no longer speeds samples up or slows them down: every note from A0 to D3 has its own sample, played at its own pitch. The recorded note (G1) is unchanged. The other 29 were made from the recording that played them before, pitch-shifted with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch 0.3.1 wrapper), which keeps the recording's timing: attack, vibrato, tremolo, loops and decay arrive as recorded. Each is level-matched to its source recording.

| Note | Made from | Semitones |
|---|---|---|
| A0 | G1 | -10 |
| A#0 | G1 | -9 |
| B0 | G1 | -8 |
| C1 | G1 | -7 |
| C#1 | G1 | -6 |
| D1 | G1 | -5 |
| D#1 | G1 | -4 |
| E1 | G1 | -3 |
| F1 | G1 | -2 |
| F#1 | G1 | -1 |
| G#1 | G1 | +1 |
| A1 | G1 | +2 |
| A#1 | G1 | +3 |
| B1 | G1 | +4 |
| C2 | G1 | +5 |
| C#2 | G1 | +6 |
| D2 | G1 | +7 |
| D#2 | G1 | +8 |
| E2 | G1 | +9 |
| F2 | G1 | +10 |
| F#2 | G1 | +11 |
| G2 | G1 | +12 |
| G#2 | G1 | +13 |
| A2 | G1 | +14 |
| A#2 | G1 | +15 |
| B2 | G1 | +16 |
| C3 | G1 | +17 |
| C#3 | G1 | +18 |
| D3 | G1 | +19 |
