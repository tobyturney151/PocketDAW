# hauntedhum

Haunted Hum — Sonic Pi sample `ambi_haunted_hum`, https://freesound.org/people/kaligari/sounds/35392/.
Pitch, measured by harmonic-series fit over the whole sample and tracked over time: D3, 25 cents flat, with a separate sub-layer on D2 16 dB down and detuned layers beating against each other — the haunted sound. D3 rather than D2 because there are no odd harmonics of D2 at all (A2 and A3 sit 60-70 dB down). Root D3, retuned +25 cents to D3. One sample played from D2 to D4 by resampling.

Ingested by tools/ingest-sfz.js from hauntedhum.sfz.
Range 38-62, tails cut at 10s.

Levels: loudest peak to -1.5 dBFS; gain ×3.488, so it peaks at -1.5 dBFS.
