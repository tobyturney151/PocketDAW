# glasshum

Glass Hum — Sonic Pi sample `ambi_glass_hum`, https://freesound.org/people/kaligari/sounds/35391/.
Pitch, measured by harmonic-series fit over the whole sample and tracked over time: A2: the loudest partial is A3, but E4 and C#5 are odd harmonics of 110 Hz, so the fundamental is A2. Root A2, left as recorded (+0 cents). One sample played from A1 to A3 by resampling.

Ingested by tools/ingest-sfz.js from glasshum.sfz.
Range 33-57, tails cut at 10s.

Levels: loudest peak to -1.5 dBFS; gain ×2.929, so it peaks at -1.5 dBFS.

1.1.0: every zone now loops while its note is held. The loop starts once the attack settles and ends late in the sustain where the level matches; the end is aligned in phase with the start, the seam crossfaded, and a quarter second of continuation follows it.
