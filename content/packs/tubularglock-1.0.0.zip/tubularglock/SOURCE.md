# tubularglock

Tubular Glock. Source: https://github.com/sgossner/VCSL

Medium strikes. Each note is one partial cluster, and that is the pitch: six octaves above the file names, G6 to A7. Each note was shifted to its nearest semitone (the top notes were up to 44 cents sharp).

Ingested by tools/ingest-sfz.js from tubularglock.sfz.
Range 89-107, tails cut at 4s.

Levels: loudest zone -15.3 dBFS as ingested; every zone given the same gain ×4.916 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
