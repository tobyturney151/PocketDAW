# Clarinet

From Versilian Studios' VSCO 2 Community Edition (CC0): B♭ clarinet, sustain (long).
https://github.com/sgossner/VSCO-2-CE (`Woodwinds/Clarinet/susLong`)

Every note from D3 to F6 has its own sample, played at its own pitch.

**Layer.** The loudest layer (v3 of v1-v3), chosen by listening. The first take (round robin) of each note is used.

**Recordings.** 11: D3, F3, A#3, D4, F4, A#4, D5, F5, A#5, D6, F6. Using the left microphone only: the two microphones are poorly correlated in these recordings (on some notes nearly opposite), so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Refiled.** A file named for one note that plays another was filed where it sounds:

- DCClar_susLong_F#5_v3_rr1_sum.wav: named F#5, expected F#6, sounds F6 -2 c

**Tuning.** Each recording's pitch was measured (cents: D3 +3, F3 +2, A#3 +1, D4 +2, F4 +1, A#4 +2, D5 +2, F5 +1, A#5 +2, D6 0, F6 -2) and corrected where 5 cents or more off. Finished notes measure -2 to +3 cents.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Made from | Semitones |
|---|---|---|
| D3 | D3 | recorded |
| D#3 | D3 | +1 |
| E3 | F3 | -1 |
| F3 | F3 | recorded |
| F#3 | F3 | +1 |
| G3 | F3 | +2 |
| G#3 | A#3 | -2 |
| A3 | A#3 | -1 |
| A#3 | A#3 | recorded |
| B3 | A#3 | +1 |
| C4 | A#3 | +2 |
| C#4 | D4 | -1 |
| D4 | D4 | recorded |
| D#4 | D4 | +1 |
| E4 | F4 | -1 |
| F4 | F4 | recorded |
| F#4 | F4 | +1 |
| G4 | F4 | +2 |
| G#4 | A#4 | -2 |
| A4 | A#4 | -1 |
| A#4 | A#4 | recorded |
| B4 | A#4 | +1 |
| C5 | A#4 | +2 |
| C#5 | D5 | -1 |
| D5 | D5 | recorded |
| D#5 | D5 | +1 |
| E5 | F5 | -1 |
| F5 | F5 | recorded |
| F#5 | F5 | +1 |
| G5 | F5 | +2 |
| G#5 | A#5 | -2 |
| A5 | A#5 | -1 |
| A#5 | A#5 | recorded |
| B5 | A#5 | +1 |
| C6 | A#5 | +2 |
| C#6 | D6 | -1 |
| D6 | D6 | recorded |
| D#6 | D6 | +1 |
| E6 | F6 | -1 |
| F6 | F6 | recorded |

**Loops.** Each recording loops while held, at points chosen for matching pitch, pitch direction, tone and level; the loop starts at least 0.5 s into the note and lasts at least 1 s; its end is aligned in phase with its start and the seam is crossfaded, with a quarter second of continuation after the loop end. Made notes reuse their recording's loop. Loops on the recordings (s): D3 2.28-6.29; F3 0.70-6.78; A#3 1.02-7.98; D4 0.68-7.98; F4 0.50-7.60; A#4 0.54-7.94; D5 0.56-7.78; F5 2.86-7.74; A#5 1.16-7.96; D6 1.34-7.66; F6 1.26-7.46.

**Attack.** Each note starts 10 ms before its tone comes within 20 dB of its full level, skipping the quiet lead-in before the reed speaks, with a 2 ms fade-in; the tongued attack itself is kept. Notes speak 5-30 ms after they start.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s) across the range, and the line is set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level.

## 1.1.0

Rebuilt from the loudest layer (v3 of v1-v3); 1.0.0 used v2, the second loudest. Each recording now starts 10 ms before its tone is within 20 dB of its full level: the clarinet recordings open with a quiet lead-in of up to 0.2 s, which left short notes ending before they sounded. The tongued attack itself is kept; notes now speak within 30 ms.
