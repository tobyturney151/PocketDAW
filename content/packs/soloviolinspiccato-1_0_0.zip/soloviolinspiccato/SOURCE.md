# Solo Violin Spiccato

From Versilian Studios' VSCO 2 Community Edition (CC0): solo violin, spiccato, soft layer.
https://github.com/sgossner/VSCO-2-CE (folder `Strings/Solo Violin/spic`)

Every note from G3 to C7 has its own sample, played at its own pitch.

**Recordings.** 15 soft-layer recordings (LLVln_spic_<note>_v1_rr1.wav, first round robin where there are several): G3, A3, C4, E4, G4, A4, C5, E5, G5, A5, C6, E6, G6, A6, C7. The file names in this folder are written an octave low (`LLVln_spic_C3_v1_rr1.wav` sounds C4), so each was filed an octave up. Only the left microphone is used: the two channels of these solo recordings are poorly correlated, and summing them to mono thinned notes by 1 to 4 dB with notches of up to 9 dB in some bands.

**Tuning.** Each recording's pitch was measured (cents: G3 -4, A3 +6, C4 +10, E4 +4, G4 +10, A4 +4, C5 +4, E5 -0, G5 +0, A5 -6, C6 -0, E6 -3, G6 +0, A6 -1, C7 +2) and corrected where 5 cents or more off. Finished notes measure -6 to +4 cents.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch wrapper), which shifts pitch while keeping the recording's timing, and level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Made from | Semitones |
|---|---|---|
| G3 | G3 | recorded |
| G#3 | G3 | +1 |
| A3 | A3 | recorded |
| A#3 | A3 | +1 |
| B3 | C4 | -1 |
| C4 | C4 | recorded |
| C#4 | C4 | +1 |
| D4 | C4 | +2 |
| D#4 | E4 | -1 |
| E4 | E4 | recorded |
| F4 | E4 | +1 |
| F#4 | G4 | -1 |
| G4 | G4 | recorded |
| G#4 | G4 | +1 |
| A4 | A4 | recorded |
| A#4 | A4 | +1 |
| B4 | C5 | -1 |
| C5 | C5 | recorded |
| C#5 | C5 | +1 |
| D5 | C5 | +2 |
| D#5 | E5 | -1 |
| E5 | E5 | recorded |
| F5 | E5 | +1 |
| F#5 | G5 | -1 |
| G5 | G5 | recorded |
| G#5 | G5 | +1 |
| A5 | A5 | recorded |
| A#5 | A5 | +1 |
| B5 | C6 | -1 |
| C6 | C6 | recorded |
| C#6 | C6 | +1 |
| D6 | C6 | +2 |
| D#6 | E6 | -1 |
| E6 | E6 | recorded |
| F6 | E6 | +1 |
| F#6 | G6 | -1 |
| G6 | G6 | recorded |
| G#6 | G6 | +1 |
| A6 | A6 | recorded |
| A#6 | A6 | +1 |
| B6 | C7 | -1 |
| C7 | C7 | recorded |

**One-shots.** No loops: each note plays to its natural end, cut 60 dB down with a 30 ms fade.

**Attack.** Attacks already land within 7 ms of each other; they were aligned to within 3 ms (2 ms fade-in where trimmed).

**Volume.** Each note's gain sits on a smooth line of loudness over the first 0.15 s (K-weighted, so the pluck and the ring are both even) across the range, and the line is set to the level of the Plucked Strings pack so the two can be swapped without changing the mix. Nothing clips.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level.
