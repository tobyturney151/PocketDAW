# tbdpad4

TBD Minor Pad 4 — Sonic Pi sample `tbd_pad_4`, donated to Sonic Pi by The Black Dog.
An E♭ major chord with added notes over an E♭3 bass, whose harmonic B♭3 confirms it. Retuned -10 cents to D#3. One sample played an octave either side, D#2 to D#4, so the sound is never stretched far.

Ingested by tools/ingest-sfz.js from tbdpad4.sfz.
Range 39-63, tails cut at 4s.

Levels: loudest peak to -1.5 dBFS; gain ×1.475.
