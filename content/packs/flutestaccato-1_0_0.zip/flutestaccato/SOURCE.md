# Flute Staccato

From Versilian Studios' VSCO 2 Community Edition (CC0): flute, staccato.
https://github.com/sgossner/VSCO-2-CE (`Woodwinds/Flute/stac`)

Every note from A4 to C7 has its own sample, played at its own pitch.

**Layer.** The rule for these packs: the mf layer if there is one, otherwise the second loudest of three or more, or the louder of two. Here that is `v3`; notes that have no `v3` recording use their nearest layer (C7 `v2`). The first take (round robin) of each note is used.

**Recordings.** 8: A4, C5, E5, A5, C6, E6, A6, C7. Using the left microphone only: the two microphones are poorly correlated in these recordings (on some notes nearly opposite), so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Tuning.** Each recording's pitch was measured (cents: A4 +1, C5 +4, E5 +1, A5 +4, C6 -2, E6 -2, A6 -2, C7 0) and corrected where 5 cents or more off. Finished notes measure -3 to +4 cents.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Made from | Semitones |
|---|---|---|
| A4 | A4 | recorded |
| A#4 | A4 | +1 |
| B4 | C5 | -1 |
| C5 | C5 | recorded |
| C#5 | C5 | +1 |
| D5 | C5 | +2 |
| D#5 | E5 | -1 |
| E5 | E5 | recorded |
| F5 | E5 | +1 |
| F#5 | E5 | +2 |
| G5 | A5 | -2 |
| G#5 | A5 | -1 |
| A5 | A5 | recorded |
| A#5 | A5 | +1 |
| B5 | C6 | -1 |
| C6 | C6 | recorded |
| C#6 | C6 | +1 |
| D6 | C6 | +2 |
| D#6 | E6 | -1 |
| E6 | E6 | recorded |
| F6 | E6 | +1 |
| F#6 | E6 | +2 |
| G6 | A6 | -2 |
| G#6 | A6 | -1 |
| A6 | A6 | recorded |
| A#6 | A6 | +1 |
| B6 | C7 | -1 |
| C7 | C7 | recorded |

**One-shots.** No loops: each note plays to its natural end, cut 60 dB down with a 30 ms fade.

**Attack.** Kept as recorded: each note starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, nothing trimmed. Notes speak 10-50 ms after they start.

**Volume.** Each note's gain sits on a smooth line of loudness over the first 0.15 s (K-weighted) across the range, and the line is set so the pack plays at the same level as the Plucked Strings pack in the app (headroom for 2 voices included). Nothing clips.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level.
