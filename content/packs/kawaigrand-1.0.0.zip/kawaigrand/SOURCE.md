# kawaigrand

Kawai Grand. Source: https://github.com/sgossner/VCSL

Player-position microphones, layer v3. Roots are the file names plus 12.

Ingested by tools/ingest-sfz.js from kawaigrand.sfz.
Range 21-108, tails cut at 5s.

Levels: loudest zone -14.0 dBFS as ingested; every zone given the same gain ×4.204 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
