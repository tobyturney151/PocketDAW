# Tenor Sax

From Versilian Studios' VCSL (Versilian Community Sample Library) (CC0): tenor saxophone (Brett). Each note starts as its staccato recording and is joined into its sustain recording, which loops for as long as the note is held: short notes keep the tongued start, held notes carry on.
https://github.com/sgossner/VCSL (staccato `Aerophones/Reed Aerophones/Tenor Saxophone/Staccato`, sustain `Aerophones/Reed Aerophones/Tenor Saxophone/Non-Vibrato`)

Every note from G#2 to E6 has its own sample, played at its own pitch.

**Layers.** Staccato, layer vl2 (loud, of vl1 and vl2). Non-vibrato sustain, layer vl2 (soft, of vl2 and vl3). Both chosen by listening; the first take (round robin) of each note is used.

**Recordings.** Staccato, 23: G#2, A#2, C3, D3, E3, F#3, G#3, A3, C4, D4, E4, F#4, G#4, A#4, C5, D5, E5, F5, G#5, A5, C6, D6, E6. Sustain, 23: G#2, A#2, C3, D3, E3, F#3, G#3, A#3, C4, D4, E4, F#4, G#4, A#4, C5, D5, E5, F#5, G#5, A#5, C6, D6, E6. Using the right microphone only: the two microphones are poorly correlated in these recordings, so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Tuning.** Each recording's pitch was measured (cents, staccato: G#2 -3, A#2 -1, C3 +2, D3 -3, E3 -1, F#3 +2, G#3 +2, A3 +3, C4 -5, D4 -4, E4 -3, F#4 -1, G#4 +1, A#4 -2, C5 0, D5 0, E5 -1, F5 +1, G#5 +3, A5 +1, C6 0, D6 +1, E6 +3; sustain: all within 0.3 cent) and corrected where 5 cents or more off.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Staccato from | Sustain from | Joint (ms) | Joins sustain at (s) | Loop (s) |
|---|---|---|---|---|---|
| G#2 | G#2 | G#2 | 79-108 | 0.14 | 1.70-6.64 |
| A2 | G#2 (+1) | G#2 (+1) | 65-92 | 0.10 | 1.72-6.65 |
| A#2 | A#2 | A#2 | 90-116 | 0.33 | 0.50-6.56 |
| B2 | A#2 (+1) | A#2 (+1) | 95-119 | 0.21 | 0.58-6.62 |
| C3 | C3 | C3 | 70-93 | 0.13 | 2.08-6.74 |
| C#3 | C3 (+1) | C3 (+1) | 70-92 | 0.13 | 2.08-6.74 |
| D3 | D3 | D3 | 84-106 | 0.09 | 2.29-7.24 |
| D#3 | D3 (+1) | D3 (+1) | 85-107 | 0.08 | 2.31-7.25 |
| E3 | E3 | E3 | 60-82 | 0.17 | 0.55-6.80 |
| F3 | E3 (+1) | E3 (+1) | 60-82 | 0.16 | 0.56-6.81 |
| F#3 | F#3 | F#3 | 35-57 | 0.30 | 0.60-6.88 |
| G3 | F#3 (+1) | F#3 (+1) | 35-57 | 0.36 | 0.53-6.80 |
| G#3 | G#3 | G#3 | 65-87 | 0.23 | 2.46-5.73 |
| A3 | A3 | G#3 (+1) | 100-122 | 0.48 | 2.24-5.50 |
| A#3 | A3 (+1) | A#3 | 105-127 | 0.55 | 1.19-5.42 |
| B3 | C4 (-1) | A#3 (+1) | 30-52 | 0.61 | 1.06-5.28 |
| C4 | C4 | C4 | 35-57 | 0.29 | 2.60-5.49 |
| C#4 | C4 (+1) | C4 (+1) | 30-52 | 0.30 | 2.59-5.48 |
| D4 | D4 | D4 | 50-72 | 0.66 | 1.13-5.96 |
| D#4 | D4 (+1) | D4 (+1) | 50-72 | 0.12 | 1.67-6.49 |
| E4 | E4 | E4 | 75-97 | 0.44 | 0.50-5.50 |
| F4 | E4 (+1) | E4 (+1) | 60-82 | 0.18 | 0.60-5.71 |
| F#4 | F#4 | F#4 | 40-62 | 0.43 | 0.89-6.06 |
| G4 | F#4 (+1) | F#4 (+1) | 40-62 | 0.50 | 0.82-5.97 |
| G#4 | G#4 | G#4 | 45-67 | 0.23 | 2.15-5.17 |
| A4 | G#4 (+1) | G#4 (+1) | 45-67 | 0.05 | 2.33-5.35 |
| A#4 | A#4 | A#4 | 50-72 | 0.50 | 1.85-7.14 |
| B4 | A#4 (+1) | A#4 (+1) | 50-72 | 0.17 | 2.18-7.48 |
| C5 | C5 | C5 | 55-77 | 0.07 | 0.94-5.33 |
| C#5 | C5 (+1) | C5 (+1) | 45-67 | 0.07 | 0.93-5.30 |
| D5 | D5 | D5 | 60-82 | 0.87 | 1.63-5.51 |
| D#5 | D5 (+1) | D5 (+1) | 65-87 | 0.87 | 1.64-5.52 |
| E5 | E5 | E5 | 70-92 | 0.47 | 1.25-5.48 |
| F5 | F5 | E5 (+1) | 105-127 | 0.66 | 1.11-5.33 |
| F#5 | F5 (+1) | F#5 | 95-117 | 0.07 | 0.71-4.06 |
| G5 | G#5 (-1) | F#5 (+1) | 59-81 | 0.10 | 0.64-4.00 |
| G#5 | G#5 | G#5 | 55-77 | 0.22 | 0.54-3.18 |
| A5 | A5 | G#5 (+1) | 40-62 | 0.27 | 0.50-3.12 |
| A#5 | A5 (+1) | A#5 | 30-52 | 0.25 | 0.50-4.16 |
| B5 | C6 (-1) | A#5 (+1) | 85-107 | 0.26 | 0.54-4.20 |
| C6 | C6 | C6 | 80-102 | 0.06 | 1.66-5.52 |
| C#6 | C6 (+1) | C6 (+1) | 75-97 | 0.06 | 1.65-5.53 |
| D6 | D6 | D6 | 85-107 | 0.18 | 0.58-6.19 |
| D#6 | D6 (+1) | D6 (+1) | 80-102 | 0.18 | 0.62-6.23 |
| E6 | E6 | E6 | 50-72 | 0.15 | 1.19-4.09 |

**The joint.** For each note:

1. The staccato is left just after its peak, so its tongued start and accent stay whole, and before it has faded 2 dB (here 30-127 ms into the note).
2. The sustain is joined where it has settled (not still swelling in or wavering), at the point that best matches the staccato's tone and pitch.
3. Where the staccato at the joint is 5 cents or more off the sustain, the staccato is retuned to it by varispeed, which keeps the attack crisp (24 of 45 notes, up to 17 cents). Joined notes match within 5 cents.
4. The sustain is moved by up to one cycle of the note to where the two waveforms line up best, and set to the staccato's level there.
5. They are crossfaded over three cycles of the note (22-40 ms) with gains that hold the level steady however well the waveforms line up. Measured across the joint, every note's level stays within -1.0 to +1.7 dB.
6. Tone glide: the sustain comes in with the staccato's tone, harmonic by harmonic, and relaxes to its own over 150 ms, so the brightness of the attack settles as in one played note. The glide changes tone only: each moment keeps its own loudness.
7. Loops: the sustain recording's own loop (pitch, tone and level matched, end aligned in phase, seam crossfaded) is kept where it still starts 0.5 s or later; otherwise a new loop is found the same way in the joined note (10 of 45 notes). Every loop starts at least 0.5 s in and lasts at least 1 s, with a quarter second of continuation after the loop end.

**Attack.** Kept as recorded: each staccato starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, nothing trimmed.

**Hits evened.** Each note's opening is set to sit the same amount above its held part, so short notes come out as even as long ones: just after the joint the sustain eases over 0.2 s from the joint level to its evened level, before any loop. The amount is measured first on a K-weighted meter (first 0.15 s against 0.3 to 2.3 s), then by listening loudness (an 8th note at 140 bpm against the held part); here -2.5 to +3.4 dB in all, at most 6 dB either way.

**Volume.** Notes are evened by how loud they sound, not just by meter. Each note's gain is set so its held part (0.3 to 1.3 s) measures the same listening loudness (Zwicker, ISO 532-1, in phon) as every other note, at a typical listening level; then all gains move together so the pack plays at the same level as before (the Violins pack's, with headroom for 2 voices). A K-weighted meter, used before, reads the recordings' different brightness as level, which left neighbouring notes up to 7 phon apart. Nothing clips.

**Release.** 0.12 s, so short notes stop near the staccato's own length.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level. Built from the original recordings.

## 1.4.0

Volume evened note by note by listening loudness: held notes now measure within 0.1 phon of each other (1.3.0: 7.3 phon apart), and short notes within 1.5 phon (1.3.0: 8.4), with no two neighbouring notes more than 1.1 phon apart (1.3.0: 7.0, D#4 to E4). Each note's opening hit is evened against its held part. The joints, loops, layers and the pack's overall level are unchanged.

## 1.3.0

The staccato part is now layer vl2 (the louder of two), chosen by listening to every staccato and sustain pairing; 1.2.0 used vl1. The sustain is unchanged (vl2).

## 1.2.0

Now a hybrid: each note starts as the staccato recording (layer vl1, soft) and is joined into the sustain, which loops; release 0.12 s (was 0.25 s), attack ramp 2 ms (was 5 ms). 1.1.0 played the sustain recording alone. It also takes over from the Tenor Sax Staccato pack, which is retired.

## 1.1.0

Rebuilt from the soft layer (vl2 of vl2 and vl3); 1.0.0 used vl3, the louder of two.
