# dantranhplucked

Dan Tranh Plucked. Source: https://github.com/sgossner/VCSL

Normal plucks at f. Roots are the file names plus 12.

Ingested by tools/ingest-sfz.js from dantranhplucked.sfz.
Range 45-85, tails cut at 4s.

Levels: loudest zone -16.7 dBFS as ingested; every zone given the same gain ×5.722 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
