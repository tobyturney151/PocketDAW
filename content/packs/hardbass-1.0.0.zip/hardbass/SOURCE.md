# hardbass

Hard Bass — Sonic Pi sample `bass_hard_c`, https://freesound.org/people/ani_music/sounds/165309/.
Pitch, measured by harmonic-series fit over the whole sample and tracked over time: C1: the fundamental is only 1 dB under the C2 partial, and the harmonic fit is clear; 16 cents flat. Root C1, retuned +16 cents to C1. One sample played from A0 to G4 by resampling.

Ingested by tools/ingest-sfz.js from hardbass.sfz.
Range 21-67, tails cut at 2s.

Levels: loudness-matched to Swag Bass G1; gain ×0.224, so it peaks at -13.9 dBFS.
