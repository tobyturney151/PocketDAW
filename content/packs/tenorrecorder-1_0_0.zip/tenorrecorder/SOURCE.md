# Tenor Recorder

From Versilian Studios' VCSL (Versilian Community Sample Library) (CC0): baroque tenor recorder. Each note starts as its staccato recording and is joined into its sustain recording, which loops for as long as the note is held: short notes keep the tongued start, held notes carry on.
https://github.com/sgossner/VCSL (staccato `Aerophones/Edge-blown Aerophones/Baroque Tenor Recorder/Staccato`, sustain `Aerophones/Edge-blown Aerophones/Baroque Tenor Recorder/Sustain`)

Every note from C4 to B5 has its own sample, played at its own pitch.

**Layers.** Staccato and sustain, one layer each. The first take (round robin) of each note is used.

**Recordings.** Staccato, 12: C4, D4, E4, F#4, G#4, A#4, C5, D5, E5, F#5, G#5, B5. Sustain, 12: C4, D4, E4, F#4, G#4, A#4, D5, E5, F#5, G#5, A5, C6. Using the left microphone only: the two microphones are poorly correlated in these recordings, so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Refiled or left out.**

- Sustain: left out the C5 recording; its notes are made from the nearest others

**Tuning.** Each recording's pitch was measured (cents, staccato: C4 +12, D4 0, E4 +8, F#4 +2, G#4 0, A#4 -6, C5 +6, D5 +4, E5 0, F#5 -5, G#5 +8, B5 +3; sustain: C4 +3, D4 -1, E4 -4, F#4 +2, G#4 +6, A#4 +1, D5 +2, E5 +2, F#5 +4, G#5 0, A5 +3, C6 -3) and corrected where 5 cents or more off.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass. The C5 sustain recording is left out: held, it carries about 10 dB more breath than its neighbours. C5 is made from A#4 (2 semitones up) and C#5 from D5.

| Note | Staccato from | Sustain from | Joint (ms) | Joins sustain at (s) | Loop (s) |
|---|---|---|---|---|---|
| C4 | C4 | C4 | 120-142 | 0.58 | 0.60-6.78 |
| C#4 | C4 (+1) | C4 (+1) | 125-147 | 0.59 | 0.60-6.77 |
| D4 | D4 | D4 | 75-97 | 0.57 | 0.68-7.04 |
| D#4 | D4 (+1) | D4 (+1) | 70-92 | 0.57 | 0.88-7.14 |
| E4 | E4 | E4 | 75-97 | 0.77 | 0.62-7.09 |
| F4 | E4 (+1) | E4 (+1) | 75-97 | 0.70 | 0.70-7.16 |
| F#4 | F#4 | F#4 | 89-111 | 0.59 | 0.54-5.86 |
| G4 | F#4 (+1) | F#4 (+1) | 60-82 | 0.58 | 0.54-5.87 |
| G#4 | G#4 | G#4 | 105-127 | 0.21 | 0.54-7.17 |
| A4 | G#4 (+1) | G#4 (+1) | 100-122 | 0.21 | 0.60-7.22 |
| A#4 | A#4 | A#4 | 130-152 | 0.20 | 0.64-6.83 |
| B4 | A#4 (+1) | A#4 (+1) | 130-152 | 0.20 | 0.64-6.84 |
| C5 | C5 | A#4 (+2) | 60-82 | 0.40 | 0.74-6.55 |
| C#5 | C5 (+1) | D5 (-1) | 55-77 | 0.47 | 0.60-7.71 |
| D5 | D5 | D5 | 120-142 | 0.20 | 0.68-8.10 |
| D#5 | D5 (+1) | D5 (+1) | 120-142 | 0.21 | 0.66-8.07 |
| E5 | E5 | E5 | 100-122 | 0.40 | 0.50-7.54 |
| F5 | E5 (+1) | E5 (+1) | 100-122 | 0.37 | 0.50-7.56 |
| F#5 | F#5 | F#5 | 114-136 | 0.28 | 2.60-7.18 |
| G5 | F#5 (+1) | F#5 (+1) | 115-137 | 0.26 | 2.62-7.22 |
| G#5 | G#5 | G#5 | 125-147 | 0.55 | 0.68-6.73 |
| A5 | G#5 (+1) | A5 | 125-147 | 0.23 | 0.69-7.63 |
| A#5 | B5 (-1) | A5 (+1) | 130-152 | 0.23 | 0.70-7.65 |
| B5 | B5 | C6 (-1) | 135-157 | 0.15 | 0.53-6.05 |

**The joint.** For each note:

1. The staccato is left just after its peak, so its tongued start and accent stay whole, and before it has faded 2 dB (here 55-157 ms into the note).
2. The sustain is joined where it has settled (not still swelling in or wavering), at the point that best matches the staccato's tone and pitch.
3. Where the staccato at the joint is 5 cents or more off the sustain, the staccato is retuned to it by varispeed, which keeps the attack crisp (5 of 24 notes, up to 17 cents). Joined notes match within 4 cents.
4. The sustain is moved by up to one cycle of the note to where the two waveforms line up best, and set to the staccato's level there.
5. They are crossfaded over three cycles of the note (22-40 ms) with gains that hold the level steady however well the waveforms line up. Measured across the joint, every note's level stays within -1.0 to +0.9 dB.
6. Tone glide: the sustain comes in with the staccato's tone, harmonic by harmonic, and relaxes to its own over 150 ms, so the brightness of the attack settles as in one played note. The glide changes tone only: each moment keeps its own loudness.
7. Loops: the sustain recording's own loop (pitch, tone and level matched, end aligned in phase, seam crossfaded) is kept where it still starts 0.5 s or later; otherwise a new loop is found the same way (16 of 24 notes). Every loop starts at least 0.5 s in and lasts at least 1 s, with a quarter second of continuation after the loop end.

**Attack and breath.** The staccato recordings carry more air than the sustains, which in a joined note arrives with every start and then vanishes. Two things take it out of the staccato part: each staccato starts 10 ms before its tone comes within 20 dB of its peak, skipping the air before the note speaks, and between the harmonics the staccato is turned down 18 dB (short-time spectrum) while the harmonics pass untouched. Breath sitting right on a harmonic can't be separated and stays. A 2 ms fade-in; the tongued start itself is kept.

**Hits evened.** Each note's first 0.15 s is set to sit the same amount above its held part (the median across the pack), so short notes come out even: just after the joint the sustain eases over 0.2 s from the joint level to its evened level (here -6.0 to +2.1 dB, at most 6 dB either way), before any loop.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s, K-weighted) across the range, set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

**Release.** 0.12 s, so short notes stop near the staccato's own length.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level. Built from the original recordings.

## 1.0.0

First version.
