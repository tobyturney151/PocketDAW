# balafon

Balafon. Source: https://github.com/sgossner/VCSL

Traditional mallet, layer vl2. Roots are the file names plus 12. Tuning varies by up to 15 cents from note to note, as a traditional balafon does; left as recorded.

Ingested by tools/ingest-sfz.js from balafon.sfz.
Range 59-91, tails cut at 2.5s.

Levels: loudest zone -21.9 dBFS as ingested; every zone given the same gain ×10.491 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
