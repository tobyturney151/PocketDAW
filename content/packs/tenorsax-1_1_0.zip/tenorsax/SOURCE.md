# Tenor Sax

From Versilian Studios' VCSL (Versilian Community Sample Library) (CC0): tenor saxophone (Brett), non-vibrato sustain.
https://github.com/sgossner/VCSL (`Aerophones/Reed Aerophones/Tenor Saxophone/Non-Vibrato`)

Every note from G#2 to E6 has its own sample, played at its own pitch.

**Layer.** The soft layer (vl2 of vl2 and vl3), chosen by listening. The first take (round robin) of each note is used.

**Recordings.** 23: G#2, A#2, C3, D3, E3, F#3, G#3, A#3, C4, D4, E4, F#4, G#4, A#4, C5, D5, E5, F#5, G#5, A#5, C6, D6, E6. Using the right microphone only: the two microphones are poorly correlated in these recordings (on some notes nearly opposite), so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Tuning.** Each recording's pitch was measured (cents: G#2 0, A#2 0, C3 0, D3 0, E3 0, F#3 0, G#3 0, A#3 0, C4 0, D4 0, E4 0, F#4 0, G#4 0, A#4 0, C5 0, D5 0, E5 0, F#5 0, G#5 0, A#5 0, C6 0, D6 0, E6 0) and corrected where 5 cents or more off. Finished notes measure 0 to +4 cents.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Made from | Semitones |
|---|---|---|
| G#2 | G#2 | recorded |
| A2 | G#2 | +1 |
| A#2 | A#2 | recorded |
| B2 | A#2 | +1 |
| C3 | C3 | recorded |
| C#3 | C3 | +1 |
| D3 | D3 | recorded |
| D#3 | D3 | +1 |
| E3 | E3 | recorded |
| F3 | E3 | +1 |
| F#3 | F#3 | recorded |
| G3 | F#3 | +1 |
| G#3 | G#3 | recorded |
| A3 | G#3 | +1 |
| A#3 | A#3 | recorded |
| B3 | A#3 | +1 |
| C4 | C4 | recorded |
| C#4 | C4 | +1 |
| D4 | D4 | recorded |
| D#4 | D4 | +1 |
| E4 | E4 | recorded |
| F4 | E4 | +1 |
| F#4 | F#4 | recorded |
| G4 | F#4 | +1 |
| G#4 | G#4 | recorded |
| A4 | G#4 | +1 |
| A#4 | A#4 | recorded |
| B4 | A#4 | +1 |
| C5 | C5 | recorded |
| C#5 | C5 | +1 |
| D5 | D5 | recorded |
| D#5 | D5 | +1 |
| E5 | E5 | recorded |
| F5 | E5 | +1 |
| F#5 | F#5 | recorded |
| G5 | F#5 | +1 |
| G#5 | G#5 | recorded |
| A5 | G#5 | +1 |
| A#5 | A#5 | recorded |
| B5 | A#5 | +1 |
| C6 | C6 | recorded |
| C#6 | C6 | +1 |
| D6 | D6 | recorded |
| D#6 | D6 | +1 |
| E6 | E6 | recorded |

**Loops.** Each recording loops while held, at points chosen for matching pitch, pitch direction, tone and level; the loop starts at least 0.5 s into the note and lasts at least 1 s; its end is aligned in phase with its start and the seam is crossfaded, with a quarter second of continuation after the loop end. Made notes reuse their recording's loop. Loops on the recordings (s): G#2 1.76-6.70; A#2 0.54-6.59; C3 2.14-6.80; D3 2.30-7.24; E3 0.66-6.92; F#3 0.86-7.14; G#3 2.62-5.89; A#3 1.64-5.87; C4 2.86-5.76; D4 1.74-6.56; E4 0.56-5.66; F#4 1.28-6.44; G#4 2.34-5.36; A#4 2.30-7.60; C5 0.96-5.34; D5 2.44-6.31; E5 1.66-5.90; F#5 0.68-4.04; G#5 0.50-3.13; A#5 0.50-4.15; C6 1.64-5.51; D6 0.50-6.10; E6 1.30-4.21.

**Attack.** Kept as recorded: each note starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, nothing trimmed. Notes speak 2-88 ms after they start.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s) across the range, and the line is set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level.

## 1.1.0

Rebuilt from the soft layer (vl2 of vl2 and vl3); 1.0.0 used vl3, the louder of two.
