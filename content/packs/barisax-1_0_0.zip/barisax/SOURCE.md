# Bari Sax

From Karoryfer Samples' Bear Sax, a 1926 Conn baritone (CC0): looped sustain.
https://github.com/sfzinstruments/karoryfer.bear-sax (`Samples (looped_p, looped_f)`)

Every note from C#2 to G#4 has its own sample, played at its own pitch.

**Layer.** The rule for these packs: the mf layer if there is one, otherwise the second loudest of three or more, or the louder of two. Here that is `looped_f`. The first take (round robin) of each note is used.

**Recordings.** 32: C#2, D2, D#2, E2, F2, F#2, G2, G#2, A2, A#2, B2, C3, C#3, D3, D#3, E3, F3, F#3, G3, G#3, A3, A#3, B3, C4, C#4, D4, D#4, E4, F4, F#4, G4, G#4. Using the mono recording. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Tuning.** Each recording's pitch was measured (cents: C#2 0, D2 0, D#2 0, E2 0, F2 0, F#2 0, G2 0, G#2 0, A2 0, A#2 0, B2 0, C3 0, C#3 0, D3 0, D#3 0, E3 0, F3 0, F#3 0, G3 -1, G#3 0, A3 -1, A#3 0, B3 0, C4 0, C#4 -1, D4 0, D#4 0, E4 0, F4 0, F#4 0, G4 0, G#4 -1) and corrected where 5 cents or more off. Finished notes measure -1 to +1 cents.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Made from | Semitones |
|---|---|---|
| C#2 | C#2 | recorded |
| D2 | D2 | recorded |
| D#2 | D#2 | recorded |
| E2 | E2 | recorded |
| F2 | F2 | recorded |
| F#2 | F#2 | recorded |
| G2 | G2 | recorded |
| G#2 | G#2 | recorded |
| A2 | A2 | recorded |
| A#2 | A#2 | recorded |
| B2 | B2 | recorded |
| C3 | C3 | recorded |
| C#3 | C#3 | recorded |
| D3 | D3 | recorded |
| D#3 | D#3 | recorded |
| E3 | E3 | recorded |
| F3 | F3 | recorded |
| F#3 | F#3 | recorded |
| G3 | G3 | recorded |
| G#3 | G#3 | recorded |
| A3 | A3 | recorded |
| A#3 | A#3 | recorded |
| B3 | B3 | recorded |
| C4 | C4 | recorded |
| C#4 | C#4 | recorded |
| D4 | D4 | recorded |
| D#4 | D#4 | recorded |
| E4 | E4 | recorded |
| F4 | F4 | recorded |
| F#4 | F#4 | recorded |
| G4 | G4 | recorded |
| G#4 | G#4 | recorded |

**Loops.** Each recording loops while held, at points chosen for matching pitch, pitch direction, tone and level; the loop starts at least 0.5 s into the note and lasts at least 1 s; its end is aligned in phase with its start and the seam is crossfaded, with a quarter second of continuation after the loop end. Made notes reuse their recording's loop. Loops on the recordings (s): C#2 1.08-3.78; D2 0.70-3.80; D#2 0.60-4.03; E2 0.58-4.64; F2 1.04-4.84; F#2 0.62-5.84; G2 0.78-5.64; G#2 0.88-4.19; A2 1.00-5.02; A#2 1.48-4.28; B2 1.64-4.30; C3 0.76-7.17; C#3 0.68-6.76; D3 0.80-3.43; D#3 2.02-7.84; E3 2.60-5.66; F3 1.04-5.16; F#3 0.50-6.18; G3 1.34-4.96; G#3 0.56-6.92; A3 0.70-7.37; A#3 2.74-7.92; B3 0.70-7.64; C4 1.94-7.82; C#4 1.42-5.74; D4 1.44-5.90; D#4 1.46-7.92; E4 0.84-6.48; F4 1.46-6.23; F#4 1.86-6.96; G4 2.48-7.92; G#4 1.86-7.10.

**Attack.** Kept as recorded: each note starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, nothing trimmed. Notes speak 0-8 ms after they start.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s) across the range, and the line is set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level.
