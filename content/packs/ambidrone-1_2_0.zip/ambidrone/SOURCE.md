# ambidrone

Ambi Drone — Sonic Pi sample `ambi_drone`, https://freesound.org/people/Autistic%20Lucario/sounds/195341/.
Pitch, measured by harmonic-series fit over the whole sample and tracked over time: C3 with a strong fifth above, 25 cents sharp. Root C3, retuned -25 cents to C3. One sample played from C2 to C4 by resampling.

Ingested by tools/ingest-sfz.js from ambidrone.sfz.
Range 36-60, tails cut at 5s.

Levels: loudest peak to -1.5 dBFS; gain ×2.514, so it peaks at -1.5 dBFS.

1.1.0: every zone now loops while its note is held. The loop starts once the attack settles and ends late in the sustain where the level matches; the end is aligned in phase with the start, the seam crossfaded, and a quarter second of continuation follows it.

## 1.2.0: one sample per semitone

The app no longer speeds samples up or slows them down: every note from C2 to C4 has its own sample, played at its own pitch. The recorded note (C3) is unchanged. The other 24 were made from the recording that played them before, pitch-shifted with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch 0.3.1 wrapper), which keeps the recording's timing: attack, vibrato, tremolo, loops and decay arrive as recorded. Each is level-matched to its source recording. Looping notes reuse their source's loop, with the same start, end and crossfade, lined up with the waveform at the new pitch.

| Note | Made from | Semitones |
|---|---|---|
| C2 | C3 | -12 |
| C#2 | C3 | -11 |
| D2 | C3 | -10 |
| D#2 | C3 | -9 |
| E2 | C3 | -8 |
| F2 | C3 | -7 |
| F#2 | C3 | -6 |
| G2 | C3 | -5 |
| G#2 | C3 | -4 |
| A2 | C3 | -3 |
| A#2 | C3 | -2 |
| B2 | C3 | -1 |
| C#3 | C3 | +1 |
| D3 | C3 | +2 |
| D#3 | C3 | +3 |
| E3 | C3 | +4 |
| F3 | C3 | +5 |
| F#3 | C3 | +6 |
| G3 | C3 | +7 |
| G#3 | C3 | +8 |
| A3 | C3 | +9 |
| A#3 | C3 | +10 |
| B3 | C3 | +11 |
| C4 | C3 | +12 |
