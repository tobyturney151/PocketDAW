# vscocellos

Cellos. Source: https://github.com/sgossner/VSCO-2-CE

Layer v3. Roots are the file names plus 12: `A2` measures 220 Hz.

Ingested by tools/ingest-sfz.js from vscocellos.sfz.
Range 36-79, tails cut at 7s.

Levels: loudest zone -4.7 dBFS as ingested; every zone given the same gain ×1.446 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.

1.1.0: every zone now loops while its note is held. The loop starts once the attack settles and ends late in the sustain where the level matches; the end is aligned in phase with the start, the seam crossfaded, and a quarter second of continuation follows it. Where the sustain fades, the level is held steady across the loop.

## 1.2.0: one sample per semitone

The app no longer speeds samples up or slows them down: every note from C2 to G5 has its own sample, played at its own pitch. The recorded notes (C2, E2, G2, B2, D3, F3, A3, C4, E4, G4, B4, D5, F5) are unchanged. The other 31 were made from the recording that played them before, pitch-shifted with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch 0.3.1 wrapper), which keeps the recording's timing: attack, vibrato, tremolo, loops and decay arrive as recorded. Each is level-matched to its source recording. Looping notes reuse their source's loop, with the same start, end and crossfade, lined up with the waveform at the new pitch.

| Note | Made from | Semitones |
|---|---|---|
| C#2 | C2 | +1 |
| D2 | C2 | +2 |
| D#2 | E2 | -1 |
| F2 | E2 | +1 |
| F#2 | G2 | -1 |
| G#2 | G2 | +1 |
| A2 | G2 | +2 |
| A#2 | B2 | -1 |
| C3 | B2 | +1 |
| C#3 | D3 | -1 |
| D#3 | D3 | +1 |
| E3 | F3 | -1 |
| F#3 | F3 | +1 |
| G3 | F3 | +2 |
| G#3 | A3 | -1 |
| A#3 | A3 | +1 |
| B3 | C4 | -1 |
| C#4 | C4 | +1 |
| D4 | C4 | +2 |
| D#4 | E4 | -1 |
| F4 | E4 | +1 |
| F#4 | G4 | -1 |
| G#4 | G4 | +1 |
| A4 | G4 | +2 |
| A#4 | B4 | -1 |
| C5 | B4 | +1 |
| C#5 | D5 | -1 |
| D#5 | D5 | +1 |
| E5 | F5 | -1 |
| F#5 | F5 | +1 |
| G5 | F5 | +2 |

### Attack and volume

Each note's gain was then set so its sustain loudness sits on a smooth line across the range, lowered just enough that no note would clip.
