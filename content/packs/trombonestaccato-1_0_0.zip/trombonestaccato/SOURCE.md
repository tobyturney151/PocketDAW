# Trombone Staccato

From Versilian Studios' VSCO 2 Community Edition (CC0): tenor trombone, staccato.
https://github.com/sgossner/VSCO-2-CE (`Brass/Tenor Trombone/stac`)

Every note from A#1 to F4 has its own sample, played at its own pitch.

**Layer.** The rule for these packs: the mf layer if there is one, otherwise the second loudest of three or more, or the louder of two. Here that is `v3`. The first take (round robin) of each note is used.

**Recordings.** 7: A#1, F2, A#2, F3, A#3, D4, F4. Using the right microphone only: the two microphones are poorly correlated in these recordings (on some notes nearly opposite), so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Tuning.** Each recording's pitch was measured (cents: A#1 -1, F2 0, A#2 0, F3 +1, A#3 +1, D4 +1, F4 0) and corrected where 5 cents or more off. Finished notes measure -1 to +1 cents.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Made from | Semitones |
|---|---|---|
| A#1 | A#1 | recorded |
| B1 | A#1 | +1 |
| C2 | A#1 | +2 |
| C#2 | A#1 | +3 |
| D2 | F2 | -3 |
| D#2 | F2 | -2 |
| E2 | F2 | -1 |
| F2 | F2 | recorded |
| F#2 | F2 | +1 |
| G2 | F2 | +2 |
| G#2 | A#2 | -2 |
| A2 | A#2 | -1 |
| A#2 | A#2 | recorded |
| B2 | A#2 | +1 |
| C3 | A#2 | +2 |
| C#3 | A#2 | +3 |
| D3 | F3 | -3 |
| D#3 | F3 | -2 |
| E3 | F3 | -1 |
| F3 | F3 | recorded |
| F#3 | F3 | +1 |
| G3 | F3 | +2 |
| G#3 | A#3 | -2 |
| A3 | A#3 | -1 |
| A#3 | A#3 | recorded |
| B3 | A#3 | +1 |
| C4 | A#3 | +2 |
| C#4 | D4 | -1 |
| D4 | D4 | recorded |
| D#4 | D4 | +1 |
| E4 | F4 | -1 |
| F4 | F4 | recorded |

**One-shots.** No loops: each note plays to its natural end, cut 60 dB down with a 30 ms fade.

**Attack.** Kept as recorded: each note starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, nothing trimmed. Notes speak 2-15 ms after they start.

**Volume.** Each note's gain sits on a smooth line of loudness over the first 0.15 s (K-weighted) across the range, and the line is set so the pack plays at the same level as the Plucked Strings pack in the app (headroom for 2 voices included). Nothing clips.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level.
