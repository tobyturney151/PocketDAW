# Signature Kit

All 24 one-shots from Signature Sounds' free "Fred Again Styled Drum Kit": seven kicks, five snares, eight claps and four hi-hats. The main kick, snare, clap and hats sit on the MIDI notes the other kits use; the variants sit on notes no other kit uses.

Source: https://signaturesounds.org/

Ingested by `tools/ingest-drumkit.js`: one file per lane, trailing silence trimmed,
levels untouched, mixed to mono and encoded to AAC. The lane table in `lanes.json`
records which file each lane came from; re-run the tool to swap any of them.

| lane | file | from | seconds | peak dB | rms dB |
|---|---|---|---|---|---|
| Hat Open | sigkit/46-hatopen.m4a | 46-hatopen.flac | 0.586 | -5.5 | -26.1 |
| Hat Closed | sigkit/42-hatclosed.m4a | 42-hatclosed.flac | 0.133 | -0.0 | -19.2 |
| Hat 1 | sigkit/44-hat1.m4a | 44-hat1.flac | 0.219 | -2.1 | -24.8 |
| Hat 2 | sigkit/84-hat2.m4a | 84-hat2.flac | 0.213 | -3.3 | -23.2 |
| Clap 1 | sigkit/85-clap1.m4a | 85-clap1.flac | 0.660 | -0.4 | -20.4 |
| Clap 2 | sigkit/86-clap2.m4a | 86-clap2.flac | 0.414 | -0.2 | -20.6 |
| Clap 3 | sigkit/87-clap3.m4a | 87-clap3.flac | 0.429 | -0.1 | -19.4 |
| Clap 4 | sigkit/39-clap4.m4a | 39-clap4.flac | 0.304 | -0.0 | -15.6 |
| Clap 5 | sigkit/88-clap5.m4a | 88-clap5.flac | 0.329 | -1.3 | -18.0 |
| Clap 6 | sigkit/89-clap6.m4a | 89-clap6.flac | 0.192 | -0.2 | -16.4 |
| Clap 7 | sigkit/90-clap7.m4a | 90-clap7.flac | 0.393 | -0.2 | -18.7 |
| Clap 8 | sigkit/91-clap8.m4a | 91-clap8.flac | 0.304 | -1.1 | -19.5 |
| Snare 1 | sigkit/38-snare1.m4a | 38-snare1.flac | 0.228 | 0.0 | -18.8 |
| Snare 2 | sigkit/92-snare2.m4a | 92-snare2.flac | 0.950 | -2.0 | -28.2 |
| Snare 3 | sigkit/93-snare3.m4a | 93-snare3.flac | 0.116 | -0.3 | -18.5 |
| Snare 4 | sigkit/94-snare4.m4a | 94-snare4.flac | 0.198 | -3.6 | -22.3 |
| Snare 5 | sigkit/95-snare5.m4a | 95-snare5.flac | 0.180 | -1.7 | -19.4 |
| Kick 1 | sigkit/96-kick1.m4a | 96-kick1.flac | 0.192 | -0.0 | -8.7 |
| Kick 1b | sigkit/97-kick1b.m4a | 97-kick1b.flac | 0.449 | 0.0 | -12.0 |
| Kick 2 | sigkit/98-kick2.m4a | 98-kick2.flac | 0.293 | -0.0 | -9.7 |
| Kick 3 | sigkit/36-kick3.m4a | 36-kick3.flac | 0.289 | -0.0 | -9.0 |
| Kick 4 | sigkit/99-kick4.m4a | 99-kick4.flac | 0.342 | -0.1 | -10.0 |
| Kick 5 | sigkit/100-kick5.m4a | 100-kick5.flac | 0.192 | -0.0 | -8.7 |
| Kick 6 | sigkit/101-kick6.m4a | 101-kick6.flac | 0.338 | -0.1 | -11.9 |

Originally named "Fred Again Styled Drum Kit"; renamed here so the app does not carry an artist's name.

The silence before each hit was trimmed (two claps began 84 and 107 ms late). Levels follow the balance in Big Rusty: every kick level with the main kick (Kick 3), snares and claps -4.9 dB, closed hats -20.1 dB, the open hat -18.1 dB, by hit loudness. The whole kit was then moved -8.0 dB so its loudness through the five reference grooves matches the other drum kits (-34.7 LUFS).
