# tbdpad4

TBD Minor Pad 4 — Sonic Pi sample `tbd_pad_4`, donated to Sonic Pi by The Black Dog.
An E♭ major chord with added notes over an E♭3 bass, whose harmonic B♭3 confirms it. Retuned -10 cents to D#3. One sample played an octave either side, D#2 to D#4, so the sound is never stretched far.

Ingested by tools/ingest-sfz.js from tbdpad4.sfz.
Range 39-63, tails cut at 4s.

Levels: loudest peak to -1.5 dBFS; gain ×1.475.

1.1.0: every zone now loops while its note is held. The loop starts once the attack settles and ends late in the sustain where the level matches; the end is aligned in phase with the start, the seam crossfaded, and a quarter second of continuation follows it.

## 1.2.0: one sample per semitone

The app no longer speeds samples up or slows them down: every note from D#2 to D#4 has its own sample, played at its own pitch. The recorded note (D#3) is unchanged. The other 24 were made from the recording that played them before, pitch-shifted with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch 0.3.1 wrapper), which keeps the recording's timing: attack, vibrato, tremolo, loops and decay arrive as recorded. Each is level-matched to its source recording. Looping notes reuse their source's loop, with the same start, end and crossfade, lined up with the waveform at the new pitch.

| Note | Made from | Semitones |
|---|---|---|
| D#2 | D#3 | -12 |
| E2 | D#3 | -11 |
| F2 | D#3 | -10 |
| F#2 | D#3 | -9 |
| G2 | D#3 | -8 |
| G#2 | D#3 | -7 |
| A2 | D#3 | -6 |
| A#2 | D#3 | -5 |
| B2 | D#3 | -4 |
| C3 | D#3 | -3 |
| C#3 | D#3 | -2 |
| D3 | D#3 | -1 |
| E3 | D#3 | +1 |
| F3 | D#3 | +2 |
| F#3 | D#3 | +3 |
| G3 | D#3 | +4 |
| G#3 | D#3 | +5 |
| A3 | D#3 | +6 |
| A#3 | D#3 | +7 |
| B3 | D#3 | +8 |
| C4 | D#3 | +9 |
| C#4 | D#3 | +10 |
| D4 | D#3 | +11 |
| D#4 | D#3 | +12 |
