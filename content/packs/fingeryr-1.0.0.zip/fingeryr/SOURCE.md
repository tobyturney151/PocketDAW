# fingeryr

Finger Bass YR
--------------

Version 2019-09-30

Sound samples created by Andrea Biasior <reusenoise@gmail.com> from a Yamaha RBX bass guitar. It was sent for inclusion in FreePats on September 2019. A few small edits to the samples and sound banks were made by <roberto@zenvoid.org> for integration with other sound banks in the FreePats project.

Please visit FreePats web pages for updates and more content:
http://freepats.zenvoid.org/


Published under the terms of Creative Commons CC0 public domain dedication:
https://creativecommons.org/publicdomain/zero/1.0/

Ingested by tools/ingest-sfz.js from FingerBassYR 20190930.sfz.
Range 28-67, tails cut at 3s.

Levels: loudest zone 3.3 dBFS as ingested; every zone given the same gain ×0.573 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
