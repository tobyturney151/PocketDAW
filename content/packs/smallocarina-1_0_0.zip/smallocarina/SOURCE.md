# Small Ocarina

From Versilian Studios' VCSL (Versilian Community Sample Library) (CC0): small ocarina. Each note starts as its staccato recording and is joined into its sustain recording, which loops for as long as the note is held: short notes keep the tongued start, held notes carry on.
https://github.com/sgossner/VCSL (staccato `Aerophones/Edge-blown Aerophones/Ocarina, Small/Staccato`, sustain `Aerophones/Edge-blown Aerophones/Ocarina, Small/Sustain`)

Every note from F5 to C7 has its own sample, played at its own pitch.

**Layers.** Staccato and sustain, one layer each. The first take (round robin) of each note is used.

**Recordings.** Staccato, 13: A5, B5, D6, D#6, E6, F6, F#6, G6, G#6, A6, A#6, B6, C7. Sustain, 10: A#5, C6, D6, E6, F6, G6, G#6, A6, A#6, B6. Using the left microphone only: the two microphones are poorly correlated in these recordings, so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Tuning.** Each recording's pitch was measured (cents, staccato: A5 +6, B5 +8, D6 -1, D#6 +2, E6 +9, F6 -11, F#6 -1, G6 +1, G#6 +2, A6 +1, A#6 0, B6 +2, C7 -2; sustain: A#5 -10, C6 +3, D6 -3, E6 +10, F6 +4, G6 -1, G#6 +16, A6 +17, A#6 -4, B6 +10) and corrected where 5 cents or more off.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass. The range reaches below the lowest recordings so a melody an octave around F5 plays without folding: F5-A5 are made from the lowest sustain recording (A#5) by up to 5 semitones and from the lowest staccato recording (A5) by up to 4; C7 comes from the B6 sustain recording, 1 semitone up.

| Note | Staccato from | Sustain from | Joint (ms) | Joins sustain at (s) | Loop (s) |
|---|---|---|---|---|---|
| F5 | A5 (-4) | A#5 (-5) | 76-98 | 0.29 | 0.63-7.36 |
| F#5 | A5 (-3) | A#5 (-4) | 81-103 | 0.33 | 0.59-7.31 |
| G5 | A5 (-2) | A#5 (-3) | 76-98 | 0.28 | 0.63-7.36 |
| G#5 | A5 (-1) | A#5 (-2) | 86-108 | 0.28 | 0.64-7.37 |
| A5 | A5 | A#5 (-1) | 85-107 | 0.34 | 0.58-7.31 |
| A#5 | A5 (+1) | A#5 | 76-98 | 0.28 | 0.63-7.36 |
| B5 | B5 | A#5 (+1) | 175-197 | 0.34 | 0.68-7.41 |
| C6 | B5 (+1) | C6 | 175-197 | 0.09 | 0.96-7.96 |
| C#6 | D6 (-1) | C6 (+1) | 100-122 | 0.36 | 0.62-7.61 |
| D6 | D6 | D6 | 90-112 | 0.23 | 0.56-6.80 |
| D#6 | D#6 | D6 (+1) | 160-182 | 0.48 | 0.56-6.79 |
| E6 | E6 | E6 | 55-77 | 0.62 | 0.58-5.87 |
| F6 | F6 | F6 | 159-181 | 0.32 | 1.07-7.78 |
| F#6 | F#6 | F6 (+1) | 65-87 | 0.32 | 0.99-7.69 |
| G6 | G6 | G6 | 185-207 | 0.12 | 0.75-7.82 |
| G#6 | G#6 | G#6 | 120-142 | 0.54 | 2.36-7.31 |
| A6 | A6 | A6 | 105-127 | 0.32 | 0.72-7.51 |
| A#6 | A#6 | A#6 | 125-147 | 0.44 | 2.31-7.65 |
| B6 | B6 | B6 | 65-87 | 0.04 | 0.96-7.94 |
| C7 | C7 | B6 (+1) | 148-170 | 0.07 | 1.02-7.99 |

**The joint.** For each note:

1. The staccato is left just after its peak, so its tongued start and accent stay whole, and before it has faded 2 dB (here 55-207 ms into the note).
2. The sustain is joined where it has settled (not still swelling in or wavering), at the point that best matches the staccato's tone and pitch.
3. Where the staccato at the joint is 5 cents or more off the sustain, the staccato is retuned to it by varispeed, which keeps the attack crisp (10 of 20 notes, up to 21 cents). Joined notes match within 4 cents.
4. The sustain is moved by up to one cycle of the note to where the two waveforms line up best, and set to the staccato's level there.
5. They are crossfaded over three cycles of the note (22-40 ms) with gains that hold the level steady however well the waveforms line up. Measured across the joint, every note's level stays within -1.9 to +0.7 dB.
6. Tone glide: the sustain comes in with the staccato's tone, harmonic by harmonic, and relaxes to its own over 150 ms, so the brightness of the attack settles as in one played note. The glide changes tone only: each moment keeps its own loudness.
7. Loops: the sustain recording's own loop (pitch, tone and level matched, end aligned in phase, seam crossfaded) is kept where it still starts 0.5 s or later; otherwise a new loop is found the same way (2 of 20 notes). Every loop starts at least 0.5 s in and lasts at least 1 s, with a quarter second of continuation after the loop end.

**Attack.** Kept as recorded: each staccato starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, nothing trimmed.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s, K-weighted) across the range, set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

**Release.** 0.12 s, so short notes stop near the staccato's own length.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level. Built from the original recordings.

## 1.0.0

First version.
