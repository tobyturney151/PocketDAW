# Solo Violin

From Versilian Studios' VSCO 2 Community Edition (CC0): solo violin, arco with vibrato, loud layer.
https://github.com/sgossner/VSCO-2-CE (folder `Strings/Solo Violin/Arco Vib`)

Every note from G3 to C7 has its own sample, played at its own pitch.

**Recordings.** 15 loud-layer recordings (LLVln_ArcoVib_<note>_f.wav, first round robin where there are several): G3, A3, C4, E4, G4, A4, C5, E5, G5, A5, C6, E6, G6, A6, C7. Only the left microphone is used: the two channels of these solo recordings are poorly correlated, and summing them to mono thinned notes by 1 to 4 dB with notches of up to 9 dB in some bands.

**Tuning.** Each recording's pitch was measured (cents: G3 -1, A3 +2, C4 -6, E4 +5, G4 +2, A4 +15, C5 -0, E5 +15, G5 +6, A5 +5, C6 -3, E6 +10, G6 +3, A6 +8, C7 -5) and corrected where 5 cents or more off. Finished notes measure -4 to +5 cents.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch wrapper), which shifts pitch while keeping the recording's timing, and level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Made from | Semitones |
|---|---|---|
| G3 | G3 | recorded |
| G#3 | G3 | +1 |
| A3 | A3 | recorded |
| A#3 | A3 | +1 |
| B3 | C4 | -1 |
| C4 | C4 | recorded |
| C#4 | C4 | +1 |
| D4 | C4 | +2 |
| D#4 | E4 | -1 |
| E4 | E4 | recorded |
| F4 | E4 | +1 |
| F#4 | G4 | -1 |
| G4 | G4 | recorded |
| G#4 | G4 | +1 |
| A4 | A4 | recorded |
| A#4 | A4 | +1 |
| B4 | C5 | -1 |
| C5 | C5 | recorded |
| C#5 | C5 | +1 |
| D5 | C5 | +2 |
| D#5 | E5 | -1 |
| E5 | E5 | recorded |
| F5 | E5 | +1 |
| F#5 | G5 | -1 |
| G5 | G5 | recorded |
| G#5 | G5 | +1 |
| A5 | A5 | recorded |
| A#5 | A5 | +1 |
| B5 | C6 | -1 |
| C6 | C6 | recorded |
| C#6 | C6 | +1 |
| D6 | C6 | +2 |
| D#6 | E6 | -1 |
| E6 | E6 | recorded |
| F6 | E6 | +1 |
| F#6 | G6 | -1 |
| G6 | G6 | recorded |
| G#6 | G6 | +1 |
| A6 | A6 | recorded |
| A#6 | A6 | +1 |
| B6 | C7 | -1 |
| C7 | C7 | recorded |

**Loops.** Each recording loops while held, at points chosen for matching pitch, pitch direction, tone and level; the loop starts after 0.5 s, is at least 1 s long, its end is aligned in phase with its start and the seam is crossfaded, with a quarter second of continuation after the loop end. Each made note reuses its source recording's loop, lined up at the new pitch. Loops on the recordings: G3 0.64-9.94 s; A3 0.76-9.80 s; C4 2.02-9.94 s; E4 1.74-9.98 s; G4 0.80-9.64 s; A4 0.64-8.98 s; C5 1.78-9.84 s; E5 1.20-9.38 s; G5 0.74-9.66 s; A5 1.38-9.14 s; C6 1.12-9.52 s; E6 1.56-8.46 s; G6 1.38-9.96 s; A6 0.98-9.88 s; C7 1.16-8.22 s.

**Attack.** Bow starts kept: each note begins at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, and nothing is trimmed, so the bite of the bow is heard. The loud recordings already speak quickly: every note speaks within 22 ms of its start.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s) across the range, and the line is set to the level of the Violins pack so the two can be swapped without changing the mix. Nothing clips.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level.

## 1.1.0 — loud layer, bow starts kept

1.0.0 used the soft layer (`_p` files) with each note's bow start trimmed so all notes spoke together. Those soft notes are slow bow swells, 0.4 to 1 s to full tone, with a narrow, slow vibrato, so short notes only ever heard the fade-in and sounded synthetic. 1.1.0 uses the loud layer (`_f` files) at the same volume, keeps every bow start, and was rebuilt (tuning, loops, volume) by the same method.
