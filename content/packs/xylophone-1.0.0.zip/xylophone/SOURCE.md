# xylophone

Xylophone. Source: https://github.com/sgossner/VCSL

Soft mallets at ff, the layer previewed. Roots are the file names plus 12; every note measured 12–16 cents sharp and was shifted down 14 cents.

Ingested by tools/ingest-sfz.js from xylophone.sfz.
Range 65-108, tails cut at 2s.

Levels: loudest zone -9.7 dBFS as ingested; every zone given the same gain ×2.578 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
