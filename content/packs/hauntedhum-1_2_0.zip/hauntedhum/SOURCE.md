# hauntedhum

Haunted Hum — Sonic Pi sample `ambi_haunted_hum`, https://freesound.org/people/kaligari/sounds/35392/.
Pitch, measured by harmonic-series fit over the whole sample and tracked over time: D3, 25 cents flat, with a separate sub-layer on D2 16 dB down and detuned layers beating against each other — the haunted sound. D3 rather than D2 because there are no odd harmonics of D2 at all (A2 and A3 sit 60-70 dB down). Root D3, retuned +25 cents to D3. One sample played from D2 to D4 by resampling.

Ingested by tools/ingest-sfz.js from hauntedhum.sfz.
Range 38-62, tails cut at 10s.

Levels: loudest peak to -1.5 dBFS; gain ×3.488, so it peaks at -1.5 dBFS.

1.1.0: every zone now loops while its note is held. The loop starts once the attack settles and ends late in the sustain where the level matches; the end is aligned in phase with the start, the seam crossfaded, and a quarter second of continuation follows it.

## 1.2.0: one sample per semitone

The app no longer speeds samples up or slows them down: every note from D2 to D4 has its own sample, played at its own pitch. The recorded note (D3) is unchanged. The other 24 were made from the recording that played them before, pitch-shifted with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch 0.3.1 wrapper), which keeps the recording's timing: attack, vibrato, tremolo, loops and decay arrive as recorded. Each is level-matched to its source recording. Looping notes reuse their source's loop, with the same start, end and crossfade, lined up with the waveform at the new pitch.

| Note | Made from | Semitones |
|---|---|---|
| D2 | D3 | -12 |
| D#2 | D3 | -11 |
| E2 | D3 | -10 |
| F2 | D3 | -9 |
| F#2 | D3 | -8 |
| G2 | D3 | -7 |
| G#2 | D3 | -6 |
| A2 | D3 | -5 |
| A#2 | D3 | -4 |
| B2 | D3 | -3 |
| C3 | D3 | -2 |
| C#3 | D3 | -1 |
| D#3 | D3 | +1 |
| E3 | D3 | +2 |
| F3 | D3 | +3 |
| F#3 | D3 | +4 |
| G3 | D3 | +5 |
| G#3 | D3 | +6 |
| A3 | D3 | +7 |
| A#3 | D3 | +8 |
| B3 | D3 | +9 |
| C4 | D3 | +10 |
| C#4 | D3 | +11 |
| D4 | D3 | +12 |
