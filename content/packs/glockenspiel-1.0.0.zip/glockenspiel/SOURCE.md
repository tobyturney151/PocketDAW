# glockenspiel

Glockenspiel. Source: https://github.com/sgossner/VCSL

Medium strikes. Roots are the file names plus 12, so it sounds G5 to C8.

Ingested by tools/ingest-sfz.js from glockenspiel.sfz.
Range 77-108, tails cut at 4s.

Levels: loudest zone -27.1 dBFS as ingested; every zone given the same gain ×19.087 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
