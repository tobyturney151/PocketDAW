# tbdpad1

TBD Minor Pad 1 — Sonic Pi sample `tbd_pad_1`, donated to Sonic Pi by The Black Dog.
A chord over G2 — G, B♭, F, E♭, a G minor 7 colour. Retuned +4 cents to G2. One sample played an octave either side, G1 to G3, so the sound is never stretched far.

Ingested by tools/ingest-sfz.js from tbdpad1.sfz.
Range 31-55, tails cut at 4s.

Levels: loudest peak to -1.5 dBFS; gain ×2.61.

1.1.0: every zone now loops while its note is held. The loop starts once the attack settles and ends late in the sustain where the level matches; the end is aligned in phase with the start, the seam crossfaded, and a quarter second of continuation follows it.

## 1.2.0: one sample per semitone

The app no longer speeds samples up or slows them down: every note from G1 to G3 has its own sample, played at its own pitch. The recorded note (G2) is unchanged. The other 24 were made from the recording that played them before, pitch-shifted with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch 0.3.1 wrapper), which keeps the recording's timing: attack, vibrato, tremolo, loops and decay arrive as recorded. Each is level-matched to its source recording. Looping notes reuse their source's loop, with the same start, end and crossfade, lined up with the waveform at the new pitch. Seams slightly above our strict check: C#2.

| Note | Made from | Semitones |
|---|---|---|
| G1 | G2 | -12 |
| G#1 | G2 | -11 |
| A1 | G2 | -10 |
| A#1 | G2 | -9 |
| B1 | G2 | -8 |
| C2 | G2 | -7 |
| C#2 | G2 | -6 |
| D2 | G2 | -5 |
| D#2 | G2 | -4 |
| E2 | G2 | -3 |
| F2 | G2 | -2 |
| F#2 | G2 | -1 |
| G#2 | G2 | +1 |
| A2 | G2 | +2 |
| A#2 | G2 | +3 |
| B2 | G2 | +4 |
| C3 | G2 | +5 |
| C#3 | G2 | +6 |
| D3 | G2 | +7 |
| D#3 | G2 | +8 |
| E3 | G2 | +9 |
| F3 | G2 | +10 |
| F#3 | G2 | +11 |
| G3 | G2 | +12 |
