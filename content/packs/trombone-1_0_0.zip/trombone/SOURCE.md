# Trombone

From Versilian Studios' VSCO 2 Community Edition (CC0): tenor trombone, sustain.
https://github.com/sgossner/VSCO-2-CE (`Brass/Tenor Trombone/sus`)

Every note from A#1 to F4 has its own sample, played at its own pitch.

**Layer.** The rule for these packs: the mf layer if there is one, otherwise the second loudest of three or more, or the louder of two. Here that is `v2`. The first take (round robin) of each note is used.

**Recordings.** 11: A#1, C#2, D#2, F2, A#2, D3, F3, C4, C#4, D#4, F4. Using the right microphone only: the two microphones are poorly correlated in these recordings (on some notes nearly opposite), so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Tuning.** Each recording's pitch was measured (cents: A#1 0, C#2 0, D#2 0, F2 0, A#2 0, D3 0, F3 0, C4 0, C#4 0, D#4 0, F4 0) and corrected where 5 cents or more off. Finished notes measure 0 to +2 cents.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Made from | Semitones |
|---|---|---|
| A#1 | A#1 | recorded |
| B1 | A#1 | +1 |
| C2 | C#2 | -1 |
| C#2 | C#2 | recorded |
| D2 | C#2 | +1 |
| D#2 | D#2 | recorded |
| E2 | D#2 | +1 |
| F2 | F2 | recorded |
| F#2 | F2 | +1 |
| G2 | F2 | +2 |
| G#2 | A#2 | -2 |
| A2 | A#2 | -1 |
| A#2 | A#2 | recorded |
| B2 | A#2 | +1 |
| C3 | A#2 | +2 |
| C#3 | D3 | -1 |
| D3 | D3 | recorded |
| D#3 | D3 | +1 |
| E3 | F3 | -1 |
| F3 | F3 | recorded |
| F#3 | F3 | +1 |
| G3 | F3 | +2 |
| G#3 | F3 | +3 |
| A3 | C4 | -3 |
| A#3 | C4 | -2 |
| B3 | C4 | -1 |
| C4 | C4 | recorded |
| C#4 | C#4 | recorded |
| D4 | C#4 | +1 |
| D#4 | D#4 | recorded |
| E4 | D#4 | +1 |
| F4 | F4 | recorded |

**Loops.** Each recording loops while held, at points chosen for matching pitch, pitch direction, tone and level; the loop starts at least 0.5 s into the note and lasts at least 1 s; its end is aligned in phase with its start and the seam is crossfaded, with a quarter second of continuation after the loop end. Made notes reuse their recording's loop. Loops on the recordings (s): A#1 0.60-3.00; C#2 0.86-3.53; D#2 0.58-4.86; F2 1.62-6.53; A#2 0.86-7.96; D3 0.70-6.74; F3 0.76-7.62; C4 1.46-7.52; C#4 0.54-6.80; D#4 1.18-7.62; F4 0.54-7.98.

**Attack.** Kept as recorded: each note starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, nothing trimmed. Notes speak 3-47 ms after they start.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s) across the range, and the line is set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level.
