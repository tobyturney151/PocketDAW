# biglittle

Big Little Bass was big, but its heart was little. Big Little Bass is a very big bass guitar (a Washburn AB95 hollowbody, with an 0.175 diameter string on the bottom and shortened double bass strings for the rest) sampled like a very little one - basically playing on the 12th fret and above except for the bottom fourth of the range, effectively giving it the speaking string length of a ukulele bass (up to guitar string length at the bottom of the range).

To register the sforzando bank, drag the Big Little Bass.bank.xml file onto the sforzando interface. Once registered, the instrument will be available in the sforzando loading menu and the GUI will work. If you don't have sforzando installed, download it from the Plogue website first.

Royalty-free for all commercial and non-commercial use. CC-0 license.

Roots are the file names minus 12: `big_little_pluck_e2` measures 41.7 Hz (E1), `a3` 109.5 Hz (A2).

Ingested by tools/ingest-sfz.js from biglittle.sfz.
Range 23-65, tails cut at 3s.

Levels: loudest zone -1.5 dBFS as ingested; every zone given the same gain ×1.006 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
