# trancebass

Trance Bass — Sonic Pi sample `bass_trance_c`, https://freesound.org/people/ani_music/sounds/165329/.
Pitch, measured by harmonic-series fit over the whole sample and tracked over time: C2, 12 cents flat, detuned layers. Root C2, retuned +12 cents to C2. One sample played from A0 to G4 by resampling.

Ingested by tools/ingest-sfz.js from trancebass.sfz.
Range 21-67, tails cut at 4s.

Levels: loudness-matched to Swag Bass G1; gain ×0.224, so it peaks at -10.5 dBFS.
