# Rain & Storm

Rain, thunder, night showers, rain on glass, and three shades of white noise. Every lane loops while its note is held and stops when the note ends.

Source: https://signaturesounds.org/

Ingested by `tools/ingest-drumkit.js`: one file per lane, trailing silence trimmed,
levels untouched, mixed to mono and encoded to AAC. The lane table in `lanes.json`
records which file each lane came from; re-run the tool to swap any of them.

| lane | file | from | seconds | peak dB | rms dB |
|---|---|---|---|---|---|
| Storm 1 | rainstorm/36-storm1.m4a | 36-storm1.flac | 10.430 | -3.1 | -21.3 |
| Storm 2 | rainstorm/37-storm2.m4a | 37-storm2.flac | 11.070 | -3.1 | -21.4 |
| Storm 3 | rainstorm/38-storm3.m4a | 38-storm3.flac | 9.730 | -6.1 | -22.9 |
| Soft Rain 1 | rainstorm/39-softrain1.m4a | 39-softrain1.flac | 8.810 | -32.4 | -53.6 |
| Soft Rain 2 | rainstorm/40-softrain2.m4a | 40-softrain2.flac | 11.230 | -40.4 | -63.2 |
| Soft Rain 3 | rainstorm/41-softrain3.m4a | 41-softrain3.flac | 10.390 | -36.2 | -52.2 |
| Night Rain 1 | rainstorm/42-nightrain1.m4a | 42-nightrain1.flac | 10.250 | -24.0 | -50.4 |
| Night Rain 2 | rainstorm/43-nightrain2.m4a | 43-nightrain2.flac | 10.830 | -28.0 | -48.2 |
| Night Rain 3 | rainstorm/44-nightrain3.m4a | 44-nightrain3.flac | 10.470 | -17.1 | -48.2 |
| Window 1 | rainstorm/45-window1.m4a | 45-window1.flac | 9.330 | -20.6 | -42.6 |
| Window 2 | rainstorm/46-window2.m4a | 46-window2.flac | 9.730 | -19.6 | -41.8 |
| Dark Noise | rainstorm/47-darknoise.m4a | 47-darknoise.flac | 10.950 | -23.3 | -36.4 |
| White Noise | rainstorm/48-whitenoise.m4a | 48-whitenoise.flac | 11.150 | -12.8 | -26.2 |
| Bright Noise | rainstorm/49-brightnoise.m4a | 49-brightnoise.flac | 11.050 | -4.2 | -22.5 |

## Lanes

| MIDI | Lane | Source pack | Recording | Excerpt from | Loop | Level |
|---|---|---|---|---|---|---|
| 36 | Storm 1 | [Rain and Thunder SFX](https://signaturesounds.org/store/p/rain-thunder-sound-effects-free-download-cc0-wav-sample-pack-) | Heavy Rain With Thunder 07.wav | 4.0 s | 2.04–10.18 s | ×0.66 |
| 37 | Storm 2 | [Rain and Thunder SFX](https://signaturesounds.org/store/p/rain-thunder-sound-effects-free-download-cc0-wav-sample-pack-) | Heavy Rain With Thunder 10.wav | 3.2 s | 0.96–10.82 s | ×0.67 |
| 38 | Storm 3 | [Rain and Thunder SFX](https://signaturesounds.org/store/p/rain-thunder-sound-effects-free-download-cc0-wav-sample-pack-) | Heavy Rain With Thunder 04.wav | 0.8 s | 1.22–9.48 s | ×0.75 |
| 39 | Soft Rain 1 | [Light Rain SFX](https://signaturesounds.org/) | Light rain recordings mixed settings-01.wav | 62.5 s | 1.02–8.56 s | ×21.14 |
| 40 | Soft Rain 2 | [Light Rain SFX](https://signaturesounds.org/) | Light rain recordings mixed settings-02.wav | 7.8 s | 0.96–10.98 s | ×60.26 |
| 41 | Soft Rain 3 | [Light Rain SFX](https://signaturesounds.org/) | Light rain recordings mixed settings-05.wav | 70.8 s | 1.00–10.14 s | ×15.49 |
| 42 | Night Rain 1 | [Nighttime Rain](https://signaturesounds.org/store/p/nighttime-rain) | Rain_At_Night_Light_Shower.wav | 96.8 s | 0.96–10.00 s | ×14.17 |
| 43 | Night Rain 2 | [Nighttime Rain](https://signaturesounds.org/store/p/nighttime-rain) | Rain_At_Night_Light_Shower_2.wav | 32.5 s | 1.08–10.58 s | ×11.88 |
| 44 | Night Rain 3 | [Nighttime Rain](https://signaturesounds.org/store/p/nighttime-rain) | Rain_At_Night_Light_Shower_5.wav | 92.2 s | 1.32–10.22 s | ×6.43 |
| 45 | Window 1 | [Rain Hitting Window SFX](https://signaturesounds.org/) | Rain_Hitting_Window_3.wav | 32.8 s | 2.28–9.08 s | ×6.84 |
| 46 | Window 2 | [Rain Hitting Window SFX](https://signaturesounds.org/) | Rain_Hitting_Window_10.wav | 11.5 s | 1.16–9.48 s | ×6.31 |
| 47 | Dark Noise | [White Noise SFX](https://signaturesounds.org/store/p/white-noise-sound-effects-free-download-cc0-wav-sample-pack-) | White Noise-10.wav | 2.5 s | 1.34–10.70 s | ×2.79 |
| 48 | White Noise | [White Noise SFX](https://signaturesounds.org/store/p/white-noise-sound-effects-free-download-cc0-wav-sample-pack-) | White Noise.wav | 5.8 s | 1.16–10.90 s | ×0.77 |
| 49 | Bright Noise | [White Noise SFX](https://signaturesounds.org/store/p/white-noise-sound-effects-free-download-cc0-wav-sample-pack-) | White Noise-4.wav | 5.0 s | 1.26–10.80 s | ×0.47 |

Each excerpt is the steadiest stretch of about 11.5 s in its recording's first two minutes; recordings were picked from each source pack for steadiness, then spread across brightness so lanes differ. Loop seams avoid sudden sounds in both the high band and the full band, and match background level; the last 0.35 s before each loop end is crossfaded into the 0.35 s before its start, with a quarter second of continuation after the end. Recordings whose channels partly cancel when summed use their stronger channel. Levels: -26 LUFS over each loop, peaks under -1 dBFS.
