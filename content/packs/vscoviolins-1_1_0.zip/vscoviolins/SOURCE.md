# vscoviolins

Violins. Source: https://github.com/sgossner/VSCO-2-CE

Layer v2. Roots are the file names plus 12 (VSCO writes middle C as C3): `A3` measures 441 Hz.

Ingested by tools/ingest-sfz.js from vscoviolins.sfz.
Range 55-91, tails cut at 7s.

Levels: loudest zone -15.0 dBFS as ingested; every zone given the same gain ×4.71 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.

1.1.0: every zone now loops while its note is held. The loop starts once the attack settles and ends late in the sustain where the level matches; the end is aligned in phase with the start, the seam crossfaded, and a quarter second of continuation follows it.
