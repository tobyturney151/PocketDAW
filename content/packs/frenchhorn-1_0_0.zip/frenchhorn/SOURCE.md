# French Horn

From Versilian Studios' VSCO 2 Community Edition (CC0): French horn. Each note starts as its staccato recording and is joined into its sustain recording, which loops for as long as the note is held: short notes keep the tongued start, held notes carry on.
https://github.com/sgossner/VSCO-2-CE (staccato `Brass/F Horn/stac`, sustain `Brass/F Horn/sus`)

Every note from A1 to F5 has its own sample, played at its own pitch.

**Layers.** Staccato, layer v1 (soft, of v1-v3). Sustain, layer v1 (soft, of v1-v4; above C4 VSCO recorded the sustain in this layer only). Both chosen by listening. The first take (round robin) of each note is used.

**Recordings.** Staccato, 11: A1, C2, D#2, G2, A#2, D3, F3, A3, C4, D5, F5. Sustain, 11: A1, C2, D#2, G2, A#2, D3, F3, A3, C4, D5, F5. Using the left microphone only: the two microphones are poorly correlated in these recordings, so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Tuning.** Each recording's pitch was measured (cents, staccato: A1 -2, C2 +2, D#2 +3, G2 +2, A#2 +1, D3 -1, F3 0, A3 -1, C4 0, D5 0, F5 0; sustain: A1 -10, C2 -3, D#2 -3, G2 -2, A#2 +4, D3 -1, F3 -2, A3 -6, C4 +2, D5 +4, F5 +1) and corrected where 5 cents or more off.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass. The recordings leave a gap between C4 and D5, so the notes there are made from those two by up to 7 semitones.

| Note | Staccato from | Sustain from | Joint (ms) | Joins sustain at (s) | Loop (s) |
|---|---|---|---|---|---|
| A1 | A1 | A1 | 105-145 | 0.80 | 0.78-3.63 |
| A#1 | A1 (+1) | A1 (+1) | 90-130 | 0.81 | 0.78-3.64 |
| B1 | C2 (-1) | C2 (-1) | 195-235 | 0.16 | 0.77-3.22 |
| C2 | C2 | C2 | 196-236 | 0.15 | 0.78-3.23 |
| C#2 | C2 (+1) | C2 (+1) | 200-240 | 0.39 | 0.55-3.01 |
| D2 | D#2 (-1) | D#2 (-1) | 150-190 | 0.57 | 1.68-6.75 |
| D#2 | D#2 | D#2 | 140-178 | 0.57 | 1.67-6.76 |
| E2 | D#2 (+1) | D#2 (+1) | 155-191 | 0.58 | 1.68-6.75 |
| F2 | D#2 (+2) | D#2 (+2) | 145-179 | 0.57 | 1.67-6.76 |
| F#2 | G2 (-1) | G2 (-1) | 74-107 | 0.51 | 1.62-7.16 |
| G2 | G2 | G2 | 75-105 | 0.52 | 1.61-7.14 |
| G#2 | G2 (+1) | G2 (+1) | 74-103 | 0.52 | 1.61-7.14 |
| A2 | A#2 (-1) | A#2 (-1) | 180-207 | 0.44 | 1.34-6.81 |
| A#2 | A#2 | A#2 | 180-205 | 0.49 | 1.29-6.77 |
| B2 | A#2 (+1) | A#2 (+1) | 175-199 | 0.46 | 1.31-6.79 |
| C3 | A#2 (+2) | A#2 (+2) | 180-203 | 0.46 | 1.32-6.80 |
| C#3 | D3 (-1) | D3 (-1) | 100-122 | 0.66 | 1.77-7.40 |
| D3 | D3 | D3 | 85-107 | 0.66 | 1.75-7.39 |
| D#3 | D3 (+1) | D3 (+1) | 79-101 | 0.65 | 1.75-7.39 |
| E3 | F3 (-1) | F3 (-1) | 80-102 | 0.26 | 1.40-6.58 |
| F3 | F3 | F3 | 70-92 | 0.16 | 1.49-6.67 |
| F#3 | F3 (+1) | F3 (+1) | 130-152 | 0.19 | 1.52-6.70 |
| G3 | F3 (+2) | F3 (+2) | 75-97 | 0.16 | 1.49-6.66 |
| G#3 | A3 (-1) | A3 (-1) | 80-102 | 0.19 | 2.73-7.67 |
| A3 | A3 | A3 | 100-122 | 0.59 | 2.35-7.29 |
| A#3 | A3 (+1) | A3 (+1) | 80-102 | 0.18 | 2.74-7.66 |
| B3 | C4 (-1) | C4 (-1) | 105-127 | 0.31 | 1.37-4.82 |
| C4 | C4 | C4 | 115-137 | 0.32 | 1.37-4.82 |
| C#4 | C4 (+1) | C4 (+1) | 110-132 | 0.33 | 1.36-4.81 |
| D4 | C4 (+2) | C4 (+2) | 110-132 | 0.33 | 1.36-4.81 |
| D#4 | C4 (+3) | C4 (+3) | 115-137 | 0.33 | 1.37-4.83 |
| E4 | C4 (+4) | C4 (+4) | 115-137 | 0.33 | 1.37-4.81 |
| F4 | C4 (+5) | C4 (+5) | 110-132 | 0.30 | 1.39-4.86 |
| F#4 | C4 (+6) | C4 (+6) | 115-137 | 0.30 | 1.39-4.80 |
| G4 | C4 (+7) | C4 (+7) | 110-132 | 0.33 | 1.36-4.81 |
| G#4 | D5 (-6) | D5 (-6) | 60-82 | 0.21 | 1.57-6.81 |
| A4 | D5 (-5) | D5 (-5) | 60-82 | 0.23 | 1.55-6.78 |
| A#4 | D5 (-4) | D5 (-4) | 60-82 | 0.23 | 1.55-6.80 |
| B4 | D5 (-3) | D5 (-3) | 65-87 | 0.23 | 1.56-6.78 |
| C5 | D5 (-2) | D5 (-2) | 60-82 | 0.23 | 1.55-6.79 |
| C#5 | D5 (-1) | D5 (-1) | 65-87 | 0.23 | 1.55-6.80 |
| D5 | D5 | D5 | 60-82 | 0.23 | 1.55-6.79 |
| D#5 | D5 (+1) | D5 (+1) | 65-87 | 0.23 | 1.56-6.80 |
| E5 | F5 (-1) | F5 (-1) | 105-127 | 0.82 | 0.80-4.09 |
| F5 | F5 | F5 | 105-127 | 0.82 | 0.81-4.07 |

**The joint.** For each note:

1. The staccato is left just after its peak, so its tongued start and accent stay whole, and before it has faded 2 dB (here 60-240 ms into the note).
2. The sustain is joined where it has settled (not still swelling in or wavering), at the point that best matches the staccato's tone and pitch.
3. Where the staccato at the joint is 5 cents or more off the sustain, the staccato is retuned to it by varispeed, which keeps the attack crisp (8 of 45 notes, up to 13 cents). Joined notes match within 5 cents.
4. The sustain is moved by up to one cycle of the note to where the two waveforms line up best, and set to the staccato's level there.
5. They are crossfaded over three cycles of the note (22-40 ms) with gains that hold the level steady however well the waveforms line up. Measured across the joint, every note's level stays within -2.5 to +1.4 dB.
6. Tone glide: the sustain comes in with the staccato's tone, harmonic by harmonic, and relaxes to its own over 150 ms, so the brightness of the attack settles as in one played note. The glide changes tone only: each moment keeps its own loudness.
7. Loops: the sustain recording's own loop (pitch, tone and level matched, end aligned in phase, seam crossfaded) is kept where it still starts 0.5 s or later; otherwise a new loop is found the same way (2 of 45 notes). Every loop starts at least 0.5 s in and lasts at least 1 s, with a quarter second of continuation after the loop end.

**Attack and breath.** The staccato recordings carry more air than the sustains, which in a joined note arrives with every start and then vanishes. Two things take it out of the staccato part: each staccato starts 10 ms before its tone comes within 20 dB of its peak, skipping the air before the note speaks, and between the harmonics the staccato is turned down 18 dB (short-time spectrum) while the harmonics pass untouched. Breath sitting right on a harmonic can't be separated and stays. A 2 ms fade-in; the tongued start itself is kept.

**Hits evened.** Each note's first 0.15 s is set to sit the same amount above its held part (the median across the pack), so short notes come out even: just after the joint the sustain eases over 0.2 s from the joint level to its evened level (here -6.0 to +6.0 dB, at most 6 dB either way), before any loop.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s, K-weighted) across the range, set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

**Release.** 0.12 s, so short notes stop near the staccato's own length.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level. Built from the original recordings.

## 1.0.0

First version.
