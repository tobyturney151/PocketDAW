# marimba

Marimba. Source: https://github.com/sgossner/VCSL

Med layer. Roots are the file names plus 12.

Ingested by tools/ingest-sfz.js from marimba.sfz.
Range 39-98, tails cut at 3s.

Levels: loudest zone -34.5 dBFS as ingested; every zone given the same gain ×44.898 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
