# Beach Rocks

All 28 one-shots from Signature Sounds' Beach Rocks Percussions.

Source: https://signaturesounds.org/

Ingested by `tools/ingest-drumkit.js`: one file per lane, trailing silence trimmed,
levels untouched, mixed to mono and encoded to AAC. The lane table in `lanes.json`
records which file each lane came from; re-run the tool to swap any of them.

| lane | file | from | seconds | peak dB | rms dB |
|---|---|---|---|---|---|
| Rock 01 | beachrocks/36-rock01.m4a | 36-rock01.flac | 0.733 | -19.1 | -36.7 |
| Rock 02 | beachrocks/37-rock02.m4a | 37-rock02.flac | 0.690 | -4.5 | -32.0 |
| Rock 03 | beachrocks/38-rock03.m4a | 38-rock03.flac | 0.722 | -29.2 | -49.6 |
| Rock 04 | beachrocks/39-rock04.m4a | 39-rock04.flac | 0.721 | -6.7 | -34.9 |
| Rock 05 | beachrocks/40-rock05.m4a | 40-rock05.flac | 0.448 | -21.7 | -36.0 |
| Rock 06 | beachrocks/41-rock06.m4a | 41-rock06.flac | 0.399 | -23.3 | -43.1 |
| Rock 07 | beachrocks/42-rock07.m4a | 42-rock07.flac | 0.418 | -14.7 | -37.4 |
| Rock 08 | beachrocks/43-rock08.m4a | 43-rock08.flac | 0.427 | -23.1 | -45.3 |
| Rock 09 | beachrocks/44-rock09.m4a | 44-rock09.flac | 0.489 | -9.5 | -33.4 |
| Rock 10 | beachrocks/45-rock10.m4a | 45-rock10.flac | 0.471 | -27.8 | -47.7 |
| Rock 11 | beachrocks/46-rock11.m4a | 46-rock11.flac | 0.543 | -9.8 | -35.0 |
| Rock 12 | beachrocks/47-rock12.m4a | 47-rock12.flac | 0.539 | -19.4 | -40.9 |
| Rock 13 | beachrocks/48-rock13.m4a | 48-rock13.flac | 0.575 | -10.8 | -34.8 |
| Rock 14 | beachrocks/49-rock14.m4a | 49-rock14.flac | 0.505 | -9.4 | -35.9 |
| Rock 15 | beachrocks/50-rock15.m4a | 50-rock15.flac | 0.542 | -6.0 | -30.3 |
| Rock 16 | beachrocks/51-rock16.m4a | 51-rock16.flac | 0.548 | -7.9 | -33.4 |
| Rock 17 | beachrocks/52-rock17.m4a | 52-rock17.flac | 0.647 | -17.0 | -38.0 |
| Rock 18 | beachrocks/53-rock18.m4a | 53-rock18.flac | 0.595 | -6.6 | -38.7 |
| Rock 19 | beachrocks/54-rock19.m4a | 54-rock19.flac | 0.597 | -10.0 | -38.9 |
| Rock 20 | beachrocks/55-rock20.m4a | 55-rock20.flac | 0.686 | -12.2 | -40.4 |
| Rock 21 | beachrocks/56-rock21.m4a | 56-rock21.flac | 0.257 | -6.3 | -30.8 |
| Rock 22 | beachrocks/57-rock22.m4a | 57-rock22.flac | 0.246 | -7.5 | -29.5 |
| Rock 23 | beachrocks/58-rock23.m4a | 58-rock23.flac | 0.264 | -3.7 | -27.3 |
| Rock 24 | beachrocks/59-rock24.m4a | 59-rock24.flac | 0.269 | -31.0 | -49.0 |
| Rock 25 | beachrocks/60-rock25.m4a | 60-rock25.flac | 0.525 | -10.8 | -33.9 |
| Rock 26 | beachrocks/61-rock26.m4a | 61-rock26.flac | 0.520 | -18.7 | -33.8 |
| Rock 27 | beachrocks/62-rock27.m4a | 62-rock27.flac | 0.494 | -6.9 | -29.8 |
| Rock 28 | beachrocks/63-rock28.m4a | 63-rock28.flac | 0.510 | -5.0 | -30.6 |

Every hit is set to the same loudness as Big Rusty's snare (hit loudness, the first 200 ms, K-weighted), peaks under -1 dBFS; the silence before each hit is trimmed.
