# yamahaupright

Yamaha Upright. Source: https://github.com/sgossner/VCSL

Layer vl2; 13 notes, so some are stretched by up to three semitones. Roots are the file names plus 12.

Ingested by tools/ingest-sfz.js from yamahaupright.sfz.
Range 22-98, tails cut at 5s.

Levels: loudest zone -13.6 dBFS as ingested; every zone given the same gain ×4.009 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
