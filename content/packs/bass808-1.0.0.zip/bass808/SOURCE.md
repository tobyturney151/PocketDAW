# bass808

808 Bass — built from the TR-808 bass drum in Michael Fischer's Roland TR-808 Rhythm Composer Sound Sample Set 1.0.0 (1994), republished under CC0 1.0 by TidalCycles: https://github.com/tidalcycles/sounds-tr808-fischer

Source file: bd8/BD2510.WAV — Tone 2.5, Decay 1.0, the 3-second recording (the kit's kick is BD2550, Decay 5.0).

Processing, in order, so the shipped file is not the untouched recording:
1. Retuned by -22 cents. Every Fischer kick settles at 49.6 Hz after its pitch sweep; G1 is 49.0 Hz.
2. The app's click sweep (clickLayer.js, amount 0.2) mixed into the first 12 ms, so the note has an onset a phone speaker can play.
3. Soft drive: tanh at a factor of 2.5, which adds the 2nd and 3rd harmonics (82 and 124 Hz at E1) that let the note be heard on a small speaker.
One sample, root G1, played across A0 to D3 by resampling, so the decay lengthens on low notes and shortens on high ones, as a pitched 808 does.

Ingested by tools/ingest-sfz.js from bass808.sfz.
Range 21-50, tails cut at 3s.

Levels: matched by loudness, not peak — a sine's crest factor is about half a bass guitar's, so a peak match would play it far louder. Gain ×0.172 sets the first second's RMS to Swag Bass on the same G1 (-22.8 dBFS). Peak as it plays: -14.4 dBFS.
