# gretschtwang

Black And Green Guitars is a free sample library for Plogue Sforzando version 1.971 or newer. It contains samples of a green Gretsch Anniversary and a black Hofner Club, recorded and photographed by Brian Wood.

To register the Sforzando bank, drag the Black And Green Guitars.bank.xml file onto the Sforzando interface. Once registered, the instrument will be available in the Sforzando loading menu and the GUI will work.

The bank XML may be broken and unable to register in Plogue Sforzando properly if downloaded from Github via the "Code" button. The XML should be 2692 bytes in order for the digital signature to be correct, but when downloaded and extracted it's 2638 bytes. Downloading from the Releases section is safe, though. On Windows systems it's also apparently possible to copy-paste the contents into a new file in Notepad, save it, and get a file of the correct size.

Royalty-free for all commercial and non-commercial use. Copyright 2022 Karoryfer Lecolds.

Gretsch (the green guitar), ordinary picked notes at the mf layer, first round robin. Roots are the file names minus 12: `e3` measures 82.6 Hz (E2).

Ingested by tools/ingest-sfz.js from gretschtwang.sfz.
Range 40-86, tails cut at 4s.

Levels: loudest zone -15.2 dBFS as ingested; every zone given the same gain ×4.864 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
