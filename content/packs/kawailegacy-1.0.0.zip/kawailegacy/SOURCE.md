# kawailegacy

Kawai Legacy. Source: https://github.com/sgossner/VCSL

The older, sparser Kawai grand set; main microphones, layer v3. Roots are the file names plus 12.

Ingested by tools/ingest-sfz.js from kawailegacy.sfz.
Range 22-108, tails cut at 5s.

Levels: loudest zone -0.3 dBFS as ingested; every zone given the same gain ×0.867 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
