# ambichoir

Ambi Choir — Sonic Pi sample `ambi_choir`, https://freesound.org/people/Exsomniel/sounds/207809/.
Pitch, measured by harmonic-series fit over the whole sample and tracked over time: a sung minor third on C#4, 43 cents flat — almost a quarter-tone. Root C#4, retuned +43 cents to C#4. One sample played from C#3 to C#5 by resampling.

Ingested by tools/ingest-sfz.js from ambichoir.sfz.
Range 49-73, tails cut at 2s.

Levels: loudest peak to -1.5 dBFS; gain ×1.919, so it peaks at -1.5 dBFS.
