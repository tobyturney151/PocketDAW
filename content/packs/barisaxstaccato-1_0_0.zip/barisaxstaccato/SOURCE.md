# Bari Sax Staccato

From Karoryfer Samples' Bear Sax, a 1926 Conn baritone (CC0): staccato.
https://github.com/sfzinstruments/karoryfer.bear-sax (`Samples (vl1-vl4)`)

Every note from C#2 to G#4 has its own sample, played at its own pitch.

**Layer.** The rule for these packs: the mf layer if there is one, otherwise the second loudest of three or more, or the louder of two. Here that is `vl3`. The first take (round robin) of each note is used.

**Recordings.** 32: C#2, D2, D#2, E2, F2, F#2, G2, G#2, A2, A#2, B2, C3, C#3, D3, D#3, E3, F3, F#3, G3, G#3, A3, A#3, B3, C4, C#4, D4, D#4, E4, F4, F#4, G4, G#4. Using the mono recording. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Tuning.** Each recording's pitch was measured (cents: C#2 +39, D2 +7, D#2 +18, E2 +21, F2 +17, F#2 +10, G2 +17, G#2 +12, A2 +17, A#2 +21, B2 +18, C3 +24, C#3 +21, D3 +16, D#3 +21, E3 +8, F3 +18, F#3 +23, G3 +40, G#3 +33, A3 +33, A#3 +29, B3 +27, C4 +42, C#4 +36, D4 +31, D#4 +28, E4 +13, F4 +26, F#4 +3, G4 +17, G#4 +30) and corrected where 5 cents or more off. Finished notes measure -1 to +3 cents.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Made from | Semitones |
|---|---|---|
| C#2 | C#2 | recorded |
| D2 | D2 | recorded |
| D#2 | D#2 | recorded |
| E2 | E2 | recorded |
| F2 | F2 | recorded |
| F#2 | F#2 | recorded |
| G2 | G2 | recorded |
| G#2 | G#2 | recorded |
| A2 | A2 | recorded |
| A#2 | A#2 | recorded |
| B2 | B2 | recorded |
| C3 | C3 | recorded |
| C#3 | C#3 | recorded |
| D3 | D3 | recorded |
| D#3 | D#3 | recorded |
| E3 | E3 | recorded |
| F3 | F3 | recorded |
| F#3 | F#3 | recorded |
| G3 | G3 | recorded |
| G#3 | G#3 | recorded |
| A3 | A3 | recorded |
| A#3 | A#3 | recorded |
| B3 | B3 | recorded |
| C4 | C4 | recorded |
| C#4 | C#4 | recorded |
| D4 | D4 | recorded |
| D#4 | D#4 | recorded |
| E4 | E4 | recorded |
| F4 | F4 | recorded |
| F#4 | F#4 | recorded |
| G4 | G4 | recorded |
| G#4 | G#4 | recorded |

**One-shots.** No loops: each note plays to its natural end, cut 60 dB down with a 30 ms fade.

**Attack.** Kept as recorded: each note starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, nothing trimmed. Notes speak 0-2 ms after they start.

**Volume.** Each note's gain sits on a smooth line of loudness over the first 0.15 s (K-weighted) across the range, and the line is set so the pack plays at the same level as the Plucked Strings pack in the app (headroom for 2 voices included). Nothing clips.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level.
