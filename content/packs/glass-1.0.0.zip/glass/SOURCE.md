# glass

# Glasses of water

Version 2019-12-27

Simple musical instrument made with glasses of water. It was recorded by
Roberto <roberto@zenvoid.org> on October 2019, initially as an example for a
workshop in Medialab-Prado. It turned out more interesting than expected and
it's now transformed into a sound bank.

Recorded with an AKG Perception 120 microphone and glasses of water, carefully
filled to tune into chromatic sounds with approximate note range from A4 to G6.

This sound bank, in several formats and qualities, is available on the
FreePats project web pages: http://freepats.zenvoid.org/

Published under the terms of Creative Commons CC0 public domain dedication:
https://creativecommons.org/publicdomain/zero/1.0/

Round robin _01 only. `A#4-B4_01` is pre-shifted -21 cents, which the SFZ asks for with `tune=-21` and the app has no field for.

Ingested by tools/ingest-sfz.js from Glass-20191227.sfz.
Range 65-96, tails cut at 4s.

Levels: loudest zone 0.6 dBFS as ingested; every zone given the same gain ×0.788 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
