# Big Rusty

A big Polish-made acoustic kit: 24" kick, 14x8 snare, 14/15/18/22 toms, 14" hats,
17" crash, 22" ride, 18" china. Close microphones only, one velocity layer per lane
taken from the 14-layer source at about four-fifths of full force.

Source: https://github.com/sfzinstruments/karoryfer.big-rusty-drums

Ingested by `tools/ingest-drumkit.js`: one file per lane, trailing silence trimmed,
levels untouched, mixed to mono and encoded to AAC. The lane table in `lanes.json`
records which file each lane came from; re-run the tool to swap any of them.

| lane | file | from | seconds | peak dB | rms dB |
|---|---|---|---|---|---|
| Crash | bigrusty/49-crash.m4a | cr_vl4_rr1.flac | 3.680 | -7.8 | -41.7 |
| China | bigrusty/52-china.m4a | cn_vl4_rr1.flac | 6.103 | -8.7 | -35.5 |
| Ride | bigrusty/51-ride.m4a | rd_vl8_rr1.flac | 5.224 | -7.0 | -41.3 |
| Open hat | bigrusty/46-openhat.m4a | ht_open_vl5_rr1.flac | 5.916 | -15.8 | -42.7 |
| Closed hat | bigrusty/42-closedhat.m4a | ht_cl_vl5_rr1.flac | 0.335 | -12.5 | -34.9 |
| Pedal hat | bigrusty/44-pedalhat.m4a | ht_chik_vl4_rr1.flac | 0.321 | -11.1 | -31.6 |
| Snare | bigrusty/38-snare.m4a | sn_center_vl8_rr1.flac | 0.334 | -11.6 | -32.6 |
| Rimshot | bigrusty/40-rimshot.m4a | sn_rims_vl5_rr1.flac | 0.339 | -5.1 | -31.4 |
| Sidestick | bigrusty/37-sidestick.m4a | sn_ss_vl3_rr1.flac | 0.258 | -16.6 | -37.5 |
| Hi tom | bigrusty/50-hitom.m4a | t14_vl5_rr1.flac | 1.182 | -8.6 | -29.1 |
| Mid tom | bigrusty/47-midtom.m4a | t15_vl6_rr1.flac | 1.049 | -7.6 | -26.9 |
| Lo tom | bigrusty/45-lotom.m4a | t18_vl6_rr1.flac | 1.086 | -5.8 | -26.2 |
| Floor tom | bigrusty/41-floortom.m4a | t22_vl6_rr1.flac | 1.683 | -6.1 | -28.7 |
| Kick | bigrusty/36-kick.m4a | k_vl11_rr1.flac | 0.473 | -4.3 | -22.3 |
