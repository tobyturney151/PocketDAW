# ambidrone

Ambi Drone — Sonic Pi sample `ambi_drone`, https://freesound.org/people/Autistic%20Lucario/sounds/195341/.
Pitch, measured by harmonic-series fit over the whole sample and tracked over time: C3 with a strong fifth above, 25 cents sharp. Root C3, retuned -25 cents to C3. One sample played from C2 to C4 by resampling.

Ingested by tools/ingest-sfz.js from ambidrone.sfz.
Range 36-60, tails cut at 5s.

Levels: loudest peak to -1.5 dBFS; gain ×2.514, so it peaks at -1.5 dBFS.
