# vscocellos

Cellos. Source: https://github.com/sgossner/VSCO-2-CE

Layer v3. Roots are the file names plus 12: `A2` measures 220 Hz.

Ingested by tools/ingest-sfz.js from vscocellos.sfz.
Range 36-79, tails cut at 7s.

Levels: loudest zone -4.7 dBFS as ingested; every zone given the same gain ×1.446 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
