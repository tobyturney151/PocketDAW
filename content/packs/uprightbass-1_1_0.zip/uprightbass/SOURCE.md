# uprightbass

Upright-Bass — the "normal" pizzicato samples from pjcohen's Standup Upright Acoustic Double Bass pack on Freesound (pack 21521), CC0.

The files name only natural notes, but each pair holds a note and its sharp: one file of every pair measures 100 cents above the other, so the set is fully chromatic, E1 to F#4, 39 notes. Each file was assigned its true note by measuring it. Every note is within 12 cents and was corrected to exact pitch; the 2 to 14 ms of silence before each pluck was trimmed. Playable down to A0 like the other basses, the lowest notes stretched from E1.

Ingested by tools/ingest-sfz.js from uprightbass.sfz.
Range 21-67, tails cut at 4s.

Levels: matched by loudness to Swag Bass on the same G1, as the other synth-era basses were; one gain, ×0.448, for every note, so the bass's own balance across its range is kept.

## 1.1.0: one sample per semitone

The app no longer speeds samples up or slows them down: every note from A0 to G4 has its own sample, played at its own pitch. The recorded notes (E1, F1, F#1, G1, G#1, A1, A#1, B1, C2, C#2, D2, D#2, E2, F2, F#2, G2, G#2, A2, A#2, B2, C3, C#3, D3, D#3, E3, F3, F#3, G3, G#3, A3, A#3, B3, C4, C#4, D4, D#4, E4, F4, F#4) are unchanged. The other 8 were made from the recording that played them before, pitch-shifted with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch 0.3.1 wrapper), which keeps the recording's timing: attack, vibrato, tremolo, loops and decay arrive as recorded. Each is level-matched to its source recording.

| Note | Made from | Semitones |
|---|---|---|
| A0 | E1 | -7 |
| A#0 | E1 | -6 |
| B0 | E1 | -5 |
| C1 | E1 | -4 |
| C#1 | E1 | -3 |
| D1 | E1 | -2 |
| D#1 | E1 | -1 |
| G4 | F#4 | +1 |
