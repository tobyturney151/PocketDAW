# vibes

Vibraphone. Source: https://github.com/sgossner/VCSL

Roots are the file names plus 12: `A4` measures 880 Hz.

Ingested by tools/ingest-sfz.js from vibes.sfz.
Range 53-89, tails cut at 5s.

Levels: loudest zone -5.9 dBFS as ingested; every zone given the same gain ×1.665 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
