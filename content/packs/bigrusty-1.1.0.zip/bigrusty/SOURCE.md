# Big Rusty

A big Polish-made acoustic kit: 24" kick, 14x8 snare, 14/15/18/22 toms, 14" Sabian HHX
Evolution hats, 17" crash, 22" Sabian Big & Ugly King ride, 18" china. Seventeen lanes.
Cymbals are taken from the overhead microphone, where their wash lives; drums, hats and
clicks from their close microphones. One velocity layer per lane, chosen by ear.

Source: https://github.com/sfzinstruments/karoryfer.big-rusty-drums

Ingested by `tools/ingest-drumkit.js`: one file per lane, trailing silence trimmed,
levels untouched, mixed to mono and encoded to AAC. The lane table in `lanes.json`
records which file each lane came from; re-run the tool to swap any of them.

| lane | file | from | seconds | peak dB | rms dB |
|---|---|---|---|---|---|
| Crash | bigrusty/49-crash.m4a | 49-crash.flac | 11.807 | -11.7 | -46.3 |
| China | bigrusty/52-china.m4a | 52-china.flac | 5.607 | -18.8 | -44.0 |
| Bell | bigrusty/53-bell.m4a | 53-bell.flac | 5.269 | -12.5 | -50.0 |
| Ride | bigrusty/51-ride.m4a | 51-ride.flac | 5.627 | -19.6 | -58.0 |
| Hat Shank | bigrusty/22-hatshank.m4a | 22-hatshank.flac | 0.496 | -16.1 | -38.1 |
| Hat Tip | bigrusty/42-hattip.m4a | 42-hattip.flac | 0.369 | -19.5 | -47.9 |
| Hat Chik | bigrusty/44-hatchik.m4a | 44-hatchik.flac | 0.522 | -11.1 | -33.7 |
| Rim Click | bigrusty/31-rimclick.m4a | 31-rimclick.flac | 0.453 | -19.8 | -47.2 |
| Shell Click | bigrusty/32-shellclick.m4a | 32-shellclick.flac | 0.435 | -24.4 | -52.2 |
| Cross Stick | bigrusty/37-crossstick.m4a | 37-crossstick.flac | 0.638 | -16.6 | -41.4 |
| Rimshot | bigrusty/40-rimshot.m4a | 40-rimshot.flac | 1.000 | -5.1 | -36.1 |
| Snare | bigrusty/38-snare.m4a | 38-snare.flac | 0.854 | -11.6 | -36.7 |
| Hi tom | bigrusty/50-hitom.m4a | 50-hitom.flac | 1.597 | -14.9 | -35.4 |
| Mid tom | bigrusty/47-midtom.m4a | 47-midtom.flac | 1.564 | -12.3 | -32.3 |
| Lo tom | bigrusty/45-lotom.m4a | 45-lotom.flac | 1.586 | -11.3 | -32.7 |
| Floor tom | bigrusty/41-floortom.m4a | 41-floortom.flac | 2.394 | -10.5 | -33.2 |
| Kick | bigrusty/36-kick.m4a | 36-kick.flac | 0.717 | -4.3 | -24.1 |
