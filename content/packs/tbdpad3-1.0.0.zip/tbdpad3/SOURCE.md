# tbdpad3

TBD Minor Pad 3 — Sonic Pi sample `tbd_pad_3`, donated to Sonic Pi by The Black Dog.
D4 with an E♭ a semitone above; the D3 energy is a separate sub-layer with no harmonics of its own. Retuned -6 cents to D4. One sample played an octave either side, D3 to D5, so the sound is never stretched far.

Ingested by tools/ingest-sfz.js from tbdpad3.sfz.
Range 50-74, tails cut at 4s.

Levels: loudest peak to -1.5 dBFS; gain ×1.581.
