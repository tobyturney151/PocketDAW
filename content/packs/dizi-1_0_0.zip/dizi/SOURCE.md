# Dizi Flute

From Hypnotriod's "Flute Dizi C all notes + pitched semitones" on Freesound (pack 21613), CC0:
https://freesound.org/people/Hypnotriod/packs/21613/

Every note from G4 to G6 has its own sample, played at its own pitch.

**Recordings and sharps.** The files are numbered by MIDI note; their note names are written an octave
high. Fifteen are real recordings: G4, A4, B4, C5, D5, E5, F#5, G5, A5, B5, C6, D6, E6, F#6 and G6. The other
ten, the sharps plus F5 and F6, were made by the uploader by speeding up the natural note below by a
semitone, which also shortened them by 5.6%. Those ten were set aside; each of those notes was made instead
from the same recording below with Signalsmith Stretch (MIT licence,
https://github.com/Signalsmith-Audio/signalsmith-stretch), which keeps the recording's timing.

**Tuning.** Each recording's pitch was measured over its sustain (cents: G4 +3, A4 +6, B4 -0, C5 -8, D5 +3, E5 +7, F#5 +7, G5 +5, A5 +5, B5 +5, C6 +11, D6 +7, E6 +29, F#6 +5, G6 +10) and corrected where more than
5 cents off, in the same Signalsmith pass as any shift.

**Loops.** Each recorded note loops at points chosen for matching pitch, tone and level, with a crossfade;
each made note reuses its source recording's loop, lined up at the new pitch. D5's seam is slightly above our
strict check (1.18x).

**Attack and volume.** Attacks were aligned so every note speaks at the same moment after it starts (5 ms
fade-in where trimmed), and each note's gain set onto a smooth line of sustain loudness, lowered so nothing clips.
