# glassrub

Glass Rub — Sonic Pi sample `ambi_glass_rub`, https://freesound.org/people/ani_music/sounds/198403/.
Pitch, measured by harmonic-series fit over the whole sample and tracked over time: F#5, 9 cents flat, clean and steady. Root F#5, retuned +9 cents to F#5. One sample played from F#4 to F#6 by resampling.

Ingested by tools/ingest-sfz.js from glassrub.sfz.
Range 66-90, tails cut at 4s.

Levels: loudest peak to -1.5 dBFS; gain ×0.996, so it peaks at -1.5 dBFS.

1.1.0: every zone now loops while its note is held. The loop starts once the attack settles and ends late in the sustain where the level matches; the end is aligned in phase with the start, the seam crossfaded, and a quarter second of continuation follows it.

## 1.2.0: one sample per semitone

The app no longer speeds samples up or slows them down: every note from F#4 to F#6 has its own sample, played at its own pitch. The recorded note (F#5) is unchanged. The other 24 were made from the recording that played them before, pitch-shifted with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch 0.3.1 wrapper), which keeps the recording's timing: attack, vibrato, tremolo, loops and decay arrive as recorded. Each is level-matched to its source recording. Looping notes reuse their source's loop, with the same start, end and crossfade, lined up with the waveform at the new pitch.

| Note | Made from | Semitones |
|---|---|---|
| F#4 | F#5 | -12 |
| G4 | F#5 | -11 |
| G#4 | F#5 | -10 |
| A4 | F#5 | -9 |
| A#4 | F#5 | -8 |
| B4 | F#5 | -7 |
| C5 | F#5 | -6 |
| C#5 | F#5 | -5 |
| D5 | F#5 | -4 |
| D#5 | F#5 | -3 |
| E5 | F#5 | -2 |
| F5 | F#5 | -1 |
| G5 | F#5 | +1 |
| G#5 | F#5 | +2 |
| A5 | F#5 | +3 |
| A#5 | F#5 | +4 |
| B5 | F#5 | +5 |
| C6 | F#5 | +6 |
| C#6 | F#5 | +7 |
| D6 | F#5 | +8 |
| D#6 | F#5 | +9 |
| E6 | F#5 | +10 |
| F6 | F#5 | +11 |
| F#6 | F#5 | +12 |
