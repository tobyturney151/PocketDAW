# tremstrings

Tremolo — 045-Tremolo Strings from the Discord SFZ GM Bank.

// GM Tremolo Strings
// A custom mix of VCSL and VSCO 2 strings (plus some contrabass string samples) which Samulis pre-panned and rendered in ARIA in m3rds
// License: Creative Commons CC0
// Source: https://vis.versilstudios.com

Ingested by tools/ingest-sfz.js from tremstrings.sfz.
Range 28-96, tails cut at 6s.

Levels: loudest zone -4.0 dBFS as ingested; every zone given the same gain ×1.338 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.

1.1.0: every zone now loops while its note is held. The loop starts once the attack settles and ends late in the sustain where the level matches; the end is aligned in phase with the start, the seam crossfaded, and a quarter second of continuation follows it.

## 1.2.0: one sample per semitone

The app no longer speeds samples up or slows them down: every note from E1 to D6 has its own sample, played at its own pitch. The recorded notes (E1, G#1, C2, E2, G#2, C3, E3, G#3, C4, E4, G#4, C5, E5, G#5, C6) are unchanged. The other 44 were made from the recording that played them before, pitch-shifted with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch 0.3.1 wrapper), which keeps the recording's timing: attack, vibrato, tremolo, loops and decay arrive as recorded. Each is level-matched to its source recording. Looping notes reuse their source's loop, with the same start, end and crossfade, lined up with the waveform at the new pitch. Seams slightly above our strict check: G2.

| Note | Made from | Semitones |
|---|---|---|
| F1 | E1 | +1 |
| F#1 | G#1 | -2 |
| G1 | G#1 | -1 |
| A1 | G#1 | +1 |
| A#1 | C2 | -2 |
| B1 | C2 | -1 |
| C#2 | C2 | +1 |
| D2 | E2 | -2 |
| D#2 | E2 | -1 |
| F2 | E2 | +1 |
| F#2 | G#2 | -2 |
| G2 | G#2 | -1 |
| A2 | G#2 | +1 |
| A#2 | C3 | -2 |
| B2 | C3 | -1 |
| C#3 | C3 | +1 |
| D3 | E3 | -2 |
| D#3 | E3 | -1 |
| F3 | E3 | +1 |
| F#3 | G#3 | -2 |
| G3 | G#3 | -1 |
| A3 | G#3 | +1 |
| A#3 | C4 | -2 |
| B3 | C4 | -1 |
| C#4 | C4 | +1 |
| D4 | E4 | -2 |
| D#4 | E4 | -1 |
| F4 | E4 | +1 |
| F#4 | G#4 | -2 |
| G4 | G#4 | -1 |
| A4 | G#4 | +1 |
| A#4 | C5 | -2 |
| B4 | C5 | -1 |
| C#5 | C5 | +1 |
| D5 | E5 | -2 |
| D#5 | E5 | -1 |
| F5 | E5 | +1 |
| F#5 | G#5 | -2 |
| G5 | G#5 | -1 |
| A5 | G#5 | +1 |
| A#5 | C6 | -2 |
| B5 | C6 | -1 |
| C#6 | C6 | +1 |
| D6 | C6 | +2 |

### Attack and volume

The recordings start to speak at different speeds. Each note's quiet bow-start was trimmed, with a 10 ms fade-in, so every note reaches its speaking point (the mean of when it first comes within 24, 18 and 12 dB of its sustain) at the same moment after the note begins; the quickest tenth were left as recorded. Trims ranged from 0 to 58 ms; loops moved with them. Each note's gain was then set so its sustain loudness sits on a smooth line across the range, lowered just enough that no note would clip.
