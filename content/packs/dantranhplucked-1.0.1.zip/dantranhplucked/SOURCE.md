# dantranhplucked

Dan Tranh Plucked. Source: https://github.com/sgossner/VCSL

Normal plucks at f. Roots are the file names plus 12.

Ingested by tools/ingest-sfz.js from dantranhplucked.sfz.
Range 45-85, tails cut at 4s.

Levels: loudest zone -16.7 dBFS as ingested; every zone given the same gain ×5.722 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.

1.0.1: the C#4 sample (file C#3) measured 52 cents sharp and is removed. The B3 sample, 10 cents sharp, now also plays C#4, and the D#4 sample, 8 cents sharp, also plays D4.
