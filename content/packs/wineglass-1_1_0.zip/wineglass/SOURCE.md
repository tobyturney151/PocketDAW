# wineglass

Glass Rims. Source: https://github.com/sgossner/VCSL

Roots are the file names plus 12. Each glass is pre-shifted to its named pitch: measured +30, -10, +57 and +6 cents off.

Ingested by tools/ingest-sfz.js from wineglass.sfz.
Range 70-90, tails cut at 8s.

Levels: loudest zone -34.7 dBFS as ingested; every zone given the same gain ×45.757 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.

1.1.0: every zone now loops while its note is held. The loop starts once the attack settles and ends late in the sustain where the level matches; the end is aligned in phase with the start, the seam crossfaded, and a quarter second of continuation follows it.
