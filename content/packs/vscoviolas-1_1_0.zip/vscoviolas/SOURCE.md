# vscoviolas

Violas. Source: https://github.com/sgossner/VSCO-2-CE

Layer v2. Roots are the file names plus 12: `A3` measures 440.6 Hz.

Ingested by tools/ingest-sfz.js from vscoviolas.sfz.
Range 48-86, tails cut at 7s.

Levels: loudest zone -6.5 dBFS as ingested; every zone given the same gain ×1.776 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.

1.1.0: every zone now loops while its note is held. The loop starts once the attack settles and ends late in the sustain where the level matches; the end is aligned in phase with the start, the seam crossfaded, and a quarter second of continuation follows it. Where the sustain fades, the level is held steady across the loop.
