# spanish

# Spanish classical guitar

Version 2019-06-18

Sound samples recorded from a Spanish classical guitar on 2008. Created by
roberto@zenvoid.org for the FreePats project.

Recorded with an AKG Perception 120 microphone and processed using free
software tools. The recording conditions were far from ideal, so several
filters have been applied to reduce noise and improve sound.

This sound bank, in several formats and qualities, is available on the
FreePats project web pages:
http://freepats.zenvoid.org/Guitar/acoustic-guitar.html

Published under the terms of Creative Commons CC0 public domain dedication:
https://creativecommons.org/publicdomain/zero/1.0/

Ingested by tools/ingest-sfz.js from SpanishClassicalGuitar-20190618.sfz.
Range 38-88, tails cut at 4s.

Levels: loudest zone 0.8 dBFS as ingested; every zone given the same gain ×0.767 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
