# Virt Percussion

Versilian Studios and Karoryfer Samples, Virtuosity Drums — the percussion set, every instrument except the bell tree. Close mic, except the timbales, cuica and woodblocks, which were only recorded on the overhead. MIDI numbers are the General MIDI percussion slots, so the 808's cowbell, clave and maracas land on Cowbell, Claves and Shaker Up.

Source: https://github.com/sfzinstruments/virtuosity_drums

Ingested by `tools/ingest-drumkit.js`: one file per lane, trailing silence trimmed,
levels untouched, mixed to mono and encoded to AAC. The lane table in `lanes.json`
records which file each lane came from; re-run the tool to swap any of them.

| lane | file | from | seconds | peak dB | rms dB |
|---|---|---|---|---|---|
| Long Whistle | virtperc/72-longwhistle.m4a | 72-28-whistle-long.flac | 2.048 | -25.6 | -38.5 |
| Whistle | virtperc/71-whistle.m4a | 71-27-whistle-short.flac | 1.094 | -24.0 | -41.5 |
| Vibraslap | virtperc/58-vibraslap.m4a | 58-26-vibraslap.flac | 0.969 | -25.7 | -47.6 |
| Jingle Bell | virtperc/83-jinglebell.m4a | 83-15-jingle-bell.flac | 1.245 | -27.7 | -50.7 |
| Tambourine | virtperc/54-tambourine.m4a | 54-25-tambourine.flac | 0.351 | -29.7 | -48.0 |
| Shaker Up | virtperc/70-shakerup.m4a | 70-24-shaker-up.flac | 0.415 | -31.8 | -48.7 |
| Shaker Down | virtperc/82-shakerdown.m4a | 82-23-shaker-down.flac | 0.500 | -22.3 | -42.4 |
| Cabasa | virtperc/69-cabasa.m4a | 69-22-cabasa.flac | 0.212 | -19.3 | -35.9 |
| Guiro Long | virtperc/74-guirolong.m4a | 74-21-guiro-slow.flac | 0.582 | -38.9 | -62.9 |
| Guiro Short | virtperc/73-guiroshort.m4a | 73-20-guiro-fast.flac | 0.244 | -32.2 | -55.8 |
| Claves | virtperc/75-claves.m4a | 75-17-claves.flac | 0.152 | -24.8 | -47.8 |
| Block Hi | virtperc/76-blockhi.m4a | 76-18-woodblock-high-OH.flac | 0.837 | -19.0 | -45.2 |
| Block Lo | virtperc/77-blocklo.m4a | 77-19-woodblock-low-OH.flac | 0.757 | -16.1 | -40.2 |
| Triangle | virtperc/81-triangle.m4a | 81-13-triangle-open.flac | 2.459 | -19.7 | -45.1 |
| Tri Muted | virtperc/80-trimuted.m4a | 80-14-triangle-muted.flac | 0.414 | -31.0 | -48.0 |
| Cowbell | virtperc/56-cowbell.m4a | 56-12-cowbell.flac | 0.335 | -19.4 | -38.5 |
| Agogo Hi | virtperc/67-agogohi.m4a | 67-10-agogo-high.flac | 0.323 | -33.4 | -56.0 |
| Agogo Lo | virtperc/68-agogolo.m4a | 68-11-agogo-low.flac | 1.011 | -26.4 | -50.8 |
| Cuica Open | virtperc/79-cuicaopen.m4a | 79-08-cuica-open-OH.flac | 1.029 | -4.8 | -14.9 |
| Cuica Muted | virtperc/78-cuicamuted.m4a | 78-09-cuica-muted-OH.flac | 0.363 | -19.8 | -30.5 |
| Timbale Hi | virtperc/65-timbalehi.m4a | 65-06-timbale-13-OH.flac | 0.842 | -11.9 | -30.0 |
| Timbale Lo | virtperc/66-timbalelo.m4a | 66-07-timbale-14-OH.flac | 0.962 | -14.1 | -30.6 |
| Bongo Hi | virtperc/60-bongohi.m4a | 60-04-bongo-high.flac | 0.375 | -26.1 | -46.5 |
| Bongo Lo | virtperc/61-bongolo.m4a | 61-05-bongo-low.flac | 0.369 | -28.6 | -47.7 |
| Conga Muted | virtperc/62-congamuted.m4a | 62-02-conga-muted.flac | 0.605 | -22.1 | -42.7 |
| Conga Open | virtperc/63-congaopen.m4a | 63-01-conga-open.flac | 0.732 | -13.5 | -29.7 |
| Tumba | virtperc/64-tumba.m4a | 64-03-tumba.flac | 0.705 | -15.8 | -32.0 |
