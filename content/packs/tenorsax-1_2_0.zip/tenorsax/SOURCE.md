# Tenor Sax

From Versilian Studios' VCSL (Versilian Community Sample Library) (CC0): tenor saxophone (Brett). Each note starts as its staccato recording and is joined into its sustain recording, which loops for as long as the note is held: short notes keep the tongued start, held notes carry on.
https://github.com/sgossner/VCSL (staccato `Aerophones/Reed Aerophones/Tenor Saxophone/Staccato`, sustain `Aerophones/Reed Aerophones/Tenor Saxophone/Non-Vibrato`)

Every note from G#2 to E6 has its own sample, played at its own pitch.

**Layers.** Staccato, layer vl1 (soft, of vl1 and vl2). Non-vibrato sustain, layer vl2 (soft, of vl2 and vl3). Both chosen by listening; the first take (round robin) of each note is used.

**Recordings.** Staccato, 23: G#2, A#2, C3, D3, E3, F#3, G#3, A3, C4, D4, E4, F#4, G#4, A#4, C5, D5, E5, F5, G#5, A5, C6, D6, E6. Sustain, 23: G#2, A#2, C3, D3, E3, F#3, G#3, A#3, C4, D4, E4, F#4, G#4, A#4, C5, D5, E5, F#5, G#5, A#5, C6, D6, E6. Using the right microphone only: the two microphones are poorly correlated in these recordings, so mixing them would thin notes unevenly. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Tuning.** Each recording's pitch was measured (cents, staccato: G#2 -3, A#2 -1, C3 +2, D3 -4, E3 -3, F#3 +2, G#3 -2, A3 +3, C4 -6, D4 +2, E4 -6, F#4 -4, G#4 -3, A#4 +4, C5 0, D5 +8, E5 -2, F5 +1, G#5 +3, A5 +1, C6 0, D6 +1, E6 +3; sustain: all within 0.3 cent) and corrected where 5 cents or more off.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Staccato from | Sustain from | Joint (ms) | Joins sustain at (s) | Loop (s) |
|---|---|---|---|---|---|
| G#2 | G#2 | G#2 | 79-108 | 0.14 | 1.70-6.64 |
| A2 | G#2 (+1) | G#2 (+1) | 65-92 | 0.10 | 1.72-6.65 |
| A#2 | A#2 | A#2 | 90-116 | 0.33 | 0.50-6.56 |
| B2 | A#2 (+1) | A#2 (+1) | 95-119 | 0.21 | 0.58-6.62 |
| C3 | C3 | C3 | 70-93 | 0.13 | 2.08-6.74 |
| C#3 | C3 (+1) | C3 (+1) | 70-92 | 0.13 | 2.08-6.74 |
| D3 | D3 | D3 | 84-106 | 0.10 | 2.29-7.23 |
| D#3 | D3 (+1) | D3 (+1) | 70-92 | 0.08 | 2.29-7.24 |
| E3 | E3 | E3 | 104-126 | 0.54 | 0.50-6.70 |
| F3 | E3 (+1) | E3 (+1) | 94-116 | 0.51 | 0.50-6.72 |
| F#3 | F#3 | F#3 | 74-96 | 0.30 | 0.63-6.91 |
| G3 | F#3 (+1) | F#3 (+1) | 79-101 | 0.36 | 0.58-6.85 |
| G#3 | G#3 | G#3 | 94-116 | 0.23 | 2.48-5.76 |
| A3 | A3 | G#3 (+1) | 95-117 | 0.24 | 2.48-5.74 |
| A#3 | A3 (+1) | A#3 | 95-117 | 0.54 | 1.19-5.42 |
| B3 | C4 (-1) | A#3 (+1) | 55-77 | 0.60 | 1.09-5.31 |
| C4 | C4 | C4 | 55-77 | 0.29 | 2.62-5.51 |
| C#4 | C4 (+1) | C4 (+1) | 55-77 | 0.29 | 2.62-5.52 |
| D4 | D4 | D4 | 65-87 | 0.11 | 1.69-6.52 |
| D#4 | D4 (+1) | D4 (+1) | 65-87 | 0.10 | 1.71-6.53 |
| E4 | E4 | E4 | 90-112 | 0.11 | 0.54-5.62 |
| F4 | E4 (+1) | E4 (+1) | 90-112 | 0.20 | 0.66-5.77 |
| F#4 | F#4 | F#4 | 45-67 | 0.29 | 1.04-6.21 |
| G4 | F#4 (+1) | F#4 (+1) | 55-77 | 0.28 | 1.05-6.20 |
| G#4 | G#4 | G#4 | 55-77 | 0.22 | 2.17-5.19 |
| A4 | G#4 (+1) | G#4 (+1) | 55-77 | 0.21 | 2.18-5.20 |
| A#4 | A#4 | A#4 | 55-77 | 0.20 | 2.16-7.45 |
| B4 | A#4 (+1) | A#4 (+1) | 50-72 | 0.29 | 2.06-7.36 |
| C5 | C5 | C5 | 80-102 | 0.48 | 0.56-4.94 |
| C#5 | C5 (+1) | C5 (+1) | 85-107 | 0.48 | 0.56-4.93 |
| D5 | D5 | D5 | 55-77 | 0.87 | 1.63-5.51 |
| D#5 | D5 (+1) | D5 (+1) | 55-77 | 0.87 | 1.63-5.51 |
| E5 | E5 | E5 | 70-92 | 0.46 | 1.27-5.49 |
| F5 | F5 | E5 (+1) | 54-76 | 0.66 | 1.06-5.28 |
| F#5 | F5 (+1) | F#5 | 54-76 | 0.59 | 0.50-3.59 |
| G5 | G#5 (-1) | F#5 (+1) | 59-81 | 0.10 | 0.64-4.00 |
| G#5 | G#5 | G#5 | 55-77 | 0.22 | 0.54-3.18 |
| A5 | A5 | G#5 (+1) | 115-137 | 0.28 | 0.52-3.15 |
| A#5 | A5 (+1) | A#5 | 120-142 | 0.26 | 0.52-4.18 |
| B5 | C6 (-1) | A#5 (+1) | 135-157 | 0.53 | 1.56-3.89 |
| C6 | C6 | C6 | 140-162 | 0.24 | 1.54-5.40 |
| C#6 | C6 (+1) | C6 (+1) | 135-157 | 0.24 | 1.53-5.41 |
| D6 | D6 | D6 | 85-107 | 0.18 | 0.58-6.19 |
| D#6 | D6 (+1) | D6 (+1) | 80-102 | 0.18 | 0.62-6.23 |
| E6 | E6 | E6 | 50-72 | 0.15 | 1.19-4.09 |

**The joint.** For each note:

1. The staccato is left just after its peak, so its tongued start and accent stay whole, and before it has faded 2 dB (here 45-162 ms into the note).
2. The sustain is joined where it has settled (not still swelling in or wavering), at the point that best matches the staccato's tone and pitch.
3. Where the staccato at the joint is 5 cents or more off the sustain, the staccato is retuned to it by varispeed, which keeps the attack crisp (17 of 45 notes, up to 19 cents). Joined notes match within 5 cents.
4. The sustain is moved by up to one cycle of the note to where the two waveforms line up best, and set to the staccato's level there.
5. They are crossfaded over three cycles of the note (22-40 ms) with gains that hold the level steady however well the waveforms line up. Measured across the joint, every note's level stays within -1.0 to +1.7 dB.
6. Tone glide: the sustain comes in with the staccato's tone, harmonic by harmonic, and relaxes to its own over 150 ms, so the brightness of the attack settles as in one played note. The glide changes tone only: each moment keeps its own loudness.
7. Loops: the sustain recording's own loop (pitch, tone and level matched, end aligned in phase, seam crossfaded) is kept where it still starts 0.5 s or later; otherwise a new loop is found the same way in the joined note (12 of 45 notes). Every loop starts at least 0.5 s in and lasts at least 1 s, with a quarter second of continuation after the loop end.

**Attack.** Kept as recorded: each staccato starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, nothing trimmed.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s, K-weighted) across the range, set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

**Release.** 0.12 s, so short notes stop near the staccato's own length.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level. Built from the original recordings.

## 1.2.0

Now a hybrid: each note starts as the staccato recording (layer vl1, soft) and is joined into the sustain, which loops; release 0.12 s (was 0.25 s), attack ramp 2 ms (was 5 ms). 1.1.0 played the sustain recording alone. It also takes over from the Tenor Sax Staccato pack, which is retired.

## 1.1.0

Rebuilt from the soft layer (vl2 of vl2 and vl3); 1.0.0 used vl3, the louder of two.
