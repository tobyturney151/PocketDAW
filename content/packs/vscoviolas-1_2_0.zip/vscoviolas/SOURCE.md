# vscoviolas

Violas. Source: https://github.com/sgossner/VSCO-2-CE

Layer v2. Roots are the file names plus 12: `A3` measures 440.6 Hz.

Ingested by tools/ingest-sfz.js from vscoviolas.sfz.
Range 48-86, tails cut at 7s.

Levels: loudest zone -6.5 dBFS as ingested; every zone given the same gain ×1.776 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.

1.1.0: every zone now loops while its note is held. The loop starts once the attack settles and ends late in the sustain where the level matches; the end is aligned in phase with the start, the seam crossfaded, and a quarter second of continuation follows it. Where the sustain fades, the level is held steady across the loop.

## 1.2.0: one sample per semitone

The app no longer speeds samples up or slows them down: every note from C3 to D6 has its own sample, played at its own pitch. The recorded notes (C3, D3, E3, G3, B3, D4, F4, A4, C5, E5, G5, B5, D6) are unchanged. The other 26 were made from the recording that played them before, pitch-shifted with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch 0.3.1 wrapper), which keeps the recording's timing: attack, vibrato, tremolo, loops and decay arrive as recorded. Each is level-matched to its source recording. Looping notes reuse their source's loop, with the same start, end and crossfade, lined up with the waveform at the new pitch.

| Note | Made from | Semitones |
|---|---|---|
| C#3 | C3 | +1 |
| D#3 | D3 | +1 |
| F3 | E3 | +1 |
| F#3 | G3 | -1 |
| G#3 | G3 | +1 |
| A3 | G3 | +2 |
| A#3 | B3 | -1 |
| C4 | B3 | +1 |
| C#4 | D4 | -1 |
| D#4 | D4 | +1 |
| E4 | F4 | -1 |
| F#4 | F4 | +1 |
| G4 | F4 | +2 |
| G#4 | A4 | -1 |
| A#4 | A4 | +1 |
| B4 | C5 | -1 |
| C#5 | C5 | +1 |
| D5 | C5 | +2 |
| D#5 | E5 | -1 |
| F5 | E5 | +1 |
| F#5 | G5 | -1 |
| G#5 | G5 | +1 |
| A5 | G5 | +2 |
| A#5 | B5 | -1 |
| C6 | B5 | +1 |
| C#6 | D6 | -1 |

### Attack and volume

The recordings start to speak at different speeds. Each note's quiet bow-start was trimmed, with a 10 ms fade-in, so every note reaches its speaking point (the mean of when it first comes within 24, 18 and 12 dB of its sustain) at the same moment after the note begins; the quickest tenth were left as recorded. Trims ranged from 0 to 140 ms; loops moved with them. Each note's gain was then set so its sustain loudness sits on a smooth line across the range, lowered just enough that no note would clip.
