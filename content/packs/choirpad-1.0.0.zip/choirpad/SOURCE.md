# choirpad

Synth Pad Choir
---------------

Version 2020-05-16

General MIDI instrument #92: Synth Pad 4 (choir).

Samples by 快乐爱的小精灵 (Elf of Happy and Love) <lovebodhi@yandex.com>, sent to the FreePats project on April 2020. Made with ZynAddSubFX software synthesizer. This version is edited by roberto@zenvoid.org.

Please visit FreePats web pages for updates and more content:
http://freepats.zenvoid.org/


Published under the terms of Creative Commons CC0 public domain dedication:
https://creativecommons.org/publicdomain/zero/1.0/

Ingested by tools/ingest-sfz.js from SynthPadChoir 20200516.sfz.
Range 24-100.

Levels: loudest zone -0.5 dBFS as ingested; every zone given the same gain ×0.893 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.
