# Bari Sax

From Karoryfer Samples' Bear Sax, a 1926 Conn baritone (CC0): baritone saxophone. Each note starts as its staccato recording and is joined into its sustain recording, which loops for as long as the note is held: short notes keep the tongued start, held notes carry on.
https://github.com/sfzinstruments/karoryfer.bear-sax (staccato `Samples`, sustain `Samples`)

Every note from C#2 to G#4 has its own sample, played at its own pitch.

**Layers.** Staccato, layer vl2 (of vl1-vl4). Looped sustain, p (the soft one of p and f). Both chosen by listening. The first take (round robin) of each note is used.

**Recordings.** Staccato, 31: C#2, D2, D#2, E2, F2, F#2, G2, G#2, A2, A#2, B2, C3, C#3, D3, D#3, E3, F3, F#3, G3, G#3, A3, A#3, C4, C#4, D4, D#4, E4, F4, F#4, G4, G#4. Sustain, 32: C#2, D2, D#2, E2, F2, F#2, G2, G#2, A2, A#2, B2, C3, C#3, D3, D#3, E3, F3, F#3, G3, G#3, A3, A#3, B3, C4, C#4, D4, D#4, E4, F4, F#4, G4, G#4. Using the mono recording. The file names are written an octave below how the notes sound, so each was filed an octave up (checked by measuring every note).

**Refiled or left out.**

- Staccato: dropped b2_vl2_rr1.wav: measures +81 c from B3

**Tuning.** Each recording's pitch was measured (cents, staccato: C#2 +48, D2 +15, D#2 +30, E2 +28, F2 +18, F#2 +9, G2 +22, G#2 +16, A2 +24, A#2 +23, B2 +15, C3 +20, C#3 +18, D3 +15, D#3 +17, E3 +4, F3 +27, F#3 +23, G3 +27, G#3 +30, A3 +30, A#3 +42, C4 +46, C#4 +42, D4 +29, D#4 +27, E4 +21, F4 +11, F#4 +5, G4 +13, G#4 +24; sustain: C#2 0, D2 0, D#2 0, E2 0, F2 0, F#2 0, G2 0, G#2 0, A2 0, A#2 0, B2 0, C3 0, C#3 0, D3 0, D#3 0, E3 0, F3 0, F#3 0, G3 -1, G#3 0, A3 +1, A#3 0, B3 0, C4 0, C#4 0, D4 0, D#4 0, E4 0, F4 0, F#4 0, G4 0, G#4 -1) and corrected where 5 cents or more off.

**Notes between recordings** were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording. Tuning corrections were made in the same pass.

| Note | Staccato from | Sustain from | Joint (ms) | Joins sustain at (s) | Loop (s) |
|---|---|---|---|---|---|
| C#2 | C#2 | C#2 | 20-60 | 0.51 | 0.52-3.62 |
| D2 | D2 | D2 | 35-75 | 0.04 | 0.70-3.80 |
| D#2 | D#2 | D#2 | 45-83 | 0.21 | 0.71-4.25 |
| E2 | E2 | E2 | 30-66 | 0.37 | 1.46-4.29 |
| F2 | F2 | F2 | 40-74 | 0.50 | 0.64-4.77 |
| F#2 | F#2 | F#2 | 45-77 | 0.14 | 1.89-5.10 |
| G2 | G2 | G2 | 25-55 | 0.48 | 1.32-5.56 |
| G#2 | G#2 | G#2 | 25-54 | 0.15 | 0.64-4.39 |
| A2 | A2 | A2 | 35-62 | 0.11 | 1.02-4.96 |
| A#2 | A#2 | A#2 | 45-71 | 0.04 | 0.94-3.99 |
| B2 | B2 | B2 | 30-54 | 0.35 | 0.58-4.25 |
| C3 | C3 | C3 | 35-58 | 0.13 | 0.61-7.24 |
| C#3 | C#3 | C#3 | 40-62 | 0.50 | 1.00-6.62 |
| D3 | D3 | D3 | 45-67 | 0.55 | 0.54-4.15 |
| D#3 | D#3 | D#3 | 65-87 | 0.36 | 0.70-7.62 |
| E3 | E3 | E3 | 30-52 | 0.04 | 0.91-5.15 |
| F3 | F3 | F3 | 35-57 | 0.09 | 0.66-5.29 |
| F#3 | F#3 | F#3 | 20-42 | 0.11 | 0.67-6.25 |
| G3 | G3 | G3 | 19-41 | 0.34 | 0.50-5.40 |
| G#3 | G#3 | G#3 | 31-53 | 0.36 | 0.75-7.27 |
| A3 | A3 | A3 | 55-77 | 0.13 | 0.76-7.30 |
| A#3 | A#3 | A#3 | 35-57 | 0.30 | 0.87-7.25 |
| B3 | A#3 (+1) | B3 | 35-57 | 0.10 | 1.48-4.52 |
| C4 | C4 | C4 | 25-47 | 0.37 | 0.50-7.83 |
| C#4 | C#4 | C#4 | 15-37 | 0.60 | 1.82-4.81 |
| D4 | D4 | D4 | 25-47 | 0.11 | 1.10-5.90 |
| D#4 | D#4 | D#4 | 20-42 | 0.03 | 2.99-6.78 |
| E4 | E4 | E4 | 25-47 | 0.17 | 1.10-7.11 |
| F4 | F4 | F4 | 20-42 | 0.04 | 1.80-6.86 |
| F#4 | F#4 | F#4 | 30-52 | 0.04 | 2.79-6.94 |
| G4 | G4 | G4 | 30-52 | 0.20 | 2.79-7.76 |
| G#4 | G#4 | G#4 | 30-52 | 0.18 | 2.63-6.42 |

**The joint.** For each note:

1. The staccato is left just after its peak, so its tongued start and accent stay whole, and before it has faded 2 dB (here 15-87 ms into the note).
2. The sustain is joined where it has settled (not still swelling in or wavering), at the point that best matches the staccato's tone and pitch.
3. Where the staccato at the joint is 5 cents or more off the sustain, the staccato is retuned to it by varispeed, which keeps the attack crisp (20 of 32 notes, up to 72 cents). Joined notes match within 4 cents.
4. The sustain is moved by up to one cycle of the note to where the two waveforms line up best, and set to the staccato's level there.
5. They are crossfaded over three cycles of the note (22-40 ms) with gains that hold the level steady however well the waveforms line up. Measured across the joint, every note's level stays within -3.6 to +3.0 dB.
6. Tone glide: the sustain comes in with the staccato's tone, harmonic by harmonic, and relaxes to its own over 150 ms, so the brightness of the attack settles as in one played note. The glide changes tone only: each moment keeps its own loudness.
7. Loops: the sustain recording's own loop (pitch, tone and level matched, end aligned in phase, seam crossfaded) is kept where it still starts 0.5 s or later; otherwise a new loop is found the same way (7 of 32 notes). Every loop starts at least 0.5 s in and lasts at least 1 s, with a quarter second of continuation after the loop end.

**Attack.** Kept as recorded: each staccato starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in, nothing trimmed.

**Hits evened.** Each note's first 0.15 s is set to sit the same amount above its held part (the median across the pack), so short notes come out even: just after the joint the sustain eases over 0.2 s from the joint level to its evened level (here -4.8 to +6.0 dB, at most 6 dB either way), before any loop.

**Volume.** Each note's gain sits on a smooth line of sustain loudness (0.3 to 2.3 s, K-weighted) across the range, set so the pack plays at the same level as the Violins pack in the app (headroom for 2 voices included). Nothing clips.

**Release.** 0.12 s, so short notes stop near the staccato's own length.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level. Built from the original recordings.

## 1.1.0

Now a hybrid: each note starts as the staccato recording (layer vl2) and is joined into the looped sustain, now the p recordings (1.0.0 used f); release 0.12 s (was 0.25 s), attack ramp 2 ms (was 5 ms); each note's opening hit evened against its held part. It also takes over from the Bari Sax Staccato pack, which is retired.

## 1.0.0

First version: looped sustain, f.
