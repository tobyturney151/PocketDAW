# thickbass

Thick Bass — Sonic Pi sample `bass_thick_c`, https://freesound.org/people/ani_music/sounds/165314/.
Pitch, measured by harmonic-series fit over the whole sample and tracked over time: two detuned oscillators on C2, averaging 10 cents flat. Root C2, retuned +10 cents to C2. One sample played from A0 to G4 by resampling.

Ingested by tools/ingest-sfz.js from thickbass.sfz.
Range 21-67, tails cut at 4s.

Levels: loudness-matched to Swag Bass G1; gain ×0.218, so it peaks at -13.6 dBFS.

## 1.1.0: one sample per semitone

The app no longer speeds samples up or slows them down: every note from A0 to G4 has its own sample, played at its own pitch. The recorded note (C2) is unchanged. The other 46 were made from the recording that played them before, pitch-shifted with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch 0.3.1 wrapper), which keeps the recording's timing: attack, vibrato, tremolo, loops and decay arrive as recorded. Each is level-matched to its source recording.

| Note | Made from | Semitones |
|---|---|---|
| A0 | C2 | -15 |
| A#0 | C2 | -14 |
| B0 | C2 | -13 |
| C1 | C2 | -12 |
| C#1 | C2 | -11 |
| D1 | C2 | -10 |
| D#1 | C2 | -9 |
| E1 | C2 | -8 |
| F1 | C2 | -7 |
| F#1 | C2 | -6 |
| G1 | C2 | -5 |
| G#1 | C2 | -4 |
| A1 | C2 | -3 |
| A#1 | C2 | -2 |
| B1 | C2 | -1 |
| C#2 | C2 | +1 |
| D2 | C2 | +2 |
| D#2 | C2 | +3 |
| E2 | C2 | +4 |
| F2 | C2 | +5 |
| F#2 | C2 | +6 |
| G2 | C2 | +7 |
| G#2 | C2 | +8 |
| A2 | C2 | +9 |
| A#2 | C2 | +10 |
| B2 | C2 | +11 |
| C3 | C2 | +12 |
| C#3 | C2 | +13 |
| D3 | C2 | +14 |
| D#3 | C2 | +15 |
| E3 | C2 | +16 |
| F3 | C2 | +17 |
| F#3 | C2 | +18 |
| G3 | C2 | +19 |
| G#3 | C2 | +20 |
| A3 | C2 | +21 |
| A#3 | C2 | +22 |
| B3 | C2 | +23 |
| C4 | C2 | +24 |
| C#4 | C2 | +25 |
| D4 | C2 | +26 |
| D#4 | C2 | +27 |
| E4 | C2 | +28 |
| F4 | C2 | +29 |
| F#4 | C2 | +30 |
| G4 | C2 | +31 |
