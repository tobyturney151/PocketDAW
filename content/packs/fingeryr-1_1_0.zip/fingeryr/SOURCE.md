# fingeryr

Finger Bass YR
--------------

Version 2019-09-30

Sound samples created by Andrea Biasior <reusenoise@gmail.com> from a Yamaha RBX bass guitar. It was sent for inclusion in FreePats on September 2019. A few small edits to the samples and sound banks were made by <roberto@zenvoid.org> for integration with other sound banks in the FreePats project.

Please visit FreePats web pages for updates and more content:
http://freepats.zenvoid.org/


Published under the terms of Creative Commons CC0 public domain dedication:
https://creativecommons.org/publicdomain/zero/1.0/

Ingested by tools/ingest-sfz.js from FingerBassYR 20190930.sfz.
Range 28-67, tails cut at 3s.

Levels: loudest zone 3.3 dBFS as ingested; every zone given the same gain ×0.573 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.

## 1.1.0: one sample per semitone

The app no longer speeds samples up or slows them down: every note from A0 to A2 has its own sample, played at its own pitch. The recorded notes (E1, F1, F#1, G1, G#1, A1, A#1, B1, C2, C#2, D2, D#2) are unchanged. The other 13 were made from the recording that played them before, pitch-shifted with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via the python-stretch 0.3.1 wrapper), which keeps the recording's timing: attack, vibrato, tremolo, loops and decay arrive as recorded. Each is level-matched to its source recording.

| Note | Made from | Semitones |
|---|---|---|
| A0 | E1 | -7 |
| A#0 | E1 | -6 |
| B0 | E1 | -5 |
| C1 | E1 | -4 |
| C#1 | E1 | -3 |
| D1 | E1 | -2 |
| D#1 | E1 | -1 |
| E2 | D#2 | +1 |
| F2 | D#2 | +2 |
| F#2 | D#2 | +3 |
| G2 | D#2 | +4 |
| G#2 | D#2 | +5 |
| A2 | D#2 | +6 |
