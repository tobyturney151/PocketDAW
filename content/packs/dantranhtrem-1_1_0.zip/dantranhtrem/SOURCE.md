# dantranhtrem

Dan Tranh Trem. Source: https://github.com/sgossner/VCSL

Tremolo. Roots are the file names plus 12.

Ingested by tools/ingest-sfz.js from dantranhtrem.sfz.
Range 45-85, tails cut at 4s.

Levels: loudest zone -8.9 dBFS as ingested; every zone given the same gain ×2.355 to bring it to -1.5 dBFS, so the instrument's balance across its range is unchanged.

1.0.1: three samples removed and their notes borrowed from neighbours. F#3 (file F#2) measured 30 cents flat and G#5 (file G#4) 33 cents sharp. C#3 (file C#2) was reported off by ear and one measurement, though it read 9 cents flat here; removed at the listener's request. Each missing note is played by whichever neighbour is closer: B2 takes C#3, D#3 takes D3 and F3, G#3 takes F#3 and G3, F#5 takes G#5, B5 takes A5 — all neighbours within 10 cents.

## 1.1.0: tuned, one sample per semitone, even attacks and volume

Pitch: each recording's pitch was measured over the body of the note and corrected. Measured offsets of the recordings, in cents: B2 -2, D#3 +2, G#3 +8, B3 -6, C#4 -26, D#4 +15, F#4 +11, G#4 -12, B4 -8, C#5 +7, D#5 +13, F#5 -3, B5 -4. Every note from A2 to C#6 now has its own sample, made from the recording that played it before with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch), shifted by the semitones to the note plus that recording's correction in one pass, which keeps the recording's timing. Recordings already within 5 cents on their own note are untouched. Attacks were aligned so each note speaks at the same moment after it starts (quiet starts trimmed, 2 ms fade-in so no pluck is softened), and each note's gain set onto a smooth line of loudness over its first half second, lowered so nothing clips.
