# Martin HD-28

From the Martin HD-28 in the Discord SFZ GM Bank (program 026, Acoustic Guitar (steel)), sampled by Jeff Learman for Kinwie's Discord SFZ GM Bank. The instrument's .sfz states "License: Creative Commons CC0".
https://github.com/sfzinstruments/Discord-SFZ-GM-Bank/tree/master/Discord%20GM/Melodic/026-Acoustic%20Guitar%20(steel)

**The recordings.** A 2017 Martin HD-28 Vintage Series steel-string acoustic, one recording per note about every minor third from E2 to B5 (15 notes), mono, 44.1 kHz, 16-bit. This pack uses the library's only recording of each note: the recordings the strummed Guitar Previews played.

**Notes.** 15 recordings, E2 to B5; the pack plays E2 to C#6. Each recording plays the notes nearest it, sped up or slowed down by at most 2 semitones, as the source's own sampler mapping does.

Each note starts 5 ms before its first sound (40 dB below its peak) with a 2 ms fade-in. It ends where it has fallen 60 dB (30 ms fade), or at 6 s with a 1 s fade if it is still ringing then, or at the end of the recording with a 0.3 s fade if that comes first (9 fall 60 dB, 6 reach 6 s). Notes last 2.2–6.0 s.

**Loops.** The Martin's recordings stop soon after the pluck, once the note has fallen 22–37 dB, and each carries a short loop at its end that the library's sampler repeats while it fades the note out. This pack does the same in the file: the loop is repeated and the note keeps dying away at the rate measured on its own recording (from 0.3 s after the peak to the loop), kept within 4–20 dB per second (4–20 dB per second across these notes).

**Tuning.** Each recording measured (a harmonic fit, then the median of a pitch track over 0.05–0.8 s). 13 of the 15 were 5 cents or more off and were retuned by varispeed (resampled, which also changes their length by under 2%). The finished files measure -4 to 0 cents.

| Recording | Plays | Measured (cents) | Retuned (cents) | Length | Ends |
|---|---|---|---|---|---|
| E2 | E2–F2 | -7.1 | +7.1 | 6.0 s | 6 s, faded |
| G2 | F#2–G#2 | -6.6 | +6.6 | 3.5 s | fell 60 dB |
| A#2 | A2–B2 | -4.3 | – | 6.0 s | 6 s, faded |
| C#3 | C3–D3 | -6.8 | +6.8 | 6.0 s | 6 s, faded |
| E3 | D#3–F3 | -3.9 | – | 6.0 s | 6 s, faded |
| G3 | F#3–G#3 | -5.1 | +5.1 | 4.2 s | fell 60 dB |
| A#3 | A3–B3 | -10.1 | +10.1 | 6.0 s | 6 s, faded |
| C#4 | C4–D4 | -9.1 | +9.1 | 6.0 s | 6 s, faded |
| E4 | D#4–F#4 | -10.7 | +10.7 | 5.6 s | fell 60 dB |
| G#4 | G4–A4 | -10.5 | +10.5 | 4.7 s | fell 60 dB |
| B4 | A#4–C5 | -11.6 | +11.6 | 2.7 s | fell 60 dB |
| D5 | C#5–D#5 | -13.5 | +13.5 | 2.7 s | fell 60 dB |
| F5 | E5–F#5 | -11.8 | +11.8 | 4.0 s | fell 60 dB |
| G#5 | G5–A5 | -13.4 | +13.4 | 3.3 s | fell 60 dB |
| B5 | A#5–C#6 | -16.0 | +16.0 | 2.2 s | fell 60 dB |

**Volume.** Set by the method of the volume audit of 14 October: every note in the range played as the app plays it and measured for listening loudness (ISO 532-1 Zwicker, the loudest moment), each recording's gain set so its notes match, and the pack set to the level of jRhodes and the other pitched packs. The notes measure 70.6 phon (median), within 1.6 phon of one another. At full velocity the loudest note peaks at 0.26 of full scale before the track and master gains.

**Strumming.** Like the rest of the Guitar category, the manifest sets `strum`: notes that start together are one stroke across the strings, down and up strokes strictly alternating; a downstroke goes low to high in 24 ms and an upstroke high to low in 18 ms however many strings it has, the upstroke at 82% of the velocity, each further string a little softer (0.96 down, 0.9 up). Single notes alternate the same way. The app needs the strum update for this; before it, the pack plays chords all at once.

**Envelope.** One-shots, as in the other Guitar packs: attack ramp 2 ms, release 0.4 s, 8 voices, headroom for 4 at once.

Files are mono, 44.1 kHz AAC at 160 kb/s (13 notes) and 192 kb/s (2 notes), each peak-normalised; the catalog gain restores its level. Each file takes the lowest of those rates at which it decodes cleanly (peak within 0.95 of full scale, waveform error at least 20 dB down).

## 1.0.0

First version.
