# uprightbass

Upright-Bass — the "normal" pizzicato samples from pjcohen's Standup Upright Acoustic Double Bass pack on Freesound (pack 21521), CC0.

The files name only natural notes, but each pair holds a note and its sharp: one file of every pair measures 100 cents above the other, so the set is fully chromatic, E1 to F#4, 39 notes. Each file was assigned its true note by measuring it. Every note is within 12 cents and was corrected to exact pitch; the 2 to 14 ms of silence before each pluck was trimmed. Playable down to A0 like the other basses, the lowest notes stretched from E1.

Ingested by tools/ingest-sfz.js from uprightbass.sfz.
Range 21-67, tails cut at 4s.

Levels: matched by loudness to Swag Bass on the same G1, as the other synth-era basses were; one gain, ×0.448, for every note, so the bass's own balance across its range is kept.
