# lunarland

Lunar Land — Sonic Pi sample `ambi_lunar_land`, https://freesound.org/people/maqsim/sounds/172157/.
Pitch, measured by harmonic-series fit over the whole sample and tracked over time: no fixed pitch: a continuous descent of about three octaves, from around B5 to G1, fading as it falls. Rooted on the loud opening around A#5, so a key starts the whole descent from that pitch. Root A#5, left as recorded (+0 cents). One sample played from A#4 to A#6 by resampling.

Ingested by tools/ingest-sfz.js from lunarland.sfz.
Range 70-94, tails cut at 8s.

Levels: loudest peak to -1.5 dBFS; gain ×1.652, so it peaks at -1.5 dBFS.
