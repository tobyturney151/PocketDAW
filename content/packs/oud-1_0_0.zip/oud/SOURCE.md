# Oud

From "Oud.wav" on Freesound (sound 160461), released under Creative Commons 0. The uploader's account has since been deleted; the sound stays up under "--DeletedUser--".
https://freesound.org/people/--DeletedUser--/sounds/160461/

Every note from C2 to G#4 has its own sample, played at its own pitch.

**The recording.** One 75 s file, 44.1 kHz, 16-bit, its two channels identical (used as mono), holding single oud notes one after another. Its description says it was made on an Akai S2000 sampler from very short original oud samples, looped, with a synthetic decay added, and names its range "D1 to F3" in the Akai's octave numbering (middle C is C3), which is D2 to F4 here.

**Notes.** 17 cut from it, at each note's onset, and each measured (a harmonic comb for the octave, then the pitch track): D#2, G#2, A#2, C3, D3, E3, F3, F#3, G3, A3, A#3, B3, C4, D4, D#4, E4, F4. Each starts at its first sound (40 dB below its peak, less 5 ms) with a 2 ms fade-in and ends where it has fallen 60 dB, with a 30 ms fade.

**Tuning.** Measured (cents: D#2 0, G#2 0, A#2 0, C3 0, D3 -1, E3 0, F3 -1, F#3 0, G3 0, A3 0, A#3 0, B3 -1, C4 0, D4 0, D#4 0, E4 0, F4 0); none is 5 cents or more off, so none was corrected. Finished notes measure -1 to +7 cents.

**Notes between recordings**, and up to 3 semitones past the lowest and highest, were made from the nearest recording (the one below when two are equally near) with Signalsmith Stretch (MIT licence, https://github.com/Signalsmith-Audio/signalsmith-stretch, via python-stretch), which shifts pitch while keeping the recording's timing, level-matched to that recording.

| Note | Made from | Semitones |
|---|---|---|
| C2 | D#2 | -3 |
| C#2 | D#2 | -2 |
| D2 | D#2 | -1 |
| D#2 | D#2 | recorded |
| E2 | D#2 | +1 |
| F2 | D#2 | +2 |
| F#2 | G#2 | -2 |
| G2 | G#2 | -1 |
| G#2 | G#2 | recorded |
| A2 | G#2 | +1 |
| A#2 | A#2 | recorded |
| B2 | A#2 | +1 |
| C3 | C3 | recorded |
| C#3 | C3 | +1 |
| D3 | D3 | recorded |
| D#3 | D3 | +1 |
| E3 | E3 | recorded |
| F3 | F3 | recorded |
| F#3 | F#3 | recorded |
| G3 | G3 | recorded |
| G#3 | G3 | +1 |
| A3 | A3 | recorded |
| A#3 | A#3 | recorded |
| B3 | B3 | recorded |
| C4 | C4 | recorded |
| C#4 | C4 | +1 |
| D4 | D4 | recorded |
| D#4 | D#4 | recorded |
| E4 | E4 | recorded |
| F4 | F4 | recorded |
| F#4 | F4 | +1 |
| G4 | F4 | +2 |
| G#4 | F4 | +3 |

**One-shots.** No loops: each note plays to its own end (about 1.5-2.5 s), as Spanish Guitar, the other pack in the Guitar category, does.

**Volume.** Every note is set to the same listening loudness (Zwicker, ISO 532-1, the loudest moment of its first 0.8 s), and the pack plays at the level of the Spanish Guitar pack in the app, the other pack in the Guitar category (median of its notes' first 0.15 s, K-weighted, headroom for 4 voices included). At full velocity the loudest note peaks at 0.95 of full scale before the track and master gains.

**Envelope.** Attack ramp 2 ms, release 0.4 s. Notes speak 0-52 ms after they start.

Files are mono, 44.1 kHz AAC (96 kb/s), each peak-normalised; the catalog gain restores the level.

## 1.0.0

First version.
